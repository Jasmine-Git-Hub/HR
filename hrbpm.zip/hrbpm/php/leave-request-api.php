<?php
// php/leave-request-api.php
// Fix: connect.php is in the same directory, so just use the filename
require_once 'connect.php';

header('Content-Type: application/json');

// Get the request method
$method = $_SERVER['REQUEST_METHOD'];

try {
    switch ($method) {
        case 'GET':
            // Get all leave requests with employee names (concatenate first_name and last_name)
            $sql = "SELECT 
                        l.leave_id, 
                        l.employee_id, 
                        l.leave_type, 
                        l.start_date, 
                        l.end_date, 
                        l.leave_reason, 
                        l.leave_status, 
                        l.approved_by, 
                        l.approval_date,
                        CONCAT(e.first_name, ' ', e.last_name) as employee_name 
                    FROM leave_requests l 
                    LEFT JOIN employees e ON l.employee_id = e.employee_id 
                    ORDER BY l.leave_id DESC";
            
            $stmt = $conn->query($sql);
            
            if (!$stmt) {
                throw new Exception("Query failed: " . print_r($conn->errorInfo(), true));
            }
            
            $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Format the data to match the JS expected format
            $formattedRequests = array();
            foreach ($requests as $row) {
                // Calculate days between dates
                $days = calculateDays($row['start_date'], $row['end_date']);
                
                // Determine status
                $status = $row['leave_status'] ?? 'pending';
                if (is_string($status)) {
                    $status = ucfirst(strtolower($status));
                } else {
                    $status = 'Pending';
                }
                
                $formattedRequests[] = [
                    'id' => 'LV-' . $row['leave_id'],
                    'employee' => $row['employee_name'] ?? 'Unknown Employee',
                    'type' => $row['leave_type'] ?? 'Vacation',
                    'from' => $row['start_date'],
                    'to' => $row['end_date'],
                    'days' => $days,
                    'reason' => $row['leave_reason'] ?? '',
                    'status' => $status
                ];
            }
            
            echo json_encode(['success' => true, 'data' => $formattedRequests]);
            break;
            
        case 'POST':
            // Create a new leave request
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data) {
                throw new Exception('Invalid request data');
            }
            
            // Start transaction
            $conn->beginTransaction();
            
            try {
                // Handle employee lookup/creation
                $employee_id = null;
                
                // Split the full name into first and last name
                $nameParts = explode(' ', trim($data['employee']));
                $firstName = $nameParts[0];
                $lastName = count($nameParts) > 1 ? implode(' ', array_slice($nameParts, 1)) : '';
                
                // Try to find existing employee by first and last name
                $stmt = $conn->prepare("SELECT employee_id FROM employees WHERE first_name = ? AND last_name = ? LIMIT 1");
                $stmt->execute([$firstName, $lastName]);
                $employee = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($employee) {
                    $employee_id = $employee['employee_id'];
                } else {
                    // Get default department_id (first available)
                    $deptStmt = $conn->query("SELECT department_id FROM departments LIMIT 1");
                    $dept = $deptStmt ? $deptStmt->fetch(PDO::FETCH_ASSOC) : null;
                    $deptId = $dept ? $dept['department_id'] : 1;
                    
                    // Get default position_id (first available)
                    $posStmt = $conn->query("SELECT position_id FROM positions LIMIT 1");
                    $pos = $posStmt ? $posStmt->fetch(PDO::FETCH_ASSOC) : null;
                    $posId = $pos ? $pos['position_id'] : 1;
                    
                    // Insert new employee with first and last name
                    $insertSql = "INSERT INTO employees (
                        first_name, 
                        last_name, 
                        department_id, 
                        position_id, 
                        hire_date, 
                        email, 
                        employment_status
                    ) VALUES (?, ?, ?, ?, CURDATE(), ?, 'Probationary')";
                    
                    // Create a simple email from the name
                    $email = strtolower(str_replace(' ', '.', $data['employee'])) . '@hospital.com';
                    
                    $insertStmt = $conn->prepare($insertSql);
                    $insertStmt->execute([
                        $firstName,
                        $lastName,
                        $deptId,
                        $posId,
                        $email
                    ]);
                    $employee_id = $conn->lastInsertId();
                }
                
                // Insert leave request
                $sql = "INSERT INTO leave_requests (
                            employee_id, 
                            leave_type, 
                            start_date, 
                            end_date, 
                            leave_reason, 
                            leave_status
                        ) VALUES (?, ?, ?, ?, ?, 'Pending')";
                
                $stmt = $conn->prepare($sql);
                $result = $stmt->execute([
                    $employee_id,
                    $data['type'],
                    $data['from'],
                    $data['to'],
                    $data['reason'] ?? ''
                ]);
                
                if (!$result) {
                    throw new Exception('Failed to insert leave request');
                }
                
                $leave_id = $conn->lastInsertId();
                
                // Commit transaction
                $conn->commit();
                
                echo json_encode([
                    'success' => true, 
                    'message' => 'Leave request created successfully',
                    'data' => [
                        'id' => 'LV-' . $leave_id,
                        'employee' => $data['employee'],
                        'type' => $data['type'],
                        'from' => $data['from'],
                        'to' => $data['to'],
                        'days' => $data['days'] ?? calculateDays($data['from'], $data['to']),
                        'reason' => $data['reason'] ?? '',
                        'status' => 'Pending'
                    ]
                ]);
                
            } catch (Exception $e) {
                $conn->rollBack();
                throw $e;
            }
            break;
            
        case 'PUT':
            // Update leave request status
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data || !isset($data['id']) || !isset($data['status'])) {
                throw new Exception('Invalid request data');
            }
            
            $leave_id = str_replace('LV-', '', $data['id']);
            
            $sql = "UPDATE leave_requests SET 
                    leave_status = ?, 
                    approval_date = CURDATE()";
            
            $params = [$data['status']];
            
            if (isset($data['approved_by'])) {
                $sql .= ", approved_by = ?";
                $params[] = $data['approved_by'];
            }
            
            $sql .= " WHERE leave_id = ?";
            $params[] = $leave_id;
            
            $stmt = $conn->prepare($sql);
            $stmt->execute($params);
            
            echo json_encode(['success' => true, 'message' => 'Leave request updated successfully']);
            break;
            
        case 'DELETE':
            // Delete a leave request
            $id = isset($_GET['id']) ? str_replace('LV-', '', $_GET['id']) : null;
            
            if (!$id) {
                throw new Exception('Invalid request ID');
            }
            
            $sql = "DELETE FROM leave_requests WHERE leave_id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->execute([$id]);
            
            echo json_encode(['success' => true, 'message' => 'Leave request deleted successfully']);
            break;
            
        default:
            throw new Exception('Method not allowed');
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'error' => 'Database error: ' . $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}

function calculateDays($from, $to) {
    if (!$from || !$to) return 1;
    
    try {
        $fromDate = new DateTime($from);
        $toDate = new DateTime($to);
        $interval = $fromDate->diff($toDate);
        return max(1, $interval->days + 1);
    } catch (Exception $e) {
        return 1;
    }
}
?>