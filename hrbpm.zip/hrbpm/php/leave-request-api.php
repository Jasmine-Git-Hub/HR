<?php
// php/leave-request-api.php
require_once 'connect.php';

header('Content-Type: application/json');

// Get the request method
$method = $_SERVER['REQUEST_METHOD'];

try {
    switch ($method) {
        case 'GET':
            // Get all leave requests with employee names
            // Fix: Use the correct column name 'start_date' (no space)
            $sql = "SELECT 
                        l.leave_id, 
                        l.employee_id, 
                        l.leave_type, 
                        l.start_date, 
                        l.end_date, 
                        l.leave_reason, 
                        l.leave_status, 
                        l.approved_by, 
                        l.approval_date,
                        COALESCE(e.employee_name, CONCAT('Employee #', l.employee_id)) as employee_name 
                    FROM leave_requests l 
                    LEFT JOIN employees e ON l.employee_id = e.id 
                    ORDER BY l.leave_id DESC";
            
            $stmt = $conn->query($sql);
            
            if (!$stmt) {
                throw new Exception("Query failed: " . print_r($conn->errorInfo(), true));
            }
            
            $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Format the data to match the JS expected format
            $formattedRequests = array();
            foreach ($requests as $row) {
                // Calculate days between dates
                $days = calculateDays($row['start_date'], $row['end_date']);
                
                // Determine status badge class
                $status = $row['leave_status'] ?? 'pending';
                if (is_string($status)) {
                    $status = ucfirst(strtolower($status));
                } else {
                    $status = 'Pending';
                }
                
                $formattedRequests[] = [
                    'id' => 'LV-' . $row['leave_id'],
                    'employee' => $row['employee_name'] ?? 'Unknown Employee',
                    'type' => $row['leave_type'] ?? 'Vacation',
                    'from' => $row['start_date'],
                    'to' => $row['end_date'],
                    'days' => $days,
                    'reason' => $row['leave_reason'] ?? '',
                    'status' => $status
                ];
            }
            
            echo json_encode(['success' => true, 'data' => $formattedRequests]);
            break;
            
        case 'POST':
            // Create a new leave request
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data) {
                throw new Exception('Invalid request data');
            }
            
            // Start transaction
            $conn->beginTransaction();
            
            try {
                // First, try to find or create employee
                $employee_id = null;
                
                // Check if employees table exists
                $checkTable = $conn->query("SHOW TABLES LIKE 'employees'");
                
                if ($checkTable && $checkTable->rowCount() > 0) {
                    // Check what columns the employees table has
                    $columns = $conn->query("SHOW COLUMNS FROM employees")->fetchAll(PDO::FETCH_COLUMN);
                    
                    // Try to find employee by name (using appropriate column name)
                    if (in_array('employee_name', $columns)) {
                        $stmt = $conn->prepare("SELECT id FROM employees WHERE employee_name LIKE :name LIMIT 1");
                    } elseif (in_array('name', $columns)) {
                        $stmt = $conn->prepare("SELECT id FROM employees WHERE name LIKE :name LIMIT 1");
                    } elseif (in_array('full_name', $columns)) {
                        $stmt = $conn->prepare("SELECT id FROM employees WHERE full_name LIKE :name LIMIT 1");
                    } else {
                        // If no name column found, just insert a new record with minimal data
                        $stmt = $conn->prepare("INSERT INTO employees (id) VALUES (NULL)");
                        $stmt->execute();
                        $employee_id = $conn->lastInsertId();
                    }
                    
                    if (isset($stmt) && !$employee_id) {
                        $stmt->execute([':name' => '%' . $data['employee'] . '%']);
                        $employee = $stmt->fetch(PDO::FETCH_ASSOC);
                        
                        if ($employee) {
                            $employee_id = $employee['id'];
                        }
                    }
                    
                    // If still no employee_id, insert new employee
                    if (!$employee_id) {
                        // Determine the name column to use
                        if (in_array('employee_name', $columns)) {
                            $stmt = $conn->prepare("INSERT INTO employees (employee_name, department, status) VALUES (:name, 'General', 'Active')");
                        } elseif (in_array('name', $columns)) {
                            $stmt = $conn->prepare("INSERT INTO employees (name, department, status) VALUES (:name, 'General', 'Active')");
                        } elseif (in_array('full_name', $columns)) {
                            $stmt = $conn->prepare("INSERT INTO employees (full_name, department, status) VALUES (:name, 'General', 'Active')");
                        } else {
                            // If no name column, just insert with minimal data
                            $stmt = $conn->prepare("INSERT INTO employees (department, status) VALUES ('General', 'Active')");
                            $stmt->execute();
                            $employee_id = $conn->lastInsertId();
                        }
                        
                        if (isset($stmt) && !$employee_id) {
                            $stmt->execute([':name' => $data['employee']]);
                            $employee_id = $conn->lastInsertId();
                        }
                    }
                } else {
                    // If no employees table, create a simple one
                    $conn->exec("CREATE TABLE IF NOT EXISTS employees (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        employee_name VARCHAR(100),
                        department VARCHAR(50),
                        status VARCHAR(20)
                    )");
                    
                    $stmt = $conn->prepare("INSERT INTO employees (employee_name, department, status) VALUES (:name, 'General', 'Active')");
                    $stmt->execute([':name' => $data['employee']]);
                    $employee_id = $conn->lastInsertId();
                }
                
                // Make sure we have an employee_id
                if (!$employee_id) {
                    $employee_id = 1; // Fallback to ID 1
                }
                
                // Insert leave request with correct column names
                $sql = "INSERT INTO leave_requests (
                            employee_id, 
                            leave_type, 
                            start_date, 
                            end_date, 
                            leave_reason, 
                            leave_status
                        ) VALUES (
                            :employee_id, 
                            :type, 
                            :from_date, 
                            :to_date, 
                            :reason, 
                            :status
                        )";
                
                $stmt = $conn->prepare($sql);
                $result = $stmt->execute([
                    ':employee_id' => $employee_id,
                    ':type' => $data['type'],
                    ':from_date' => $data['from'],
                    ':to_date' => $data['to'],
                    ':reason' => $data['reason'] ?? '',
                    ':status' => 'Pending'
                ]);
                
                if (!$result) {
                    throw new Exception('Failed to insert leave request');
                }
                
                $leave_id = $conn->lastInsertId();
                
                // Commit transaction
                $conn->commit();
                
                echo json_encode([
                    'success' => true, 
                    'message' => 'Leave request created successfully',
                    'data' => [
                        'id' => 'LV-' . $leave_id,
                        'employee' => $data['employee'],
                        'type' => $data['type'],
                        'from' => $data['from'],
                        'to' => $data['to'],
                        'days' => $data['days'] ?? calculateDays($data['from'], $data['to']),
                        'reason' => $data['reason'] ?? '',
                        'status' => 'Pending'
                    ]
                ]);
                
            } catch (Exception $e) {
                $conn->rollBack();
                throw $e;
            }
            break;
            
        case 'PUT':
            // Update leave request status (approve/reject)
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data || !isset($data['id']) || !isset($data['status'])) {
                throw new Exception('Invalid request data');
            }
            
            // Extract numeric ID from LV-XXX format
            $leave_id = str_replace('LV-', '', $data['id']);
            
            $sql = "UPDATE leave_requests SET 
                    leave_status = :status, 
                    approval_date = CURDATE()";
            
            // Add approved_by if provided
            if (isset($data['approved_by'])) {
                $sql .= ", approved_by = :approved_by";
            }
            
            $sql .= " WHERE leave_id = :id";
            
            $stmt = $conn->prepare($sql);
            $params = [
                ':status' => ucfirst(strtolower($data['status'])),
                ':id' => $leave_id
            ];
            
            if (isset($data['approved_by'])) {
                $params[':approved_by'] = $data['approved_by'];
            }
            
            $stmt->execute($params);
            
            echo json_encode(['success' => true, 'message' => 'Leave request updated successfully']);
            break;
            
        case 'DELETE':
            // Delete a leave request
            $id = isset($_GET['id']) ? str_replace('LV-', '', $_GET['id']) : null;
            
            if (!$id) {
                throw new Exception('Invalid request ID');
            }
            
            $sql = "DELETE FROM leave_requests WHERE leave_id = :id";
            $stmt = $conn->prepare($sql);
            $stmt->execute([':id' => $id]);
            
            echo json_encode(['success' => true, 'message' => 'Leave request deleted successfully']);
            break;
            
        default:
            throw new Exception('Method not allowed');
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'error' => 'Database error: ' . $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}

// Helper function to calculate days
function calculateDays($from, $to) {
    if (!$from || !$to) return 1;
    
    try {
        $fromDate = new DateTime($from);
        $toDate = new DateTime($to);
        $interval = $fromDate->diff($toDate);
        return max(1, $interval->days + 1);
    } catch (Exception $e) {
        return 1;
    }
}
?>