<?php
// add-sample-employees.php
require_once __DIR__ . '/php/connect.php';

echo "<h2>Adding Sample Employees</h2>";

try {
    if (!$conn) {
        throw new Exception("Database connection failed");
    }
    
    // First, check if departments exist
    $deptCheck = $conn->query("SELECT COUNT(*) as count FROM departments");
    $deptCount = $deptCheck->fetch(PDO::FETCH_ASSOC)['count'];
    
    if ($deptCount == 0) {
        // Insert default department
        $conn->exec("INSERT INTO departments (department_name) VALUES ('General')");
        echo "Added default department<br>";
    }
    
    // Get department ID
    $dept = $conn->query("SELECT department_id FROM departments LIMIT 1")->fetch(PDO::FETCH_ASSOC);
    $deptId = $dept['department_id'];
    
    // Check if positions exist
    $posCheck = $conn->query("SELECT COUNT(*) as count FROM positions");
    $posCount = $posCheck->fetch(PDO::FETCH_ASSOC)['count'];
    
    if ($posCount == 0) {
        // Insert default position
        $conn->exec("INSERT INTO positions (department_id, grade_id, position_title) VALUES ($deptId, 1, 'Employee')");
        echo "Added default position<br>";
    }
    
    // Get position ID
    $pos = $conn->query("SELECT position_id FROM positions LIMIT 1")->fetch(PDO::FETCH_ASSOC);
    $posId = $pos['position_id'];
    
    // Sample employees to add
    $employees = [
        ['Anna', 'Santos', 'anna.santos@hospital.com', 'EMP001'],
        ['Jude', 'Molina', 'jude.molina@hospital.com', 'EMP002'],
        ['Leah', 'Gomez', 'leah.gomez@hospital.com', 'EMP003'],
        ['Maria', 'Cruz', 'maria.cruz@hospital.com', 'EMP004'],
        ['Mark', 'Rivera', 'mark.rivera@hospital.com', 'EMP005']
    ];
    
    $added = 0;
    $skipped = 0;
    
    foreach ($employees as $emp) {
        // Check if employee already exists
        $check = $conn->prepare("SELECT COUNT(*) as count FROM employees WHERE email = ? OR employee_no = ?");
        $check->execute([$emp[2], $emp[3]]);
        $exists = $check->fetch(PDO::FETCH_ASSOC)['count'];
        
        if ($exists == 0) {
            $sql = "INSERT INTO employees (
                department_id, 
                position_id, 
                employee_no, 
                first_name, 
                last_name, 
                email, 
                hire_date, 
                employment_status
            ) VALUES (?, ?, ?, ?, ?, ?, CURDATE(), 'Regular')";
            
            $stmt = $conn->prepare($sql);
            $stmt->execute([$deptId, $posId, $emp[3], $emp[0], $emp[1], $emp[2]]);
            echo "Added: " . $emp[0] . " " . $emp[1] . "<br>";
            $added++;
        } else {
            echo "Skipped (already exists): " . $emp[0] . " " . $emp[1] . "<br>";
            $skipped++;
        }
    }
    
    // Also add leave balances
    echo "<h3>Adding Leave Balances</h3>";
    
    // Get all employees
    $emps = $conn->query("SELECT employee_id, first_name, last_name FROM employees")->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($emps as $emp) {
        // Check if balances exist
        $check = $conn->prepare("SELECT COUNT(*) as count FROM leave_balances WHERE employee_id = ?");
        $check->execute([$emp['employee_id']]);
        $balExists = $check->fetch(PDO::FETCH_ASSOC)['count'];
        
        if ($balExists == 0) {
            // Add default balances
            $balances = [
                ['Vacation', 15, 0, 15],
                ['Sick', 10, 0, 10],
                ['Emergency', 3, 0, 3]
            ];
            
            foreach ($balances as $bal) {
                $sql = "INSERT INTO leave_balances (
                    employee_id, 
                    leave_type, 
                    allotted_credits, 
                    used_credits, 
                    remaining_credits
                ) VALUES (?, ?, ?, ?, ?)";
                
                $stmt = $conn->prepare($sql);
                $stmt->execute([$emp['employee_id'], $bal[0], $bal[1], $bal[2], $bal[3]]);
            }
            echo "Added balances for: " . $emp['first_name'] . " " . $emp['last_name'] . "<br>";
        }
    }
    
    echo "<h3>Summary:</h3>";
    echo "Added: $added employees<br>";
    echo "Skipped: $skipped employees<br>";
    echo "<p style='color: green; font-weight: bold;'>✓ Sample employees added successfully!</p>";
    echo "<p><a href='leave-management.php'>Go to Leave Management</a></p>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}
?>