<?php
// php/get-employees.php
require_once __DIR__ . '/connect.php';

header('Content-Type: application/json');

try {
    if (!$conn) {
        throw new Exception('Database connection failed');
    }
    
    $stmt = $conn->query("
        SELECT 
            employee_id,
            CONCAT(first_name, ' ', last_name) as full_name,
            first_name,
            last_name,
            email
        FROM employees
        WHERE employment_status IN ('Regular', 'Probationary')
        ORDER BY first_name, last_name
    ");
    
    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'data' => $employees
    ]);
    
} catch (Exception $e) {
    error_log('Get employees error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>