
window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const PAYROLL_KEY = 'hospitalHrPayrollRecords';

    function ensurePayrollProcessingModalHost() {
        if (document.getElementById('payrollProcessingModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="payrollProcessingModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="payrollProcessingModalTitle">Payroll Processing</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="payrollProcessingModalBody"></div>',
            '      <div class="modal-footer" id="payrollProcessingModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showPayrollProcessingModal(config) {
        const modalEl = document.getElementById('payrollProcessingModal');
        const titleEl = document.getElementById('payrollProcessingModalTitle');
        const bodyEl = document.getElementById('payrollProcessingModalBody');
        const footerEl = document.getElementById('payrollProcessingModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    function defaultPayroll() {
        return [
            { id: 'PAY-9001', employee: 'Anna Santos', period: '2026-03-15', base: 32000, overtime: 1800, deductions: 2400, net: 31400, status: 'Ready', payslip: false },
            { id: 'PAY-9002', employee: 'Jude Molina', period: '2026-03-15', base: 28500, overtime: 950, deductions: 2100, net: 27350, status: 'Processed', payslip: true },
            { id: 'PAY-9003', employee: 'Leah Gomez', period: '2026-03-15', base: 30000, overtime: 1200, deductions: 2200, net: 29000, status: 'Ready', payslip: false }
        ];
    }

    function getStorageList(key, fallbackFn) {
        const raw = localStorage.getItem(key);
        const fallback = fallbackFn();
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderPayrollProcessing = function (container) {
        ensurePayrollProcessingModalHost();

        let payroll = getStorageList(PAYROLL_KEY, defaultPayroll);

        function render() {
            const readyCount = payroll.filter(function (item) { return item.status === 'Ready'; }).length;
            const processedCount = payroll.filter(function (item) { return item.status === 'Processed'; }).length;

            container.innerHTML = [
                '<div class="row g-3 mb-3 payroll-processing-submodule">',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Ready for Processing</p><h5 class="mb-0">' + readyCount + '</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Processed</p><h5 class="mb-0">' + processedCount + '</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Current Cutoff</p><h5 class="mb-0">March 2026</h5></div></div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-gears text-primary me-2"></i>Payroll Processing Queue</h5></div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>Payroll ID</th><th>Employee</th><th>Period</th><th>Net Pay</th><th>Status</th><th>Action</th></tr></thead>',
                '      <tbody>',
                payroll.map(function (item) {
                    const badge = item.status === 'Processed' ? 'bg-success-subtle text-success' : 'bg-warning-subtle text-warning';
                    return '<tr>'
                        + '<td>' + item.id + '</td>'
                        + '<td>' + item.employee + '</td>'
                        + '<td>' + item.period + '</td>'
                        + '<td>₱' + Number(item.net).toLocaleString() + '</td>'
                        + '<td><span class="badge ' + badge + '">' + item.status + '</span></td>'
                        + '<td><button class="btn btn-sm btn-outline-primary" data-action="process" data-id="' + item.id + '">Process</button></td>'
                        + '</tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            container.querySelectorAll('button[data-action="process"]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const id = button.getAttribute('data-id');
                    const target = payroll.find(function (item) { return item.id === id; });
                    if (!target) {
                        return;
                    }

                    showPayrollProcessingModal({
                        title: 'Process Payroll Entry',
                        message: 'Mark payroll ' + target.id + ' for ' + target.employee + ' as Processed?',
                        footerHtml: [
                            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                            '<button type="button" class="btn btn-primary" id="confirmPayrollProcessBtn">Process</button>'
                        ].join(''),
                        onShown: function (modal) {
                            const confirmBtn = document.getElementById('confirmPayrollProcessBtn');
                            if (!confirmBtn) {
                                return;
                            }

                            confirmBtn.addEventListener('click', function () {
                                payroll = payroll.map(function (item) {
                                    if (item.id !== id) {
                                        return item;
                                    }
                                    return {
                                        id: item.id,
                                        employee: item.employee,
                                        period: item.period,
                                        base: item.base,
                                        overtime: item.overtime,
                                        deductions: item.deductions,
                                        net: item.net,
                                        status: 'Processed',
                                        payslip: item.payslip === true
                                    };
                                });
                                setStorageList(PAYROLL_KEY, payroll);
                                modal.hide();
                                render();

                                showPayrollProcessingModal({
                                    title: 'Payroll Processed',
                                    message: 'Payroll ' + target.id + ' is now marked as Processed.'
                                });
                            }, { once: true });
                        }
                    });
                });
            });
        }

        render();
    };
})(window.HRSubmodules);


window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const PAYROLL_KEY = 'hospitalHrPayrollRecords';

    function ensureSalaryComputationModalHost() {
        if (document.getElementById('salaryComputationModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="salaryComputationModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="salaryComputationModalTitle">Salary Computation</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="salaryComputationModalBody"></div>',
            '      <div class="modal-footer" id="salaryComputationModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showSalaryComputationInfo(title, message) {
        const modalEl = document.getElementById('salaryComputationModal');
        const titleEl = document.getElementById('salaryComputationModalTitle');
        const bodyEl = document.getElementById('salaryComputationModalBody');
        const footerEl = document.getElementById('salaryComputationModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    function defaultPayroll() {
        return [
            { id: 'PAY-9001', employee: 'Anna Santos', period: '2026-03-15', base: 32000, overtime: 1800, deductions: 2400, net: 31400, status: 'Ready', payslip: false },
            { id: 'PAY-9002', employee: 'Jude Molina', period: '2026-03-15', base: 28500, overtime: 950, deductions: 2100, net: 27350, status: 'Processed', payslip: true },
            { id: 'PAY-9003', employee: 'Leah Gomez', period: '2026-03-15', base: 30000, overtime: 1200, deductions: 2200, net: 29000, status: 'Ready', payslip: false }
        ];
    }

    function getStorageList(key, fallbackFn) {
        const raw = localStorage.getItem(key);
        const fallback = fallbackFn();
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderSalaryComputation = function (container) {
        ensureSalaryComputationModalHost();

        let payroll = getStorageList(PAYROLL_KEY, defaultPayroll);

        function render() {
            container.innerHTML = [
                '<div class="card border-0 shadow-sm mb-3 salary-computation-submodule">',
                '  <div class="card-body">',
                '    <h6 class="mb-3"><i class="fas fa-calculator text-primary me-2"></i>Compute Salary Entry</h6>',
                '    <div class="row g-2">',
                '      <div class="col-md-3"><input id="salaryEmployee" class="form-control" placeholder="Employee"></div>',
                '      <div class="col-md-2"><input id="salaryBase" type="number" class="form-control" placeholder="Base"></div>',
                '      <div class="col-md-2"><input id="salaryOvertime" type="number" class="form-control" placeholder="Overtime"></div>',
                '      <div class="col-md-2"><input id="salaryDeduction" type="number" class="form-control" placeholder="Deductions"></div>',
                '      <div class="col-md-2"><input id="salaryPeriod" type="date" class="form-control"></div>',
                '      <div class="col-md-1"><button id="salaryComputeBtn" class="btn btn-primary w-100">Add</button></div>',
                '    </div>',
                '  </div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-receipt text-primary me-2"></i>Salary Computation Ledger</h5></div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>Payroll ID</th><th>Employee</th><th>Base</th><th>Overtime</th><th>Deductions</th><th>Net Pay</th></tr></thead>',
                '      <tbody>',
                payroll.map(function (item) {
                    return '<tr>'
                        + '<td>' + item.id + '</td>'
                        + '<td>' + item.employee + '</td>'
                        + '<td>₱' + Number(item.base).toLocaleString() + '</td>'
                        + '<td>₱' + Number(item.overtime).toLocaleString() + '</td>'
                        + '<td>₱' + Number(item.deductions).toLocaleString() + '</td>'
                        + '<td class="fw-semibold">₱' + Number(item.net).toLocaleString() + '</td>'
                        + '</tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            const computeButton = document.getElementById('salaryComputeBtn');
            if (!computeButton) {
                return;
            }

            computeButton.addEventListener('click', function () {
                const employee = (document.getElementById('salaryEmployee').value || '').trim();
                const base = Number(document.getElementById('salaryBase').value || 0);
                const overtime = Number(document.getElementById('salaryOvertime').value || 0);
                const deductions = Number(document.getElementById('salaryDeduction').value || 0);
                const period = (document.getElementById('salaryPeriod').value || '').trim();

                if (!employee || !base || !period) {
                    showSalaryComputationInfo('Incomplete Salary Entry', 'Employee, base pay, and payroll period are required.');
                    return;
                }

                const net = base + overtime - deductions;
                const nextId = 'PAY-' + (9000 + payroll.length + 1);
                payroll.unshift({
                    id: nextId,
                    employee: employee,
                    period: period,
                    base: base,
                    overtime: overtime,
                    deductions: deductions,
                    net: net,
                    status: 'Ready',
                    payslip: false
                });

                setStorageList(PAYROLL_KEY, payroll);
                render();
                showSalaryComputationInfo('Salary Computed', 'Payroll entry ' + nextId + ' for ' + employee + ' has been created.');
            });
        }

        render();
    };
})(window.HRSubmodules);


window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const PAYROLL_KEY = 'hospitalHrPayrollRecords';

    function ensurePayslipGenerationModalHost() {
        if (document.getElementById('payslipGenerationModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="payslipGenerationModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="payslipGenerationModalTitle">Payslip Generation</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="payslipGenerationModalBody"></div>',
            '      <div class="modal-footer" id="payslipGenerationModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showPayslipGenerationModal(config) {
        const modalEl = document.getElementById('payslipGenerationModal');
        const titleEl = document.getElementById('payslipGenerationModalTitle');
        const bodyEl = document.getElementById('payslipGenerationModalBody');
        const footerEl = document.getElementById('payslipGenerationModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    function defaultPayroll() {
        return [
            { id: 'PAY-9001', employee: 'Anna Santos', period: '2026-03-15', base: 32000, overtime: 1800, deductions: 2400, net: 31400, status: 'Ready', payslip: false },
            { id: 'PAY-9002', employee: 'Jude Molina', period: '2026-03-15', base: 28500, overtime: 950, deductions: 2100, net: 27350, status: 'Processed', payslip: true },
            { id: 'PAY-9003', employee: 'Leah Gomez', period: '2026-03-15', base: 30000, overtime: 1200, deductions: 2200, net: 29000, status: 'Ready', payslip: false }
        ];
    }

    function getStorageList(key, fallbackFn) {
        const raw = localStorage.getItem(key);
        const fallback = fallbackFn();
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderPayslipGeneration = function (container) {
        ensurePayslipGenerationModalHost();

        let payroll = getStorageList(PAYROLL_KEY, defaultPayroll);

        function render() {
            const readyForPayslip = payroll.filter(function (item) {
                return item.status === 'Processed' && item.payslip !== true;
            });

            const generatedCount = payroll.filter(function (item) { return item.payslip === true; }).length;

            container.innerHTML = [
                '<div class="row g-3 mb-3 payslip-generation-submodule">',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Ready for Payslip</p><h5 class="mb-0">' + readyForPayslip.length + '</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Generated Payslips</p><h5 class="mb-0">' + generatedCount + '</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Distribution Status</p><h5 class="mb-0">Ready</h5></div></div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-file-invoice-dollar text-primary me-2"></i>Payslip Generation</h5></div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>Payroll ID</th><th>Employee</th><th>Period</th><th>Net Pay</th><th>Payslip</th><th>Action</th></tr></thead>',
                '      <tbody>',
                payroll.map(function (item) {
                    const payslipBadge = item.payslip === true
                        ? '<span class="badge bg-success-subtle text-success">Generated</span>'
                        : '<span class="badge bg-warning-subtle text-warning">Pending</span>';
                    const disabled = item.status !== 'Processed' || item.payslip === true ? ' disabled' : '';

                    return '<tr>'
                        + '<td>' + item.id + '</td>'
                        + '<td>' + item.employee + '</td>'
                        + '<td>' + item.period + '</td>'
                        + '<td>₱' + Number(item.net).toLocaleString() + '</td>'
                        + '<td>' + payslipBadge + '</td>'
                        + '<td><button class="btn btn-sm btn-outline-primary" data-action="generate" data-id="' + item.id + '"' + disabled + '>Generate</button></td>'
                        + '</tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            container.querySelectorAll('button[data-action="generate"]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const id = button.getAttribute('data-id');
                    const target = payroll.find(function (item) { return item.id === id; });
                    if (!target) {
                        return;
                    }

                    showPayslipGenerationModal({
                        title: 'Generate Payslip',
                        message: 'Generate payslip for ' + target.employee + ' (' + target.id + ')?',
                        footerHtml: [
                            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                            '<button type="button" class="btn btn-primary" id="confirmPayslipGenerationBtn">Generate</button>'
                        ].join(''),
                        onShown: function (modal) {
                            const confirmBtn = document.getElementById('confirmPayslipGenerationBtn');
                            if (!confirmBtn) {
                                return;
                            }

                            confirmBtn.addEventListener('click', function () {
                                payroll = payroll.map(function (item) {
                                    if (item.id !== id) {
                                        return item;
                                    }
                                    return {
                                        id: item.id,
                                        employee: item.employee,
                                        period: item.period,
                                        base: item.base,
                                        overtime: item.overtime,
                                        deductions: item.deductions,
                                        net: item.net,
                                        status: item.status,
                                        payslip: true
                                    };
                                });
                                setStorageList(PAYROLL_KEY, payroll);
                                modal.hide();
                                render();

                                showPayslipGenerationModal({
                                    title: 'Payslip Generated',
                                    message: 'Payslip for ' + target.employee + ' has been generated successfully.'
                                });
                            }, { once: true });
                        }
                    });
                });
            });
        }

        render();
    };
})(window.HRSubmodules);


window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const PAYROLL_KEY = 'hospitalHrPayrollRecords';

    function defaultPayroll() {
        return [
            { id: 'PAY-9001', employee: 'Anna Santos', period: '2026-03-15', base: 32000, overtime: 1800, deductions: 2400, net: 31400, status: 'Ready', payslip: false },
            { id: 'PAY-9002', employee: 'Jude Molina', period: '2026-03-15', base: 28500, overtime: 950, deductions: 2100, net: 27350, status: 'Processed', payslip: true },
            { id: 'PAY-9003', employee: 'Leah Gomez', period: '2026-03-15', base: 30000, overtime: 1200, deductions: 2200, net: 29000, status: 'Ready', payslip: false }
        ];
    }

    function getStorageList(key, fallbackFn) {
        const raw = localStorage.getItem(key);
        const fallback = fallbackFn();
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
    }

    registry.renderPayrollReports = function (container) {
        const payroll = getStorageList(PAYROLL_KEY, defaultPayroll);
        const totalNet = payroll.reduce(function (sum, item) { return sum + Number(item.net || 0); }, 0);
        const totalBase = payroll.reduce(function (sum, item) { return sum + Number(item.base || 0); }, 0);
        const totalDeductions = payroll.reduce(function (sum, item) { return sum + Number(item.deductions || 0); }, 0);
        const processedCount = payroll.filter(function (item) { return item.status === 'Processed'; }).length;

        container.innerHTML = [
            '<div class="d-flex justify-content-between align-items-center mb-3 payroll-reports-submodule"><h6 class="mb-0"><i class="fas fa-chart-column text-primary me-2"></i>Payroll Reports</h6></div>',
            '<div class="row g-3 mb-3">',
            '  <div class="col-md-3"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Payroll Runs</p><h5 class="mb-0">' + payroll.length + '</h5></div></div>',
            '  <div class="col-md-3"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Processed</p><h5 class="mb-0">' + processedCount + '</h5></div></div>',
            '  <div class="col-md-3"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Total Net Pay</p><h5 class="mb-0">₱' + totalNet.toLocaleString() + '</h5></div></div>',
            '  <div class="col-md-3"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Total Deductions</p><h5 class="mb-0">₱' + totalDeductions.toLocaleString() + '</h5></div></div>',
            '</div>',
            '<div class="card border-0 shadow-sm">',
            '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-table text-primary me-2"></i>Payroll Summary Report</h5></div>',
            '  <div class="table-responsive">',
            '    <table class="table mb-0 align-middle">',
            '      <thead><tr><th>Payroll ID</th><th>Employee</th><th>Period</th><th>Gross (Base+OT)</th><th>Deductions</th><th>Net Pay</th><th>Status</th></tr></thead>',
            '      <tbody>',
            payroll.map(function (item) {
                const gross = Number(item.base || 0) + Number(item.overtime || 0);
                const badge = item.status === 'Processed' ? 'bg-success-subtle text-success' : 'bg-warning-subtle text-warning';

                return '<tr>'
                    + '<td>' + item.id + '</td>'
                    + '<td>' + item.employee + '</td>'
                    + '<td>' + item.period + '</td>'
                    + '<td>₱' + gross.toLocaleString() + '</td>'
                    + '<td>₱' + Number(item.deductions || 0).toLocaleString() + '</td>'
                    + '<td class="fw-semibold">₱' + Number(item.net || 0).toLocaleString() + '</td>'
                    + '<td><span class="badge ' + badge + '">' + item.status + '</span></td>'
                    + '</tr>';
            }).join(''),
            '      </tbody>',
            '      <tfoot><tr><th colspan="3">Totals</th><th>₱' + (totalBase + payroll.reduce(function (sum, item) { return sum + Number(item.overtime || 0); }, 0)).toLocaleString() + '</th><th>₱' + totalDeductions.toLocaleString() + '</th><th>₱' + totalNet.toLocaleString() + '</th><th></th></tr></tfoot>',
            '    </table>',
            '  </div>',
            '</div>'
        ].join('');
    };
})(window.HRSubmodules);

(function () {
    var container = document.getElementById('pmSubmoduleContainer');
    var buttons = Array.prototype.slice.call(document.querySelectorAll('button[data-submodule]'));

    var rendererMap = {
        'Payroll Processing': 'renderPayrollProcessing',
        'Salary Computation': 'renderSalaryComputation',
        'Payslip Generation': 'renderPayslipGeneration',
        'Payroll Reports': 'renderPayrollReports'
    };

    function setActiveButton(activeName) {
        buttons.forEach(function (button) {
            button.classList.toggle('active', button.getAttribute('data-submodule') === activeName);
        });
    }

    function renderSubmodule(submoduleName) {
        if (!container) {
            return;
        }

        var rendererName = rendererMap[submoduleName];
        var renderer = rendererName && window.HRSubmodules ? window.HRSubmodules[rendererName] : null;

        if (typeof renderer === 'function') {
            renderer(container);
        } else {
            container.innerHTML = '<div class="alert alert-warning mb-0">Submodule renderer is not available.</div>';
        }

        setActiveButton(submoduleName);
    }

    buttons.forEach(function (button) {
        button.addEventListener('click', function () {
            renderSubmodule(button.getAttribute('data-submodule'));
        });
    });

    if (container && buttons.length) {
        renderSubmodule('Payroll Processing');
    }
})();
