window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const LEAVE_REQUESTS_API = window.location.pathname.toLowerCase().indexOf('/modules/') !== -1
        ? '../php/leave-request-api.php'
        : 'php/leave-request-api.php';

    // Use data from PHP if available, otherwise fallback to API
    function getInitialData() {
        return window.hrLeaveData || {
            stats: { pending: 0, approved: 0, rejected: 0, total_days: 0 },
            recentRequests: [],
            balances: []
        };
    }

    // Render Leave Dashboard with data from database
    registry.renderLeaveDashboard = function (container) {
        const data = getInitialData();
        const stats = data.stats;
        const recentRequests = data.recentRequests || [];
        const balances = data.balances || [];

        const pending = stats.pending || 0;
        const approved = stats.approved || 0;
        const rejected = stats.rejected || 0;
        const totalDays = stats.total_days || 0;

        const avgVacation = balances.length
            ? Math.round((balances.reduce(function (sum, item) { return sum + Number(item.vacation || 0); }, 0) / balances.length) * 10) / 10
            : 0;

        const latestRows = recentRequests.slice(0, 5).map(function (item) {
            const status = item.leave_status || item.status || 'Pending';
            const badge = status === 'Approved'
                ? 'bg-success-subtle text-success'
                : status === 'Rejected'
                    ? 'bg-danger-subtle text-danger'
                    : 'bg-warning-subtle text-warning';
            
            const employeeName = item.employee_name || item.employee || 'Unknown';
            const leaveId = item.leave_code || item.leave_id || item.id || 'N/A';
            const leaveType = item.leave_type || item.type || 'N/A';
            const days = item.days || 1;
            
            return '<tr><td>' + leaveId + '</td><td>' + employeeName + '</td><td>' + leaveType + '</td><td>' + days + '</td><td><span class="badge ' + badge + '">' + status + '</span></td></tr>';
        }).join('') || '<tr><td colspan="5" class="text-center text-muted">No recent requests</td></tr>';

        container.innerHTML = [
            '<div class="d-flex align-items-center gap-2 mb-3"><i class="fas fa-gauge-high text-primary"></i><h6 class="mb-0">Leave Dashboard</h6></div>',
            '<div class="row g-3 mb-3 leave-dashboard-submodule">',
            '  <div class="col-md-3"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Pending Requests</p><h5 class="mb-0">' + pending + '</h5></div></div>',
            '  <div class="col-md-3"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Approved Requests</p><h5 class="mb-0">' + approved + '</h5></div></div>',
            '  <div class="col-md-3"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Rejected Requests</p><h5 class="mb-0">' + rejected + '</h5></div></div>',
            '  <div class="col-md-3"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Leave Days Filed</p><h5 class="mb-0">' + totalDays + '</h5></div></div>',
            '</div>',
            '<div class="row g-3 mb-3">',
            '  <div class="col-md-6"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Average Vacation Balance</p><h5 class="mb-0">' + avgVacation + ' days</h5></div></div>',
            '  <div class="col-md-6"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Total Active Employees in Leave Ledger</p><h5 class="mb-0">' + balances.length + '</h5></div></div>',
            '</div>',
            '<div class="card border-0 shadow-sm">',
            '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-list-check text-primary me-2"></i>Recent Leave Requests</h5></div>',
            '  <div class="table-responsive">',
            '    <table class="table mb-0 align-middle">',
            '      <thead><tr><th>ID</th><th>Employee</th><th>Type</th><th>Days</th><th>Status</th></tr></thead>',
            '      <tbody>' + latestRows + '</tbody>',
            '    </table>',
            '  </div>',
            '</div>'
        ].join('');
    };
})(window.HRSubmodules);

// Leave Request Module
window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const LEAVE_REQUESTS_API = window.location.pathname.toLowerCase().indexOf('/modules/') !== -1
        ? '../php/leave-request-api.php'
        : 'php/leave-request-api.php';

    function ensureLeaveRequestModalHost() {
        if (document.getElementById('leaveRequestModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="leaveRequestModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="leaveRequestModalTitle">Leave Request</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="leaveRequestModalBody"></div>',
            '      <div class="modal-footer" id="leaveRequestModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showLeaveRequestInfo(title, message, isError = false) {
        const modalEl = document.getElementById('leaveRequestModal');
        const titleEl = document.getElementById('leaveRequestModalTitle');
        const bodyEl = document.getElementById('leaveRequestModalBody');
        const footerEl = document.getElementById('leaveRequestModalFooter');
        
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            alert(title + ': ' + message);
            return;
        }

        titleEl.textContent = title;
        titleEl.style.color = isError ? '#dc3545' : '';
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        
        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();
        
        modalEl.addEventListener('hidden.bs.modal', function() {
            titleEl.style.color = '';
        }, { once: true });
    }

    function calcDays(fromValue, toValue) {
        if (!fromValue || !toValue) return 0;
        
        const fromDate = new Date(fromValue);
        const toDate = new Date(toValue);
        
        if (Number.isNaN(fromDate.getTime()) || Number.isNaN(toDate.getTime()) || toDate < fromDate) {
            return 0;
        }

        const msPerDay = 1000 * 60 * 60 * 24;
        return Math.floor((toDate - fromDate) / msPerDay) + 1;
    }

    async function fetchRequestsFromDB() {
        try {
            const response = await fetch(LEAVE_REQUESTS_API);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const result = await response.json();
            
            if (result.success && result.data) {
                return result.data;
            }
            return [];
        } catch (error) {
            console.error('Error fetching leave requests:', error);
            showLeaveRequestInfo('Database Error', 'Could not fetch leave requests. Please check your connection.', true);
            return [];
        }
    }

    async function fetchEmployeesFromDB() {
        try {
            // You'll need to create this endpoint or use an existing one
            const response = await fetch('php/get-employees.php');
            if (!response.ok) {
                throw new Error('Failed to fetch employees');
            }
            const result = await response.json();
            return result.success ? result.data : [];
        } catch (error) {
            console.error('Error fetching employees:', error);
            return [];
        }
    }

    async function saveRequestToDB(requestData) {
        try {
            console.log('Sending to server:', requestData);
            
            const response = await fetch(LEAVE_REQUESTS_API, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(requestData)
            });
            
            const responseText = await response.text();
            console.log('Raw server response:', responseText);
            
            let result;
            try {
                result = JSON.parse(responseText);
            } catch (e) {
                console.error('Failed to parse JSON:', responseText);
                throw new Error('Server returned invalid response. Check console for details.');
            }
            
            if (!result.success) {
                throw new Error(result.error || 'Failed to save request');
            }
            
            return result.data;
        } catch (error) {
            console.error('Error saving leave request:', error);
            showLeaveRequestInfo('Database Error', error.message, true);
            throw error;
        }
    }

    registry.renderLeaveRequest = async function (container) {
        if (!container) {
            console.error('Container element is required');
            return;
        }

        ensureLeaveRequestModalHost();

        // Show loading state
        container.innerHTML = '<div class="text-center p-4"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></div>';

        // Fetch initial data from database
        let requests = await fetchRequestsFromDB();
        let employees = await fetchEmployeesFromDB();

        async function render() {
            const today = new Date().toISOString().split('T')[0];
            
            // Create employee datalist options
            const employeeOptions = employees.length ? 
                employees.map(emp => '<option value="' + emp.full_name + '">').join('') :
                '<option value="Anna Santos"><option value="Jude Molina"><option value="Leah Gomez">';
            
            container.innerHTML = [
                '<div class="card border-0 shadow-sm mb-3 leave-request-submodule">',
                '  <div class="card-body">',
                '    <h6 class="mb-3"><i class="fas fa-calendar-plus text-primary me-2"></i>Create Leave Request</h6>',
                '    <div class="row g-2">',
                '      <div class="col-md-3">',
                '        <input id="lvEmp" class="form-control" placeholder="Employee Name" list="employeeList" autocomplete="off">',
                '        <datalist id="employeeList">',
                employeeOptions,
                '        </datalist>',
                '      </div>',
                '      <div class="col-md-2">',
                '        <select id="lvType" class="form-select">',
                '          <option value="Vacation">Vacation</option>',
                '          <option value="Sick">Sick</option>',
                '          <option value="Emergency">Emergency</option>',
                '        </select>',
                '      </div>',
                '      <div class="col-md-2">',
                '        <input id="lvFrom" type="date" class="form-control" min="' + today + '">',
                '      </div>',
                '      <div class="col-md-2">',
                '        <input id="lvTo" type="date" class="form-control" min="' + today + '">',
                '      </div>',
                '      <div class="col-md-2">',
                '        <input id="lvReason" class="form-control" placeholder="Reason">',
                '      </div>',
                '      <div class="col-md-1">',
                '        <button id="lvAddBtn" class="btn btn-primary w-100">',
                '          <i class="fas fa-paper-plane"></i>',
                '        </button>',
                '      </div>',
                '    </div>',
                '  </div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white d-flex justify-content-between align-items-center">',
                '    <h5 class="mb-0"><i class="fas fa-inbox text-primary me-2"></i>Leave Requests</h5>',
                '    <div>',
                '      <button id="refreshLeaveBtn" class="btn btn-sm btn-outline-primary me-2" title="Refresh">',
                '        <i class="fas fa-sync-alt"></i>',
                '      </button>',
                '      <span class="badge bg-primary">' + requests.length + ' total</span>',
                '    </div>',
                '  </div>',
                '  <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">',
                '    <table class="table table-hover mb-0 align-middle">',
                '      <thead class="sticky-top bg-white">',
                '        <tr>',
                '          <th>ID</th>',
                '          <th>Employee</th>',
                '          <th>Type</th>',
                '          <th>From</th>',
                '          <th>To</th>',
                '          <th>Days</th>',
                '          <th>Reason</th>',
                '          <th>Status</th>',
                '        </tr>',
                '      </thead>',
                '      <tbody id="leaveRequestsTableBody">',
                requests.length ? requests.map(function (item) {
                    const statusLower = (item.status || 'Pending').toLowerCase();
                    const badgeClass = statusLower === 'approved' ? 'bg-success-subtle text-success' : 
                                     statusLower === 'rejected' ? 'bg-danger-subtle text-danger' : 
                                     'bg-warning-subtle text-warning';
                    
                    const statusBadge = statusLower === 'approved' ? '✅' :
                                      statusLower === 'rejected' ? '❌' : '⏳';
                    
                    return '<tr>' + 
                        '<td><code>' + (item.id || 'N/A') + '</code></td>' +
                        '<td><strong>' + (item.employee || 'Unknown') + '</strong></td>' +
                        '<td>' + (item.type || 'N/A') + '</td>' +
                        '<td>' + (item.from || 'N/A') + '</td>' +
                        '<td>' + (item.to || 'N/A') + '</td>' +
                        '<td><span class="badge bg-secondary">' + (item.days || 1) + ' day' + ((item.days || 1) > 1 ? 's' : '') + '</span></td>' +
                        '<td><small>' + (item.reason ? item.reason.substring(0, 20) + (item.reason.length > 20 ? '...' : '') : '-') + '</small></td>' +
                        '<td><span class="badge ' + badgeClass + '">' + statusBadge + ' ' + (item.status || 'Pending') + '</span></td>' +
                    '</tr>';
                }).join('') : 
                '<tr><td colspan="8" class="text-center text-muted py-4"><i class="fas fa-inbox fa-2x mb-2 d-block"></i>No leave requests found</td></tr>',
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            // Add button event listener
            const addButton = document.getElementById('lvAddBtn');
            if (addButton) {
                addButton.addEventListener('click', async function () {
                    const employee = (document.getElementById('lvEmp').value || '').trim();
                    const type = document.getElementById('lvType').value;
                    const from = document.getElementById('lvFrom').value;
                    const to = document.getElementById('lvTo').value;
                    const reason = (document.getElementById('lvReason').value || '').trim();
                    const days = calcDays(from, to);

                    // Validation
                    if (!employee) {
                        showLeaveRequestInfo('Missing Information', 'Please enter employee name.', true);
                        document.getElementById('lvEmp').focus();
                        return;
                    }

                    if (!from) {
                        showLeaveRequestInfo('Missing Information', 'Please select start date.', true);
                        document.getElementById('lvFrom').focus();
                        return;
                    }

                    if (!to) {
                        showLeaveRequestInfo('Missing Information', 'Please select end date.', true);
                        document.getElementById('lvTo').focus();
                        return;
                    }

                    if (!reason) {
                        showLeaveRequestInfo('Missing Information', 'Please enter a reason.', true);
                        document.getElementById('lvReason').focus();
                        return;
                    }

                    if (!days) {
                        showLeaveRequestInfo('Invalid Date Range', 'End date must be on or after start date.', true);
                        document.getElementById('lvTo').focus();
                        return;
                    }

                    // Disable button to prevent double submission
                    addButton.disabled = true;
                    addButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>';

                    try {
                        // Save to database
                        const newRequest = await saveRequestToDB({
                            employee: employee,
                            type: type,
                            from: from,
                            to: to,
                            reason: reason
                        });

                        // Update local array
                        requests.unshift(newRequest);
                        
                        // Clear form
                        document.getElementById('lvEmp').value = '';
                        document.getElementById('lvFrom').value = '';
                        document.getElementById('lvTo').value = '';
                        document.getElementById('lvReason').value = '';
                        
                        // Re-render the table
                        await render();
                        
                        showLeaveRequestInfo('Success!', 'Leave request for ' + employee + ' has been submitted for approval.');
                    } catch (error) {
                        // Error already handled in saveRequestToDB
                        addButton.disabled = false;
                        addButton.innerHTML = '<i class="fas fa-paper-plane"></i>';
                    }
                });
            }

            // Refresh button event listener
            const refreshBtn = document.getElementById('refreshLeaveBtn');
            if (refreshBtn) {
                refreshBtn.addEventListener('click', async function () {
                    refreshBtn.disabled = true;
                    refreshBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>';
                    
                    requests = await fetchRequestsFromDB();
                    await render();
                    
                    refreshBtn.disabled = false;
                    refreshBtn.innerHTML = '<i class="fas fa-sync-alt"></i>';
                    
                    showLeaveRequestInfo('Refreshed', 'Leave requests have been refreshed from the database.');
                });
            }

            // Auto-update "to" date minimum based on "from" date
            const fromInput = document.getElementById('lvFrom');
            const toInput = document.getElementById('lvTo');
            
            if (fromInput && toInput) {
                fromInput.addEventListener('change', function() {
                    toInput.min = this.value;
                    if (toInput.value && toInput.value < this.value) {
                        toInput.value = this.value;
                    }
                });
            }
        }

        await render();
    };
})(window.HRSubmodules);

// Leave Approval Module
window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const LEAVE_REQUESTS_API = window.location.pathname.toLowerCase().indexOf('/modules/') !== -1
        ? '../php/leave-request-api.php'
        : 'php/leave-request-api.php';

    function ensureLeaveApprovalModalHost() {
        if (document.getElementById('leaveApprovalModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="leaveApprovalModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="leaveApprovalModalTitle">Leave Approval</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="leaveApprovalModalBody"></div>',
            '      <div class="modal-footer" id="leaveApprovalModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showLeaveApprovalModal(config) {
        const modalEl = document.getElementById('leaveApprovalModal');
        const titleEl = document.getElementById('leaveApprovalModalTitle');
        const bodyEl = document.getElementById('leaveApprovalModalBody');
        const footerEl = document.getElementById('leaveApprovalModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    async function fetchRequestsFromDB() {
        try {
            const response = await fetch(LEAVE_REQUESTS_API);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const result = await response.json();
            
            if (result.success && result.data) {
                return result.data;
            }
            return [];
        } catch (error) {
            console.error('Error fetching leave requests:', error);
            return [];
        }
    }

    async function updateRequestStatus(id, status, approvedBy = 'Admin') {
        try {
            const response = await fetch(LEAVE_REQUESTS_API, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    id: id,
                    status: status,
                    approved_by: approvedBy
                })
            });
            
            const result = await response.json();
            return result.success;
        } catch (error) {
            console.error('Error updating request:', error);
            return false;
        }
    }

    registry.renderLeaveApproval = async function (container) {
        ensureLeaveApprovalModalHost();

        // Show loading state
        container.innerHTML = '<div class="text-center p-4"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></div>';

        let requests = await fetchRequestsFromDB();

        function render() {
            const pendingRequests = requests.filter(function (item) { 
                return (item.status || '').toLowerCase() === 'pending'; 
            });

            container.innerHTML = [
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white d-flex justify-content-between align-items-center">',
                '    <h5 class="mb-0"><i class="fas fa-check-double text-primary me-2"></i>Leave Approval Queue</h5>',
                '    <div>',
                '      <button id="refreshApprovalBtn" class="btn btn-sm btn-outline-primary me-2" title="Refresh">',
                '        <i class="fas fa-sync-alt"></i>',
                '      </button>',
                '      <span class="badge bg-warning-subtle text-warning">' + pendingRequests.length + ' Pending</span>',
                '    </div>',
                '  </div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle leave-approval-submodule">',
                '      <thead><tr><th>ID</th><th>Employee</th><th>Type</th><th>Days</th><th>Reason</th><th>Status</th><th>Action</th></tr></thead>',
                '      <tbody>',
                requests.length ? requests.map(function (item) {
                    const status = item.status || 'Pending';
                    const badge = status === 'Approved' ? 'bg-success-subtle text-success' : 
                                 status === 'Rejected' ? 'bg-danger-subtle text-danger' : 
                                 'bg-warning-subtle text-warning';
                    
                    const actionButtons = status.toLowerCase() === 'pending' ? 
                        '<button class="btn btn-sm btn-outline-success me-1" data-action="approve" data-id="' + item.id + '">Approve</button>' +
                        '<button class="btn btn-sm btn-outline-danger" data-action="reject" data-id="' + item.id + '">Reject</button>' :
                        '<span class="text-muted">No action needed</span>';
                    
                    return '<tr>'
                        + '<td>' + item.id + '</td>'
                        + '<td>' + item.employee + '</td>'
                        + '<td>' + item.type + '</td>'
                        + '<td>' + item.days + '</td>'
                        + '<td>' + (item.reason || '-') + '</td>'
                        + '<td><span class="badge ' + badge + '">' + status + '</span></td>'
                        + '<td>' + actionButtons + '</td>'
                        + '</tr>';
                }).join('') : 
                '<tr><td colspan="7" class="text-center text-muted py-4">No leave requests found</td></tr>',
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            // Add action button event listeners
            container.querySelectorAll('button[data-action]').forEach(function (button) {
                button.addEventListener('click', async function () {
                    const action = button.getAttribute('data-action');
                    const id = button.getAttribute('data-id');
                    const target = requests.find(function (item) { return item.id === id; });
                    
                    if (!target) {
                        return;
                    }

                    const nextStatus = action === 'approve' ? 'Approved' : 'Rejected';
                    
                    showLeaveApprovalModal({
                        title: nextStatus === 'Approved' ? 'Approve Leave Request' : 'Reject Leave Request',
                        message: 'Update ' + target.id + ' for ' + target.employee + ' to ' + nextStatus + '?',
                        footerHtml: [
                            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                            '<button type="button" class="btn ' + (nextStatus === 'Approved' ? 'btn-success' : 'btn-danger') + '" id="confirmLeaveApprovalActionBtn">Confirm</button>'
                        ].join(''),
                        onShown: function (modal) {
                            const confirmBtn = document.getElementById('confirmLeaveApprovalActionBtn');
                            if (!confirmBtn) {
                                return;
                            }

                            confirmBtn.addEventListener('click', async function () {
                                // Update in database
                                const success = await updateRequestStatus(id, nextStatus);
                                
                                if (success) {
                                    // Update local array
                                    requests = requests.map(function (item) {
                                        if (item.id !== id) {
                                            return item;
                                        }
                                        return {
                                            ...item,
                                            status: nextStatus
                                        };
                                    });
                                    
                                    modal.hide();
                                    render();
                                    
                                    showLeaveApprovalModal({
                                        title: 'Leave Status Updated',
                                        message: 'Request ' + target.id + ' is now ' + nextStatus + '.'
                                    });
                                } else {
                                    showLeaveApprovalModal({
                                        title: 'Update Failed',
                                        message: 'Failed to update request status. Please try again.'
                                    });
                                }
                            }, { once: true });
                        }
                    });
                });
            });

            // Refresh button
            const refreshBtn = document.getElementById('refreshApprovalBtn');
            if (refreshBtn) {
                refreshBtn.addEventListener('click', async function () {
                    refreshBtn.disabled = true;
                    refreshBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>';
                    
                    requests = await fetchRequestsFromDB();
                    render();
                    
                    refreshBtn.disabled = false;
                    refreshBtn.innerHTML = '<i class="fas fa-sync-alt"></i>';
                });
            }
        }

        render();
    };
})(window.HRSubmodules);

// Leave Balance Module
window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    registry.renderLeaveBalance = function (container) {
        // Use data from PHP if available
        const data = window.hrLeaveData || { balances: [] };
        let balances = data.balances || [];

        // If no data from PHP, use sample data
        if (!balances.length) {
            balances = [
                { employee: 'Anna Santos', vacation: 9, sick: 8, emergency: 3 },
                { employee: 'Jude Molina', vacation: 10, sick: 6, emergency: 3 },
                { employee: 'Leah Gomez', vacation: 7, sick: 5, emergency: 2 }
            ];
        }

        const totalVacation = balances.reduce(function (sum, item) { return sum + Number(item.vacation || 0); }, 0);
        const totalSick = balances.reduce(function (sum, item) { return sum + Number(item.sick || 0); }, 0);
        const totalEmergency = balances.reduce(function (sum, item) { return sum + Number(item.emergency || 0); }, 0);

        const balanceRows = balances.map(function (item) {
            return '<tr><td>' + (item.employee || 'Unknown') + '</td><td>' + (item.vacation || 0) + '</td><td>' + (item.sick || 0) + '</td><td>' + (item.emergency || 0) + '</td></tr>';
        }).join('') || '<tr><td colspan="4" class="text-center text-muted">No balance data available</td></tr>';

        container.innerHTML = [
            '<div class="d-flex align-items-center gap-2 mb-3"><i class="fas fa-wallet text-primary"></i><h6 class="mb-0">Leave Balance</h6></div>',
            '<div class="row g-3 mb-3 leave-balance-submodule">',
            '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Total Vacation Balance</p><h5 class="mb-0">' + totalVacation + '</h5></div></div>',
            '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Total Sick Balance</p><h5 class="mb-0">' + totalSick + '</h5></div></div>',
            '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Total Emergency Balance</p><h5 class="mb-0">' + totalEmergency + '</h5></div></div>',
            '</div>',
            '<div class="card border-0 shadow-sm">',
            '  <div class="card-header bg-white d-flex justify-content-between align-items-center">',
            '    <h5 class="mb-0"><i class="fas fa-table-list text-primary me-2"></i>Employee Leave Balance Ledger</h5>',
            '    <span class="badge bg-primary">' + balances.length + ' employees</span>',
            '  </div>',
            '  <div class="table-responsive">',
            '    <table class="table mb-0 align-middle">',
            '      <thead><tr><th>Employee</th><th>Vacation</th><th>Sick</th><th>Emergency</th></tr></thead>',
            '      <tbody>' + balanceRows + '</tbody>',
            '    </table>',
            '  </div>',
            '</div>'
        ].join('');
    };
})(window.HRSubmodules);

// Leave Reports Module
window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const LEAVE_REQUESTS_API = window.location.pathname.toLowerCase().indexOf('/modules/') !== -1
        ? '../php/leave-request-api.php'
        : 'php/leave-request-api.php';

    function ensureLeaveReportsModalHost() {
        if (document.getElementById('leaveReportsModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="leaveReportsModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="leaveReportsModalTitle">Leave Reports</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="leaveReportsModalBody"></div>',
            '      <div class="modal-footer" id="leaveReportsModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showLeaveReportsModal(config) {
        const modalEl = document.getElementById('leaveReportsModal');
        const titleEl = document.getElementById('leaveReportsModalTitle');
        const bodyEl = document.getElementById('leaveReportsModalBody');
        const footerEl = document.getElementById('leaveReportsModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = (config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    async function fetchRequestsFromDB() {
        try {
            const response = await fetch(LEAVE_REQUESTS_API);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const result = await response.json();
            
            if (result.success && result.data) {
                return result.data;
            }
            return [];
        } catch (error) {
            console.error('Error fetching leave requests:', error);
            return [];
        }
    }

    registry.renderLeaveReports = async function (container) {
        ensureLeaveReportsModalHost();

        // Show loading state
        container.innerHTML = '<div class="text-center p-4"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></div>';

        let requests = await fetchRequestsFromDB();

        function render() {
            const typeSummary = {};
            const statusSummary = {
                Approved: 0,
                Pending: 0,
                Rejected: 0
            };

            requests.forEach(function (item) {
                // Count by type
                const type = item.type || 'Other';
                typeSummary[type] = (typeSummary[type] || 0) + (item.days || 1);
                
                // Count by status
                const status = item.status || 'Pending';
                if (statusSummary.hasOwnProperty(status)) {
                    statusSummary[status]++;
                }
            });

            const typeRows = Object.keys(typeSummary).map(function (type) {
                return '<tr><td>' + type + '</td><td>' + typeSummary[type] + '</td></tr>';
            }).join('') || '<tr><td colspan="2" class="text-center text-muted">No data available</td></tr>';

            container.innerHTML = [
                '<div class="d-flex justify-content-between align-items-center mb-3 leave-reports-submodule">',
                '  <h6 class="mb-0"><i class="fas fa-chart-pie text-primary me-2"></i>Leave Reports</h6>',
                '  <div>',
                '    <button id="refreshReportsBtn" class="btn btn-outline-secondary btn-sm me-2">',
                '      <i class="fas fa-sync-alt"></i>',
                '    </button>',
                '    <button id="leaveExportCsv" class="btn btn-outline-secondary btn-sm">Export CSV</button>',
                '  </div>',
                '</div>',
                '<div class="row g-3 mb-3">',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Total Requests</p><h5 class="mb-0">' + requests.length + '</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Approved</p><h5 class="mb-0">' + statusSummary.Approved + '</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Pending</p><h5 class="mb-0">' + statusSummary.Pending + '</h5></div></div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-chart-column text-primary me-2"></i>Leave Days by Type</h5></div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>Leave Type</th><th>Total Days</th></tr></thead>',
                '      <tbody>' + typeRows + '</tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            // Export CSV button
            const exportButton = document.getElementById('leaveExportCsv');
            if (exportButton) {
                exportButton.addEventListener('click', function () {
                    showLeaveReportsModal({
                        title: 'Export Leave CSV',
                        message: 'Download the leave report as a CSV file?',
                        footerHtml: [
                            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                            '<button type="button" class="btn btn-primary" id="confirmLeaveExportBtn">Export</button>'
                        ].join(''),
                        onShown: function (modal) {
                            const confirmBtn = document.getElementById('confirmLeaveExportBtn');
                            if (!confirmBtn) {
                                return;
                            }

                            confirmBtn.addEventListener('click', function () {
                                const csvLines = ['ID,Employee,Type,From,To,Days,Status,Reason'];
                                requests.forEach(function (item) {
                                    csvLines.push([
                                        item.id || 'N/A',
                                        item.employee || 'Unknown',
                                        item.type || 'N/A',
                                        item.from || 'N/A',
                                        item.to || 'N/A',
                                        item.days || 1,
                                        item.status || 'Pending',
                                        (item.reason || '').replace(/,/g, ';') // Replace commas in reason
                                    ].join(','));
                                });

                                const blob = new Blob([csvLines.join('\n')], { type: 'text/csv;charset=utf-8;' });
                                const link = document.createElement('a');
                                link.href = URL.createObjectURL(blob);
                                link.download = 'leave-reports-' + new Date().toISOString().split('T')[0] + '.csv';
                                link.click();
                                URL.revokeObjectURL(link.href);
                                modal.hide();

                                showLeaveReportsModal({
                                    title: 'Export Complete',
                                    message: 'Leave report CSV has been downloaded.'
                                });
                            }, { once: true });
                        }
                    });
                });
            }

            // Refresh button
            const refreshBtn = document.getElementById('refreshReportsBtn');
            if (refreshBtn) {
                refreshBtn.addEventListener('click', async function () {
                    refreshBtn.disabled = true;
                    refreshBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>';
                    
                    requests = await fetchRequestsFromDB();
                    render();
                    
                    refreshBtn.disabled = false;
                    refreshBtn.innerHTML = '<i class="fas fa-sync-alt"></i>';
                });
            }
        }

        render();
    };
})(window.HRSubmodules);

// Initialize module switching
(function () {
    var container = document.getElementById('lmSubmoduleContainer');
    var buttons = Array.prototype.slice.call(document.querySelectorAll('button[data-submodule]'));

    var rendererMap = {
        'Leave Dashboard': 'renderLeaveDashboard',
        'Leave Request': 'renderLeaveRequest',
        'Leave Approval': 'renderLeaveApproval',
        'Leave Balance': 'renderLeaveBalance',
        'Leave Reports': 'renderLeaveReports'
    };

    function setActiveButton(activeName) {
        buttons.forEach(function (button) {
            button.classList.toggle('active', button.getAttribute('data-submodule') === activeName);
        });
    }

    function renderSubmodule(submoduleName) {
        if (!container) {
            return;
        }

        var rendererName = rendererMap[submoduleName];
        var renderer = rendererName && window.HRSubmodules ? window.HRSubmodules[rendererName] : null;

        if (typeof renderer === 'function') {
            Promise.resolve(renderer(container)).catch(function (error) {
                console.error('Error rendering submodule:', error);
                container.innerHTML = '<div class="alert alert-danger mb-0">Unable to load submodule data. Please try again.</div>';
            });
        } else {
            container.innerHTML = '<div class="alert alert-warning mb-0">Submodule renderer is not available.</div>';
        }

        setActiveButton(submoduleName);
    }

    buttons.forEach(function (button) {
        button.addEventListener('click', function () {
            renderSubmodule(button.getAttribute('data-submodule'));
        });
    });

    if (container && buttons.length) {
        renderSubmodule('Leave Dashboard');
    }
})();