window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const TIMESHEET_SUBMISSIONS_KEY = 'hospitalHrTimesheetSubmissions';

    function ensureTimesheetSubmissionModalHost() {
        if (document.getElementById('timesheetSubmissionModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="timesheetSubmissionModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="timesheetSubmissionModalTitle">Timesheet Submission</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="timesheetSubmissionModalBody"></div>',
            '      <div class="modal-footer" id="timesheetSubmissionModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showTimesheetSubmissionInfo(title, message) {
        const modalEl = document.getElementById('timesheetSubmissionModal');
        const titleEl = document.getElementById('timesheetSubmissionModalTitle');
        const bodyEl = document.getElementById('timesheetSubmissionModalBody');
        const footerEl = document.getElementById('timesheetSubmissionModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    function getStorageList(key, fallback) {
        const raw = localStorage.getItem(key);
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback.slice();
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback.slice();
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderTimesheetSubmission = function (container) {
        ensureTimesheetSubmissionModalHost();

        const fallback = [
            { id: 'TS-301', employee: 'Anna Santos', week: '2026-W09', hours: 40, status: 'Submitted' },
            { id: 'TS-302', employee: 'Mark Rivera', week: '2026-W09', hours: 38, status: 'Draft' }
        ];

        let submissions = getStorageList(TIMESHEET_SUBMISSIONS_KEY, fallback);

        function render() {
            container.innerHTML = [
                '<div class="card border-0 shadow-sm mb-3 ts-submission-submodule">',
                '  <div class="card-body">',
                '    <h6 class="mb-3"><i class="fas fa-file-signature text-primary me-2"></i>Submit Timesheet</h6>',
                '    <div class="row g-2">',
                '      <div class="col-md-4"><input id="tsEmp" class="form-control" placeholder="Employee"></div>',
                '      <div class="col-md-3"><input id="tsWeek" class="form-control" placeholder="Week (YYYY-W##)"></div>',
                '      <div class="col-md-2"><input id="tsHours" type="number" min="1" max="80" class="form-control" placeholder="Hours"></div>',
                '      <div class="col-md-2">',
                '        <select id="tsStatus" class="form-select">',
                '          <option>Draft</option>',
                '          <option>Submitted</option>',
                '        </select>',
                '      </div>',
                '      <div class="col-md-1"><button id="tsAddBtn" class="btn btn-primary w-100">Add</button></div>',
                '    </div>',
                '  </div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-clipboard-list text-primary me-2"></i>Timesheet Submission Log</h5></div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>ID</th><th>Employee</th><th>Week</th><th>Hours</th><th>Status</th></tr></thead>',
                '      <tbody>',
                submissions.map(function (item) {
                    const badge = item.status === 'Submitted' ? 'bg-success-subtle text-success' : 'bg-secondary-subtle text-secondary';
                    return '<tr><td>' + item.id + '</td><td>' + item.employee + '</td><td>' + item.week + '</td><td>' + item.hours + '</td><td><span class="badge ' + badge + '">' + item.status + '</span></td></tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            const addButton = document.getElementById('tsAddBtn');
            if (!addButton) {
                return;
            }

            addButton.addEventListener('click', function () {
                const employee = (document.getElementById('tsEmp').value || '').trim();
                const week = (document.getElementById('tsWeek').value || '').trim();
                const hours = Number(document.getElementById('tsHours').value || 0);
                const status = (document.getElementById('tsStatus').value || 'Draft').trim();

                if (!employee || !week || !hours) {
                    showTimesheetSubmissionInfo('Incomplete Timesheet', 'Employee, week, and hours are required to create a timesheet entry.');
                    return;
                }

                const nextNumber = 300 + submissions.length + 1;
                submissions.unshift({
                    id: 'TS-' + nextNumber,
                    employee: employee,
                    week: week,
                    hours: hours,
                    status: status
                });

                setStorageList(TIMESHEET_SUBMISSIONS_KEY, submissions);
                render();
                showTimesheetSubmissionInfo('Timesheet Added', 'Timesheet entry for ' + employee + ' (' + week + ') was recorded.');
            });
        }

        render();
    };
})(window.HRSubmodules);

(function (registry) {
    const TIMESHEET_APPROVAL_KEY = 'hospitalHrTimesheetApprovalQueue';

    function ensureTimesheetApprovalModalHost() {
        if (document.getElementById('timesheetApprovalModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="timesheetApprovalModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="timesheetApprovalModalTitle">Timesheet Approval</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="timesheetApprovalModalBody"></div>',
            '      <div class="modal-footer" id="timesheetApprovalModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showTimesheetApprovalModal(config) {
        const modalEl = document.getElementById('timesheetApprovalModal');
        const titleEl = document.getElementById('timesheetApprovalModalTitle');
        const bodyEl = document.getElementById('timesheetApprovalModalBody');
        const footerEl = document.getElementById('timesheetApprovalModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    function getStorageList(key, fallback) {
        const raw = localStorage.getItem(key);
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback.slice();
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback.slice();
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderTimesheetApproval = function (container) {
        ensureTimesheetApprovalModalHost();

        const fallback = [
            { id: 'APP-401', employee: 'Jude Molina', week: '2026-W09', hours: 41, status: 'Pending' },
            { id: 'APP-402', employee: 'Leah Gomez', week: '2026-W09', hours: 39, status: 'Pending' },
            { id: 'APP-403', employee: 'Anna Santos', week: '2026-W09', hours: 40, status: 'Approved' }
        ];

        let queue = getStorageList(TIMESHEET_APPROVAL_KEY, fallback);

        function render() {
            container.innerHTML = [
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white d-flex justify-content-between align-items-center">',
                '    <h5 class="mb-0"><i class="fas fa-thumbs-up text-primary me-2"></i>Timesheet Approval Queue</h5>',
                '    <span class="badge bg-warning-subtle text-warning">' + queue.filter(function (item) { return item.status === 'Pending'; }).length + ' Pending</span>',
                '  </div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle ts-approval-submodule">',
                '      <thead><tr><th>ID</th><th>Employee</th><th>Week</th><th>Hours</th><th>Status</th><th>Action</th></tr></thead>',
                '      <tbody>',
                queue.map(function (item) {
                    const badge = item.status === 'Approved' ? 'bg-success-subtle text-success' : item.status === 'Rejected' ? 'bg-danger-subtle text-danger' : 'bg-warning-subtle text-warning';
                    return '<tr>'
                        + '<td>' + item.id + '</td>'
                        + '<td>' + item.employee + '</td>'
                        + '<td>' + item.week + '</td>'
                        + '<td>' + item.hours + '</td>'
                        + '<td><span class="badge ' + badge + '">' + item.status + '</span></td>'
                        + '<td>'
                        + '<button class="btn btn-sm btn-outline-success me-1" data-action="approve" data-id="' + item.id + '">Approve</button>'
                        + '<button class="btn btn-sm btn-outline-danger" data-action="reject" data-id="' + item.id + '">Reject</button>'
                        + '</td>'
                        + '</tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            container.querySelectorAll('button[data-action]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const action = button.getAttribute('data-action');
                    const id = button.getAttribute('data-id');
                    const target = queue.find(function (item) { return item.id === id; });
                    if (!target) {
                        return;
                    }

                    const nextStatus = action === 'approve' ? 'Approved' : 'Rejected';
                    showTimesheetApprovalModal({
                        title: nextStatus === 'Approved' ? 'Approve Timesheet' : 'Reject Timesheet',
                        message: 'Set ' + target.id + ' for ' + target.employee + ' to ' + nextStatus + '?',
                        footerHtml: [
                            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                            '<button type="button" class="btn ' + (nextStatus === 'Approved' ? 'btn-success' : 'btn-danger') + '" id="confirmTimesheetApprovalActionBtn">Confirm</button>'
                        ].join(''),
                        onShown: function (modal) {
                            const confirmBtn = document.getElementById('confirmTimesheetApprovalActionBtn');
                            if (!confirmBtn) {
                                return;
                            }

                            confirmBtn.addEventListener('click', function () {
                                queue = queue.map(function (item) {
                                    if (item.id !== id) {
                                        return item;
                                    }
                                    return {
                                        id: item.id,
                                        employee: item.employee,
                                        week: item.week,
                                        hours: item.hours,
                                        status: nextStatus
                                    };
                                });
                                setStorageList(TIMESHEET_APPROVAL_KEY, queue);
                                modal.hide();
                                render();

                                showTimesheetApprovalModal({
                                    title: 'Timesheet Updated',
                                    message: 'Timesheet ' + target.id + ' is now ' + nextStatus + '.'
                                });
                            }, { once: true });
                        }
                    });
                });
            });
        }

        render();
    };
})(window.HRSubmodules);

(function (registry) {
    const OVERTIME_TRACKING_KEY = 'hospitalHrOvertimeTracking';

    function ensureOvertimeTrackingModalHost() {
        if (document.getElementById('overtimeTrackingModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="overtimeTrackingModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="overtimeTrackingModalTitle">Overtime Tracking</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="overtimeTrackingModalBody"></div>',
            '      <div class="modal-footer" id="overtimeTrackingModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showOvertimeTrackingInfo(title, message) {
        const modalEl = document.getElementById('overtimeTrackingModal');
        const titleEl = document.getElementById('overtimeTrackingModalTitle');
        const bodyEl = document.getElementById('overtimeTrackingModalBody');
        const footerEl = document.getElementById('overtimeTrackingModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    function getStorageList(key, fallback) {
        const raw = localStorage.getItem(key);
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback.slice();
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback.slice();
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderOvertimeTracking = function (container) {
        ensureOvertimeTrackingModalHost();

        const fallback = [
            { id: 'OT-501', employee: 'Mark Rivera', date: '2026-03-01', hours: 2, reason: 'Payroll close', status: 'Approved' },
            { id: 'OT-502', employee: 'Jude Molina', date: '2026-03-01', hours: 3, reason: 'System migration', status: 'Pending' }
        ];

        let overtime = getStorageList(OVERTIME_TRACKING_KEY, fallback);

        function render() {
            const totalHours = overtime.reduce(function (sum, item) { return sum + Number(item.hours || 0); }, 0);

            container.innerHTML = [
                '<div class="card border-0 shadow-sm mb-3 overtime-track-submodule">',
                '  <div class="card-body">',
                '    <h6 class="mb-3"><i class="fas fa-business-time text-primary me-2"></i>Log Overtime</h6>',
                '    <div class="row g-2">',
                '      <div class="col-md-3"><input id="otEmp" class="form-control" placeholder="Employee"></div>',
                '      <div class="col-md-2"><input id="otDate" type="date" class="form-control"></div>',
                '      <div class="col-md-2"><input id="otHours" type="number" min="1" max="12" class="form-control" placeholder="Hours"></div>',
                '      <div class="col-md-3"><input id="otReason" class="form-control" placeholder="Reason"></div>',
                '      <div class="col-md-2"><button id="otAddBtn" class="btn btn-primary w-100">Log</button></div>',
                '    </div>',
                '  </div>',
                '</div>',
                '<div class="row g-3 mb-3">',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Overtime Entries</p><h5 class="mb-0">' + overtime.length + '</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Total OT Hours</p><h5 class="mb-0">' + totalHours + '</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Pending Approval</p><h5 class="mb-0">' + overtime.filter(function (item) { return item.status === 'Pending'; }).length + '</h5></div></div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-stopwatch text-primary me-2"></i>Overtime Tracker</h5></div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>ID</th><th>Employee</th><th>Date</th><th>Hours</th><th>Reason</th><th>Status</th></tr></thead>',
                '      <tbody>',
                overtime.map(function (item) {
                    const badge = item.status === 'Approved' ? 'bg-success-subtle text-success' : 'bg-warning-subtle text-warning';
                    return '<tr><td>' + item.id + '</td><td>' + item.employee + '</td><td>' + item.date + '</td><td>' + item.hours + '</td><td>' + item.reason + '</td><td><span class="badge ' + badge + '">' + item.status + '</span></td></tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            const addButton = document.getElementById('otAddBtn');
            if (!addButton) {
                return;
            }

            addButton.addEventListener('click', function () {
                const employee = (document.getElementById('otEmp').value || '').trim();
                const date = (document.getElementById('otDate').value || '').trim();
                const hours = Number(document.getElementById('otHours').value || 0);
                const reason = (document.getElementById('otReason').value || '').trim();

                if (!employee || !date || !hours || !reason) {
                    showOvertimeTrackingInfo('Incomplete Overtime Log', 'Enter employee, date, hours, and reason before logging overtime.');
                    return;
                }

                const nextNumber = 500 + overtime.length + 1;
                overtime.unshift({
                    id: 'OT-' + nextNumber,
                    employee: employee,
                    date: date,
                    hours: hours,
                    reason: reason,
                    status: 'Pending'
                });

                setStorageList(OVERTIME_TRACKING_KEY, overtime);
                render();
                showOvertimeTrackingInfo('Overtime Logged', employee + ' has a pending overtime entry for ' + hours + ' hour(s).');
            });
        }

        render();
    };
})(window.HRSubmodules);

(function () {
    var container = document.getElementById('tmSubmoduleContainer');
    var buttons = Array.prototype.slice.call(document.querySelectorAll('button[data-submodule]'));

    var rendererMap = {
        'Timesheet Submission': 'renderTimesheetSubmission',
        'Timesheet Approval': 'renderTimesheetApproval',
        'Overtime Tracking': 'renderOvertimeTracking'
    };

    function setActiveButton(activeName) {
        buttons.forEach(function (button) {
            button.classList.toggle('active', button.getAttribute('data-submodule') === activeName);
        });
    }

    function renderSubmodule(submoduleName) {
        if (!container) {
            return;
        }

        var rendererName = rendererMap[submoduleName];
        var renderer = rendererName && window.HRSubmodules ? window.HRSubmodules[rendererName] : null;

        if (typeof renderer === 'function') {
            renderer(container);
        } else {
            container.innerHTML = '<div class="alert alert-warning mb-0">Submodule renderer is not available.</div>';
        }

        setActiveButton(submoduleName);
    }

    buttons.forEach(function (button) {
        button.addEventListener('click', function () {
            renderSubmodule(button.getAttribute('data-submodule'));
        });
    });

    if (container && buttons.length) {
        renderSubmodule('Timesheet Submission');
    }
})();
