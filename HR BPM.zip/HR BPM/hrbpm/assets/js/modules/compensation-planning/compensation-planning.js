
window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const COMPENSATION_KEY = 'hospitalHrCompensationRecords';

    function ensureSalaryAdjustmentModalHost() {
        if (document.getElementById('salaryAdjustmentModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="salaryAdjustmentModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="salaryAdjustmentModalTitle">Salary Adjustment</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="salaryAdjustmentModalBody"></div>',
            '      <div class="modal-footer" id="salaryAdjustmentModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showSalaryAdjustmentModal(config) {
        const modalEl = document.getElementById('salaryAdjustmentModal');
        const titleEl = document.getElementById('salaryAdjustmentModalTitle');
        const bodyEl = document.getElementById('salaryAdjustmentModalBody');
        const footerEl = document.getElementById('salaryAdjustmentModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    function defaultCompensation() {
        return [
            { id: 'CMP-7001', employee: 'Anna Santos', adjustmentType: 'Merit Increase', amount: 2500, effectiveDate: '2026-03-10', status: 'Pending', incentive: 0, bonus: 0 },
            { id: 'CMP-7002', employee: 'Jude Molina', adjustmentType: 'Promotion Increase', amount: 4000, effectiveDate: '2026-03-15', status: 'Approved', incentive: 1500, bonus: 3000 },
            { id: 'CMP-7003', employee: 'Leah Gomez', adjustmentType: 'Market Alignment', amount: 1800, effectiveDate: '2026-03-20', status: 'Pending', incentive: 800, bonus: 0 }
        ];
    }

    function getStorageList(key, fallbackFn) {
        const raw = localStorage.getItem(key);
        const fallback = fallbackFn();
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderSalaryAdjustment = function (container) {
        ensureSalaryAdjustmentModalHost();

        let records = getStorageList(COMPENSATION_KEY, defaultCompensation);

        function render() {
            container.innerHTML = [
                '<div class="card border-0 shadow-sm mb-3 salary-adjustment-submodule">',
                '  <div class="card-body">',
                '    <h6 class="mb-3"><i class="fas fa-money-check text-primary me-2"></i>Salary Adjustment Entry</h6>',
                '    <div class="row g-2">',
                '      <div class="col-md-3"><input id="cmpEmpName" class="form-control" placeholder="Employee"></div>',
                '      <div class="col-md-3"><input id="cmpAdjType" class="form-control" placeholder="Adjustment Type"></div>',
                '      <div class="col-md-2"><input id="cmpAdjAmount" type="number" min="1" class="form-control" placeholder="Amount"></div>',
                '      <div class="col-md-2"><input id="cmpAdjDate" type="date" class="form-control"></div>',
                '      <div class="col-md-2"><button id="cmpAdjAddBtn" class="btn btn-primary w-100">Submit</button></div>',
                '    </div>',
                '  </div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-chart-line text-primary me-2"></i>Salary Adjustment Pipeline</h5></div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>ID</th><th>Employee</th><th>Type</th><th>Amount</th><th>Effective Date</th><th>Status</th><th>Action</th></tr></thead>',
                '      <tbody>',
                records.map(function (item) {
                    const badge = item.status === 'Approved' ? 'bg-success-subtle text-success' : 'bg-warning-subtle text-warning';
                    const disabled = item.status === 'Approved' ? ' disabled' : '';
                    return '<tr>'
                        + '<td>' + item.id + '</td>'
                        + '<td>' + item.employee + '</td>'
                        + '<td>' + item.adjustmentType + '</td>'
                        + '<td>₱' + Number(item.amount).toLocaleString() + '</td>'
                        + '<td>' + item.effectiveDate + '</td>'
                        + '<td><span class="badge ' + badge + '">' + item.status + '</span></td>'
                        + '<td><button class="btn btn-sm btn-outline-success" data-action="approve" data-id="' + item.id + '"' + disabled + '>Approve</button></td>'
                        + '</tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            const addButton = document.getElementById('cmpAdjAddBtn');
            if (addButton) {
                addButton.addEventListener('click', function () {
                    const employee = (document.getElementById('cmpEmpName').value || '').trim();
                    const adjustmentType = (document.getElementById('cmpAdjType').value || '').trim();
                    const amount = Number(document.getElementById('cmpAdjAmount').value || 0);
                    const effectiveDate = (document.getElementById('cmpAdjDate').value || '').trim();

                    if (!employee || !adjustmentType || !amount || !effectiveDate) {
                        showSalaryAdjustmentModal({
                            title: 'Incomplete Adjustment',
                            message: 'Employee, adjustment type, amount, and effective date are required.'
                        });
                        return;
                    }

                    const nextId = 'CMP-' + (7000 + records.length + 1);
                    records.unshift({
                        id: nextId,
                        employee: employee,
                        adjustmentType: adjustmentType,
                        amount: amount,
                        effectiveDate: effectiveDate,
                        status: 'Pending',
                        incentive: 0,
                        bonus: 0
                    });

                    setStorageList(COMPENSATION_KEY, records);
                    render();
                    showSalaryAdjustmentModal({
                        title: 'Adjustment Submitted',
                        message: 'Salary adjustment ' + nextId + ' for ' + employee + ' has been submitted.'
                    });
                });
            }

            container.querySelectorAll('button[data-action="approve"]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const id = button.getAttribute('data-id');
                    const target = records.find(function (item) { return item.id === id; });
                    if (!target) {
                        return;
                    }

                    showSalaryAdjustmentModal({
                        title: 'Approve Adjustment',
                        message: 'Approve adjustment ' + target.id + ' for ' + target.employee + '?',
                        footerHtml: [
                            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                            '<button type="button" class="btn btn-success" id="confirmSalaryAdjustmentApproveBtn">Approve</button>'
                        ].join(''),
                        onShown: function (modal) {
                            const confirmBtn = document.getElementById('confirmSalaryAdjustmentApproveBtn');
                            if (!confirmBtn) {
                                return;
                            }

                            confirmBtn.addEventListener('click', function () {
                                records = records.map(function (item) {
                                    if (item.id !== id) {
                                        return item;
                                    }
                                    return {
                                        id: item.id,
                                        employee: item.employee,
                                        adjustmentType: item.adjustmentType,
                                        amount: item.amount,
                                        effectiveDate: item.effectiveDate,
                                        status: 'Approved',
                                        incentive: item.incentive,
                                        bonus: item.bonus
                                    };
                                });
                                setStorageList(COMPENSATION_KEY, records);
                                modal.hide();
                                render();

                                showSalaryAdjustmentModal({
                                    title: 'Adjustment Approved',
                                    message: 'Adjustment ' + target.id + ' is now approved.'
                                });
                            }, { once: true });
                        }
                    });
                });
            });
        }

        render();
    };
})(window.HRSubmodules);


window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const COMPENSATION_KEY = 'hospitalHrCompensationRecords';

    function ensureIncentiveManagementModalHost() {
        if (document.getElementById('incentiveManagementModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="incentiveManagementModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="incentiveManagementModalTitle">Incentive Management</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="incentiveManagementModalBody"></div>',
            '      <div class="modal-footer" id="incentiveManagementModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showIncentiveManagementModal(config) {
        const modalEl = document.getElementById('incentiveManagementModal');
        const titleEl = document.getElementById('incentiveManagementModalTitle');
        const bodyEl = document.getElementById('incentiveManagementModalBody');
        const footerEl = document.getElementById('incentiveManagementModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    function defaultCompensation() {
        return [
            { id: 'CMP-7001', employee: 'Anna Santos', adjustmentType: 'Merit Increase', amount: 2500, effectiveDate: '2026-03-10', status: 'Pending', incentive: 0, bonus: 0 },
            { id: 'CMP-7002', employee: 'Jude Molina', adjustmentType: 'Promotion Increase', amount: 4000, effectiveDate: '2026-03-15', status: 'Approved', incentive: 1500, bonus: 3000 },
            { id: 'CMP-7003', employee: 'Leah Gomez', adjustmentType: 'Market Alignment', amount: 1800, effectiveDate: '2026-03-20', status: 'Pending', incentive: 800, bonus: 0 }
        ];
    }

    function getStorageList(key, fallbackFn) {
        const raw = localStorage.getItem(key);
        const fallback = fallbackFn();
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderIncentiveManagement = function (container) {
        ensureIncentiveManagementModalHost();

        let records = getStorageList(COMPENSATION_KEY, defaultCompensation);

        function render() {
            const totalIncentive = records.reduce(function (sum, item) {
                return sum + Number(item.incentive || 0);
            }, 0);

            container.innerHTML = [
                '<div class="row g-3 mb-3 incentive-management-submodule">',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Compensation Profiles</p><h5 class="mb-0">' + records.length + '</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Total Incentives</p><h5 class="mb-0">₱' + totalIncentive.toLocaleString() + '</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Average Incentive</p><h5 class="mb-0">₱' + (records.length ? Math.round(totalIncentive / records.length).toLocaleString() : '0') + '</h5></div></div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-hand-holding-dollar text-primary me-2"></i>Incentive Management</h5></div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>ID</th><th>Employee</th><th>Adjustment</th><th>Current Incentive</th><th>Action</th></tr></thead>',
                '      <tbody>',
                records.map(function (item) {
                    return '<tr>'
                        + '<td>' + item.id + '</td>'
                        + '<td>' + item.employee + '</td>'
                        + '<td>' + item.adjustmentType + '</td>'
                        + '<td>₱' + Number(item.incentive || 0).toLocaleString() + '</td>'
                        + '<td><button class="btn btn-sm btn-outline-primary" data-action="add-incentive" data-id="' + item.id + '">+₱500</button></td>'
                        + '</tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            container.querySelectorAll('button[data-action="add-incentive"]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const id = button.getAttribute('data-id');
                    const target = records.find(function (item) { return item.id === id; });
                    if (!target) {
                        return;
                    }

                    showIncentiveManagementModal({
                        title: 'Add Incentive',
                        message: 'Add ₱500 incentive to ' + target.employee + ' (' + target.id + ')?',
                        footerHtml: [
                            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                            '<button type="button" class="btn btn-primary" id="confirmIncentiveIncrementBtn">Add</button>'
                        ].join(''),
                        onShown: function (modal) {
                            const confirmBtn = document.getElementById('confirmIncentiveIncrementBtn');
                            if (!confirmBtn) {
                                return;
                            }

                            confirmBtn.addEventListener('click', function () {
                                records = records.map(function (item) {
                                    if (item.id !== id) {
                                        return item;
                                    }
                                    return {
                                        id: item.id,
                                        employee: item.employee,
                                        adjustmentType: item.adjustmentType,
                                        amount: item.amount,
                                        effectiveDate: item.effectiveDate,
                                        status: item.status,
                                        incentive: Number(item.incentive || 0) + 500,
                                        bonus: item.bonus
                                    };
                                });
                                setStorageList(COMPENSATION_KEY, records);
                                modal.hide();
                                render();

                                showIncentiveManagementModal({
                                    title: 'Incentive Added',
                                    message: '₱500 incentive was added for ' + target.employee + '.'
                                });
                            }, { once: true });
                        }
                    });
                });
            });
        }

        render();
    };
})(window.HRSubmodules);


window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const COMPENSATION_KEY = 'hospitalHrCompensationRecords';

    function ensureBonusAllocationModalHost() {
        if (document.getElementById('bonusAllocationModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="bonusAllocationModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="bonusAllocationModalTitle">Bonus Allocation</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="bonusAllocationModalBody"></div>',
            '      <div class="modal-footer" id="bonusAllocationModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showBonusAllocationModal(config) {
        const modalEl = document.getElementById('bonusAllocationModal');
        const titleEl = document.getElementById('bonusAllocationModalTitle');
        const bodyEl = document.getElementById('bonusAllocationModalBody');
        const footerEl = document.getElementById('bonusAllocationModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    function defaultCompensation() {
        return [
            { id: 'CMP-7001', employee: 'Anna Santos', adjustmentType: 'Merit Increase', amount: 2500, effectiveDate: '2026-03-10', status: 'Pending', incentive: 0, bonus: 0 },
            { id: 'CMP-7002', employee: 'Jude Molina', adjustmentType: 'Promotion Increase', amount: 4000, effectiveDate: '2026-03-15', status: 'Approved', incentive: 1500, bonus: 3000 },
            { id: 'CMP-7003', employee: 'Leah Gomez', adjustmentType: 'Market Alignment', amount: 1800, effectiveDate: '2026-03-20', status: 'Pending', incentive: 800, bonus: 0 }
        ];
    }

    function getStorageList(key, fallbackFn) {
        const raw = localStorage.getItem(key);
        const fallback = fallbackFn();
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderBonusAllocation = function (container) {
        ensureBonusAllocationModalHost();

        let records = getStorageList(COMPENSATION_KEY, defaultCompensation);

        function render() {
            const totalBonus = records.reduce(function (sum, item) {
                return sum + Number(item.bonus || 0);
            }, 0);

            const approvedCount = records.filter(function (item) {
                return item.status === 'Approved';
            }).length;

            container.innerHTML = [
                '<div class="d-flex justify-content-between align-items-center mb-3 bonus-allocation-submodule">',
                '  <h6 class="mb-0"><i class="fas fa-gift text-primary me-2"></i>Bonus Allocation</h6>',
                '</div>',
                '<div class="row g-3 mb-3">',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Approved Profiles</p><h5 class="mb-0">' + approvedCount + '</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Total Bonus Pool</p><h5 class="mb-0">₱' + totalBonus.toLocaleString() + '</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Allocation Cycle</p><h5 class="mb-0">Q1 2026</h5></div></div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-sack-dollar text-primary me-2"></i>Bonus Allocation Register</h5></div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>ID</th><th>Employee</th><th>Status</th><th>Incentive</th><th>Bonus</th><th>Action</th></tr></thead>',
                '      <tbody>',
                records.map(function (item) {
                    const badge = item.status === 'Approved' ? 'bg-success-subtle text-success' : 'bg-warning-subtle text-warning';
                    const disabled = item.status !== 'Approved' ? ' disabled' : '';
                    return '<tr>'
                        + '<td>' + item.id + '</td>'
                        + '<td>' + item.employee + '</td>'
                        + '<td><span class="badge ' + badge + '">' + item.status + '</span></td>'
                        + '<td>₱' + Number(item.incentive || 0).toLocaleString() + '</td>'
                        + '<td>₱' + Number(item.bonus || 0).toLocaleString() + '</td>'
                        + '<td><button class="btn btn-sm btn-outline-primary" data-action="allocate" data-id="' + item.id + '"' + disabled + '>+₱1,000 Bonus</button></td>'
                        + '</tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            container.querySelectorAll('button[data-action="allocate"]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const id = button.getAttribute('data-id');
                    const target = records.find(function (item) { return item.id === id; });
                    if (!target) {
                        return;
                    }

                    showBonusAllocationModal({
                        title: 'Allocate Bonus',
                        message: 'Allocate ₱1,000 bonus to ' + target.employee + ' (' + target.id + ')?',
                        footerHtml: [
                            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                            '<button type="button" class="btn btn-primary" id="confirmBonusAllocationBtn">Allocate</button>'
                        ].join(''),
                        onShown: function (modal) {
                            const confirmBtn = document.getElementById('confirmBonusAllocationBtn');
                            if (!confirmBtn) {
                                return;
                            }

                            confirmBtn.addEventListener('click', function () {
                                records = records.map(function (item) {
                                    if (item.id !== id) {
                                        return item;
                                    }
                                    return {
                                        id: item.id,
                                        employee: item.employee,
                                        adjustmentType: item.adjustmentType,
                                        amount: item.amount,
                                        effectiveDate: item.effectiveDate,
                                        status: item.status,
                                        incentive: item.incentive,
                                        bonus: Number(item.bonus || 0) + 1000
                                    };
                                });
                                setStorageList(COMPENSATION_KEY, records);
                                modal.hide();
                                render();

                                showBonusAllocationModal({
                                    title: 'Bonus Allocated',
                                    message: '₱1,000 bonus was allocated for ' + target.employee + '.'
                                });
                            }, { once: true });
                        }
                    });
                });
            });
        }

        render();
    };
})(window.HRSubmodules);

(function () {
    var container = document.getElementById('cpSubmoduleContainer');
    var buttons = Array.prototype.slice.call(document.querySelectorAll('button[data-submodule]'));

    var rendererMap = {
        'Salary Adjustment': 'renderSalaryAdjustment',
        'Incentive Management': 'renderIncentiveManagement',
        'Bonus Allocation': 'renderBonusAllocation'
    };

    function setActiveButton(activeName) {
        buttons.forEach(function (button) {
            button.classList.toggle('active', button.getAttribute('data-submodule') === activeName);
        });
    }

    function renderSubmodule(submoduleName) {
        if (!container) {
            return;
        }

        var rendererName = rendererMap[submoduleName];
        var renderer = rendererName && window.HRSubmodules ? window.HRSubmodules[rendererName] : null;

        if (typeof renderer === 'function') {
            renderer(container);
        } else {
            container.innerHTML = '<div class="alert alert-warning mb-0">Submodule renderer is not available.</div>';
        }

        setActiveButton(submoduleName);
    }

    buttons.forEach(function (button) {
        button.addEventListener('click', function () {
            renderSubmodule(button.getAttribute('data-submodule'));
        });
    });

    if (container && buttons.length) {
        renderSubmodule('Salary Adjustment');
    }
})();
