window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const ATTENDANCE_RECORDS_KEY = 'hospitalHrAttendanceRecords';

    function getAttendanceSeedData() {
        return [
            { employee: 'Anna Santos', department: 'HR Operations', timeIn: '08:02 AM', status: 'Present' },
            { employee: 'Mark Rivera', department: 'Finance', timeIn: '08:21 AM', status: 'Late' },
            { employee: 'Liza De Leon', department: 'Nursing', timeIn: '-', status: 'No Log-in' },
            { employee: 'Paolo Cruz', department: 'HR Operations', timeIn: '-', status: 'On Leave' },
            { employee: 'Jude Molina', department: 'Operations', timeIn: '07:58 AM', status: 'Present' },
            { employee: 'Mara Lopez', department: 'Nursing', timeIn: '08:17 AM', status: 'Late' }
        ];
    }

    function getStorageList(key, fallback) {
        const raw = localStorage.getItem(key);
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback.slice();
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback.slice();
    }

    registry.renderAttendanceMonitoring = function (container) {
        const records = getStorageList(ATTENDANCE_RECORDS_KEY, getAttendanceSeedData());
        container.innerHTML = [
            '<div class="card border-0 shadow-sm att-mon-submodule">',
            '  <div class="card-body">',
            '    <div class="d-flex align-items-center gap-2 mb-3"><i class="fas fa-user-check text-primary"></i><h6 class="mb-0">Attendance Monitoring</h6></div>',
            '    <div class="row g-3 mb-3">',
            '      <div class="col-md-4"><input id="attMonSearch" class="form-control" placeholder="Search employee"></div>',
            '      <div class="col-md-3">',
            '        <select id="attMonStatus" class="form-select">',
            '          <option value="All">All Status</option>',
            '          <option value="Present">Present</option>',
            '          <option value="Late">Late</option>',
            '          <option value="On Leave">On Leave</option>',
            '          <option value="No Log-in">No Log-in</option>',
            '        </select>',
            '      </div>',
            '    </div>',
            '    <div id="attMonKpis" class="row g-3 mb-3"></div>',
            '    <div class="table-responsive">',
            '      <table class="table table-sm align-middle mb-0">',
            '        <thead><tr><th>Employee</th><th>Department</th><th>Time In</th><th>Status</th></tr></thead>',
            '        <tbody id="attMonRows"></tbody>',
            '      </table>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        const searchInput = document.getElementById('attMonSearch');
        const statusSelect = document.getElementById('attMonStatus');
        const rowsEl = document.getElementById('attMonRows');
        const kpisEl = document.getElementById('attMonKpis');

        function render() {
            const query = (searchInput.value || '').toLowerCase().trim();
            const status = statusSelect.value;
            const filtered = records.filter(function (row) {
                const matchesStatus = status === 'All' || row.status === status;
                const matchesQuery = !query || row.employee.toLowerCase().indexOf(query) !== -1 || row.department.toLowerCase().indexOf(query) !== -1;
                return matchesStatus && matchesQuery;
            });

            const present = filtered.filter(function (row) { return row.status === 'Present'; }).length;
            const late = filtered.filter(function (row) { return row.status === 'Late'; }).length;
            const onLeave = filtered.filter(function (row) { return row.status === 'On Leave'; }).length;
            const noLogin = filtered.filter(function (row) { return row.status === 'No Log-in'; }).length;

            kpisEl.innerHTML = [
                '<div class="col-md-3"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Present</p><h5 class="mb-0">' + present + '</h5></div></div>',
                '<div class="col-md-3"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Late</p><h5 class="mb-0">' + late + '</h5></div></div>',
                '<div class="col-md-3"><div class="border rounded-3 p-3"><p class="text-muted mb-1">On Leave</p><h5 class="mb-0">' + onLeave + '</h5></div></div>',
                '<div class="col-md-3"><div class="border rounded-3 p-3"><p class="text-muted mb-1">No Log-in</p><h5 class="mb-0">' + noLogin + '</h5></div></div>'
            ].join('');

            rowsEl.innerHTML = filtered.map(function (row) {
                const badgeClass = row.status === 'Present'
                    ? 'bg-success-subtle text-success'
                    : row.status === 'Late'
                        ? 'bg-warning-subtle text-warning'
                        : row.status === 'On Leave'
                            ? 'bg-info-subtle text-info'
                            : 'bg-danger-subtle text-danger';
                return '<tr><td>' + row.employee + '</td><td>' + row.department + '</td><td>' + row.timeIn + '</td><td><span class="badge ' + badgeClass + '">' + row.status + '</span></td></tr>';
            }).join('');
        }

        searchInput.addEventListener('input', render);
        statusSelect.addEventListener('change', render);
        render();
    };
})(window.HRSubmodules);

(function (registry) {
    const VALIDATION_QUEUE_KEY = 'hospitalHrAttendanceValidationQueue';

    function ensureAttendanceValidationModalHost() {
        if (document.getElementById('attendanceValidationModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="attendanceValidationModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="attendanceValidationModalTitle">Attendance Validation</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="attendanceValidationModalBody"></div>',
            '      <div class="modal-footer" id="attendanceValidationModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showAttendanceValidationModal(config) {
        const modalEl = document.getElementById('attendanceValidationModal');
        const titleEl = document.getElementById('attendanceValidationModalTitle');
        const bodyEl = document.getElementById('attendanceValidationModalBody');
        const footerEl = document.getElementById('attendanceValidationModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    function getStorageList(key, fallback) {
        const raw = localStorage.getItem(key);
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback.slice();
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback.slice();
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderAttendanceValidation = function (container) {
        ensureAttendanceValidationModalHost();

        const fallback = [
            { id: 'VAL-1001', employee: 'Paolo Cruz', issue: 'Missing Time In', status: 'Pending' },
            { id: 'VAL-1002', employee: 'Rina Torres', issue: 'Late Log Entry', status: 'Pending' },
            { id: 'VAL-1003', employee: 'John Lim', issue: 'Early Out Dispute', status: 'For Review' }
        ];
        let queue = getStorageList(VALIDATION_QUEUE_KEY, fallback);

        function render() {
            container.innerHTML = [
                '<div class="card border-0 shadow-sm att-val-submodule">',
                '  <div class="card-header bg-white d-flex justify-content-between align-items-center">',
                '    <h5 class="mb-0"><i class="fas fa-clipboard-check text-primary me-2"></i>Pending Validation Queue</h5>',
                '    <span class="badge bg-warning-subtle text-warning">' + queue.filter(function (item) { return item.status === 'Pending' || item.status === 'For Review'; }).length + ' Open</span>',
                '  </div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>ID</th><th>Employee</th><th>Issue</th><th>Status</th><th>Action</th></tr></thead>',
                '      <tbody>',
                queue.map(function (item) {
                    return '<tr>'
                        + '<td>' + item.id + '</td>'
                        + '<td>' + item.employee + '</td>'
                        + '<td>' + item.issue + '</td>'
                        + '<td><span class="badge ' + (item.status === 'Approved' ? 'bg-success-subtle text-success' : item.status === 'Rejected' ? 'bg-danger-subtle text-danger' : 'bg-warning-subtle text-warning') + '">' + item.status + '</span></td>'
                        + '<td>'
                        + '<button class="btn btn-sm btn-outline-success me-1" data-action="approve" data-id="' + item.id + '">Approve</button>'
                        + '<button class="btn btn-sm btn-outline-danger" data-action="reject" data-id="' + item.id + '">Reject</button>'
                        + '</td>'
                        + '</tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            container.querySelectorAll('button[data-action]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const action = button.getAttribute('data-action');
                    const id = button.getAttribute('data-id');
                    const target = queue.find(function (item) { return item.id === id; });
                    if (!target) {
                        return;
                    }

                    const nextStatus = action === 'approve' ? 'Approved' : 'Rejected';
                    showAttendanceValidationModal({
                        title: nextStatus === 'Approved' ? 'Approve Validation' : 'Reject Validation',
                        message: 'Set request ' + target.id + ' for ' + target.employee + ' to ' + nextStatus + '?',
                        footerHtml: [
                            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                            '<button type="button" class="btn ' + (nextStatus === 'Approved' ? 'btn-success' : 'btn-danger') + '" id="confirmAttendanceValidationActionBtn">Confirm</button>'
                        ].join(''),
                        onShown: function (modal) {
                            const confirmBtn = document.getElementById('confirmAttendanceValidationActionBtn');
                            if (!confirmBtn) {
                                return;
                            }

                            confirmBtn.addEventListener('click', function () {
                                queue = queue.map(function (item) {
                                    if (item.id !== id) {
                                        return item;
                                    }
                                    return {
                                        id: item.id,
                                        employee: item.employee,
                                        issue: item.issue,
                                        status: nextStatus
                                    };
                                });
                                setStorageList(VALIDATION_QUEUE_KEY, queue);
                                modal.hide();
                                render();

                                showAttendanceValidationModal({
                                    title: 'Validation Updated',
                                    message: 'Request ' + target.id + ' is now marked as ' + nextStatus + '.'
                                });
                            }, { once: true });
                        }
                    });
                });
            });
        }

        render();
    };
})(window.HRSubmodules);

(function (registry) {
    const ATTENDANCE_RECORDS_KEY = 'hospitalHrAttendanceRecords';

    function ensureAttendanceReportsModalHost() {
        if (document.getElementById('attendanceReportsModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="attendanceReportsModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="attendanceReportsModalTitle">Attendance Reports</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="attendanceReportsModalBody"></div>',
            '      <div class="modal-footer" id="attendanceReportsModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showAttendanceReportsModal(config) {
        const modalEl = document.getElementById('attendanceReportsModal');
        const titleEl = document.getElementById('attendanceReportsModalTitle');
        const bodyEl = document.getElementById('attendanceReportsModalBody');
        const footerEl = document.getElementById('attendanceReportsModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = (config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    function getAttendanceSeedData() {
        return [
            { employee: 'Anna Santos', department: 'HR Operations', timeIn: '08:02 AM', status: 'Present' },
            { employee: 'Mark Rivera', department: 'Finance', timeIn: '08:21 AM', status: 'Late' },
            { employee: 'Liza De Leon', department: 'Nursing', timeIn: '-', status: 'No Log-in' },
            { employee: 'Paolo Cruz', department: 'HR Operations', timeIn: '-', status: 'On Leave' },
            { employee: 'Jude Molina', department: 'Operations', timeIn: '07:58 AM', status: 'Present' },
            { employee: 'Mara Lopez', department: 'Nursing', timeIn: '08:17 AM', status: 'Late' }
        ];
    }

    function getStorageList(key, fallback) {
        const raw = localStorage.getItem(key);
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback.slice();
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback.slice();
    }

    registry.renderAttendanceReports = function (container) {
        ensureAttendanceReportsModalHost();

        const records = getStorageList(ATTENDANCE_RECORDS_KEY, getAttendanceSeedData());
        const departments = {};
        records.forEach(function (row) {
            const current = departments[row.department] || { total: 0, late: 0, absences: 0 };
            current.total += 1;
            if (row.status === 'Late') {
                current.late += 1;
            }
            if (row.status === 'No Log-in') {
                current.absences += 1;
            }
            departments[row.department] = current;
        });

        const rows = Object.keys(departments).map(function (dept) {
            const info = departments[dept];
            const attendanceRate = Math.max(0, Math.round(((info.total - info.absences) / info.total) * 100));
            return '<tr><td>' + dept + '</td><td>' + attendanceRate + '%</td><td>' + info.late + '</td><td>' + info.absences + '</td></tr>';
        }).join('');

        container.innerHTML = [
            '<div class="d-flex justify-content-between align-items-center mb-3 att-reports-submodule"><h6 class="mb-0"><i class="fas fa-chart-column text-primary me-2"></i>Attendance Reports</h6><button id="attExportCsv" class="btn btn-outline-secondary btn-sm">Export CSV</button></div>',
            '<div class="row g-3 mb-3">',
            '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Monthly Attendance Rate</p><h5 class="mb-0">93%</h5></div></div>',
            '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Average Late Minutes</p><h5 class="mb-0">14 min</h5></div></div>',
            '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Absence Incidents</p><h5 class="mb-0">8</h5></div></div>',
            '</div>',
            '<div class="card border-0 shadow-sm">',
            '  <div class="card-header bg-white"><h5 class="mb-0">Department Attendance Summary</h5></div>',
            '  <div class="table-responsive">',
            '    <table class="table mb-0 align-middle">',
            '      <thead><tr><th>Department</th><th>Attendance Rate</th><th>Late Cases</th><th>Absences</th></tr></thead>',
            '      <tbody>' + rows + '</tbody>',
            '    </table>',
            '  </div>',
            '</div>'
        ].join('');

        const exportButton = document.getElementById('attExportCsv');
        if (exportButton) {
            exportButton.addEventListener('click', function () {
                showAttendanceReportsModal({
                    title: 'Export Attendance CSV',
                    message: 'Generate and download the attendance summary CSV now?',
                    footerHtml: [
                        '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                        '<button type="button" class="btn btn-primary" id="confirmAttendanceExportBtn">Export</button>'
                    ].join(''),
                    onShown: function (modal) {
                        const confirmBtn = document.getElementById('confirmAttendanceExportBtn');
                        if (!confirmBtn) {
                            return;
                        }

                        confirmBtn.addEventListener('click', function () {
                            const csvLines = ['Department,Attendance Rate,Late Cases,Absences'];
                            Object.keys(departments).forEach(function (dept) {
                                const info = departments[dept];
                                const rate = Math.max(0, Math.round(((info.total - info.absences) / info.total) * 100));
                                csvLines.push([dept, rate + '%', info.late, info.absences].join(','));
                            });

                            const blob = new Blob([csvLines.join('\n')], { type: 'text/csv;charset=utf-8;' });
                            const link = document.createElement('a');
                            link.href = URL.createObjectURL(blob);
                            link.download = 'attendance-reports.csv';
                            link.click();
                            URL.revokeObjectURL(link.href);
                            modal.hide();

                            showAttendanceReportsModal({
                                title: 'Export Complete',
                                message: 'Attendance report CSV has been downloaded.'
                            });
                        }, { once: true });
                    }
                });
            });
        }
    };
})(window.HRSubmodules);

(function (registry) {
    const CORRECTION_REQUESTS_KEY = 'hospitalHrCorrectionRequests';

    function ensureCorrectionRequestsModalHost() {
        if (document.getElementById('correctionRequestsModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="correctionRequestsModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="correctionRequestsModalTitle">Correction Requests</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="correctionRequestsModalBody"></div>',
            '      <div class="modal-footer" id="correctionRequestsModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showCorrectionRequestsInfo(title, message) {
        const modalEl = document.getElementById('correctionRequestsModal');
        const titleEl = document.getElementById('correctionRequestsModalTitle');
        const bodyEl = document.getElementById('correctionRequestsModalBody');
        const footerEl = document.getElementById('correctionRequestsModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    function getStorageList(key, fallback) {
        const raw = localStorage.getItem(key);
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback.slice();
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback.slice();
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderCorrectionRequests = function (container) {
        ensureCorrectionRequestsModalHost();

        const fallback = [
            { id: 'CR-1042', employee: 'Anna Santos', issue: 'Missing Time Out', status: 'Pending' },
            { id: 'CR-1041', employee: 'Miguel Reyes', issue: 'Wrong Shift Tag', status: 'Approved' },
            { id: 'CR-1038', employee: 'Leah Gomez', issue: 'Late Log Adjustment', status: 'Rejected' }
        ];
        let requests = getStorageList(CORRECTION_REQUESTS_KEY, fallback);

        function render() {
            container.innerHTML = [
                '<div class="card border-0 shadow-sm mb-3 corr-req-submodule">',
                '  <div class="card-body">',
                '    <h6 class="mb-3"><i class="fas fa-pen-to-square text-primary me-2"></i>Submit New Correction Request</h6>',
                '    <div class="row g-2">',
                '      <div class="col-md-4"><input id="corrEmployee" class="form-control" placeholder="Employee name"></div>',
                '      <div class="col-md-5"><input id="corrIssue" class="form-control" placeholder="Issue description"></div>',
                '      <div class="col-md-3"><button id="corrAddBtn" class="btn btn-primary w-100">Add Request</button></div>',
                '    </div>',
                '  </div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-list-check text-primary me-2"></i>Correction Request Tracker</h5></div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>Request ID</th><th>Employee</th><th>Issue</th><th>Status</th></tr></thead>',
                '      <tbody>',
                requests.map(function (item) {
                    const badge = item.status === 'Approved'
                        ? 'bg-success-subtle text-success'
                        : item.status === 'Rejected'
                            ? 'bg-danger-subtle text-danger'
                            : 'bg-warning-subtle text-warning';
                    return '<tr><td>' + item.id + '</td><td>' + item.employee + '</td><td>' + item.issue + '</td><td><span class="badge ' + badge + '">' + item.status + '</span></td></tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            const addButton = document.getElementById('corrAddBtn');
            if (addButton) {
                addButton.addEventListener('click', function () {
                    const employee = (document.getElementById('corrEmployee').value || '').trim();
                    const issue = (document.getElementById('corrIssue').value || '').trim();
                    if (!employee || !issue) {
                        showCorrectionRequestsInfo('Incomplete Request', 'Enter both employee name and issue description before adding a request.');
                        return;
                    }

                    const nextNumber = 1000 + requests.length + 1;
                    requests.unshift({
                        id: 'CR-' + nextNumber,
                        employee: employee,
                        issue: issue,
                        status: 'Pending'
                    });
                    setStorageList(CORRECTION_REQUESTS_KEY, requests);
                    render();
                    showCorrectionRequestsInfo('Request Added', 'Correction request for ' + employee + ' has been filed.');
                });
            }
        }

        render();
    };
})(window.HRSubmodules);

(function () {
    var container = document.getElementById('tasSubmoduleContainer');
    var buttons = Array.prototype.slice.call(document.querySelectorAll('button[data-submodule]'));

    var rendererMap = {
        'Attendance Monitoring': 'renderAttendanceMonitoring',
        'Attendance Validation': 'renderAttendanceValidation',
        'Attendance Reports': 'renderAttendanceReports',
        'Correction Requests': 'renderCorrectionRequests'
    };

    function setActiveButton(activeName) {
        buttons.forEach(function (button) {
            button.classList.toggle('active', button.getAttribute('data-submodule') === activeName);
        });
    }

    function renderSubmodule(submoduleName) {
        if (!container) {
            return;
        }

        var rendererName = rendererMap[submoduleName];
        var renderer = rendererName && window.HRSubmodules ? window.HRSubmodules[rendererName] : null;

        if (typeof renderer === 'function') {
            renderer(container);
        } else {
            container.innerHTML = '<div class="alert alert-warning mb-0">Submodule renderer is not available.</div>';
        }

        setActiveButton(submoduleName);
    }

    buttons.forEach(function (button) {
        button.addEventListener('click', function () {
            renderSubmodule(button.getAttribute('data-submodule'));
        });
    });

    renderSubmodule('Attendance Monitoring');
})();
