
window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const CLAIMS_RECORDS_KEY = 'hospitalHrClaimsRecords';

    function ensureClaimSubmissionModalHost() {
        if (document.getElementById('claimSubmissionModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="claimSubmissionModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="claimSubmissionModalTitle">Claim Submission</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="claimSubmissionModalBody"></div>',
            '      <div class="modal-footer" id="claimSubmissionModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showClaimSubmissionInfo(title, message) {
        const modalEl = document.getElementById('claimSubmissionModal');
        const titleEl = document.getElementById('claimSubmissionModalTitle');
        const bodyEl = document.getElementById('claimSubmissionModalBody');
        const footerEl = document.getElementById('claimSubmissionModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    function defaultClaims() {
        return [
            { id: 'CLM-801', employee: 'Anna Santos', category: 'Medical', amount: 2500, date: '2026-02-25', notes: 'Outpatient consultation', status: 'Submitted', reimbursed: false },
            { id: 'CLM-802', employee: 'Jude Molina', category: 'Transportation', amount: 850, date: '2026-02-26', notes: 'Official field visit', status: 'Approved', reimbursed: true },
            { id: 'CLM-803', employee: 'Leah Gomez', category: 'Training', amount: 3200, date: '2026-02-28', notes: 'Certification course', status: 'Under Review', reimbursed: false }
        ];
    }

    function getStorageList(key, fallbackFn) {
        const raw = localStorage.getItem(key);
        const fallback = fallbackFn();
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderClaimSubmission = function (container) {
        ensureClaimSubmissionModalHost();

        let claims = getStorageList(CLAIMS_RECORDS_KEY, defaultClaims);

        function render() {
            container.innerHTML = [
                '<div class="card border-0 shadow-sm mb-3 claim-submission-submodule">',
                '  <div class="card-body">',
                '    <h6 class="mb-3"><i class="fas fa-file-circle-plus text-primary me-2"></i>Submit Claim Request</h6>',
                '    <div class="row g-2">',
                '      <div class="col-md-3"><input id="claimEmp" class="form-control" placeholder="Employee"></div>',
                '      <div class="col-md-2">',
                '        <select id="claimCategory" class="form-select">',
                '          <option>Medical</option><option>Transportation</option><option>Training</option><option>Meal</option><option>Other</option>',
                '        </select>',
                '      </div>',
                '      <div class="col-md-2"><input id="claimAmount" type="number" min="1" class="form-control" placeholder="Amount"></div>',
                '      <div class="col-md-2"><input id="claimDate" type="date" class="form-control"></div>',
                '      <div class="col-md-2"><input id="claimNotes" class="form-control" placeholder="Notes"></div>',
                '      <div class="col-md-1"><button id="claimAddBtn" class="btn btn-primary w-100">File</button></div>',
                '    </div>',
                '  </div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-receipt text-primary me-2"></i>Claim Submission Queue</h5></div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>ID</th><th>Employee</th><th>Category</th><th>Amount</th><th>Date</th><th>Status</th></tr></thead>',
                '      <tbody>',
                claims.slice(0, 8).map(function (item) {
                    const badge = item.status === 'Approved'
                        ? 'bg-success-subtle text-success'
                        : item.status === 'Rejected'
                            ? 'bg-danger-subtle text-danger'
                            : item.status === 'Under Review'
                                ? 'bg-info-subtle text-info'
                                : 'bg-warning-subtle text-warning';
                    return '<tr><td>' + item.id + '</td><td>' + item.employee + '</td><td>' + item.category + '</td><td>₱' + Number(item.amount).toLocaleString() + '</td><td>' + item.date + '</td><td><span class="badge ' + badge + '">' + item.status + '</span></td></tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            const addButton = document.getElementById('claimAddBtn');
            if (!addButton) {
                return;
            }

            addButton.addEventListener('click', function () {
                const employee = (document.getElementById('claimEmp').value || '').trim();
                const category = (document.getElementById('claimCategory').value || 'Other').trim();
                const amount = Number(document.getElementById('claimAmount').value || 0);
                const date = (document.getElementById('claimDate').value || '').trim();
                const notes = (document.getElementById('claimNotes').value || '').trim();

                if (!employee || !amount || !date || !notes) {
                    showClaimSubmissionInfo('Incomplete Claim', 'Provide employee, amount, date, and notes before filing a claim.');
                    return;
                }

                const nextNumber = 800 + claims.length + 1;
                claims.unshift({
                    id: 'CLM-' + nextNumber,
                    employee: employee,
                    category: category,
                    amount: amount,
                    date: date,
                    notes: notes,
                    status: 'Submitted',
                    reimbursed: false
                });

                setStorageList(CLAIMS_RECORDS_KEY, claims);
                render();
                showClaimSubmissionInfo('Claim Filed', 'Claim request for ' + employee + ' has been submitted successfully.');
            });
        }

        render();
    };
})(window.HRSubmodules);


window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const CLAIMS_RECORDS_KEY = 'hospitalHrClaimsRecords';

    function ensureClaimReviewModalHost() {
        if (document.getElementById('claimReviewModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="claimReviewModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="claimReviewModalTitle">Claim Review</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="claimReviewModalBody"></div>',
            '      <div class="modal-footer" id="claimReviewModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showClaimReviewModal(config) {
        const modalEl = document.getElementById('claimReviewModal');
        const titleEl = document.getElementById('claimReviewModalTitle');
        const bodyEl = document.getElementById('claimReviewModalBody');
        const footerEl = document.getElementById('claimReviewModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    function defaultClaims() {
        return [
            { id: 'CLM-801', employee: 'Anna Santos', category: 'Medical', amount: 2500, date: '2026-02-25', notes: 'Outpatient consultation', status: 'Submitted', reimbursed: false },
            { id: 'CLM-802', employee: 'Jude Molina', category: 'Transportation', amount: 850, date: '2026-02-26', notes: 'Official field visit', status: 'Approved', reimbursed: true },
            { id: 'CLM-803', employee: 'Leah Gomez', category: 'Training', amount: 3200, date: '2026-02-28', notes: 'Certification course', status: 'Under Review', reimbursed: false }
        ];
    }

    function getStorageList(key, fallbackFn) {
        const raw = localStorage.getItem(key);
        const fallback = fallbackFn();
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderClaimReview = function (container) {
        ensureClaimReviewModalHost();

        let claims = getStorageList(CLAIMS_RECORDS_KEY, defaultClaims);

        function render() {
            const reviewQueue = claims.filter(function (item) {
                return item.status === 'Submitted' || item.status === 'Under Review';
            });

            container.innerHTML = [
                '<div class="card border-0 shadow-sm claim-review-submodule">',
                '  <div class="card-header bg-white d-flex justify-content-between align-items-center">',
                '    <h5 class="mb-0"><i class="fas fa-clipboard-check text-primary me-2"></i>Claim Review Queue</h5>',
                '    <span class="badge bg-warning-subtle text-warning">' + reviewQueue.length + ' In Review</span>',
                '  </div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>ID</th><th>Employee</th><th>Category</th><th>Amount</th><th>Notes</th><th>Status</th><th>Action</th></tr></thead>',
                '      <tbody>',
                reviewQueue.map(function (item) {
                    return '<tr>'
                        + '<td>' + item.id + '</td>'
                        + '<td>' + item.employee + '</td>'
                        + '<td>' + item.category + '</td>'
                        + '<td>₱' + Number(item.amount).toLocaleString() + '</td>'
                        + '<td>' + item.notes + '</td>'
                        + '<td><span class="badge bg-info-subtle text-info">' + item.status + '</span></td>'
                        + '<td>'
                        + '<button class="btn btn-sm btn-outline-primary me-1" data-action="review" data-id="' + item.id + '">Mark Review</button>'
                        + '<button class="btn btn-sm btn-outline-success me-1" data-action="approve" data-id="' + item.id + '">Approve</button>'
                        + '<button class="btn btn-sm btn-outline-danger" data-action="reject" data-id="' + item.id + '">Reject</button>'
                        + '</td>'
                        + '</tr>';
                }).join(''),
                reviewQueue.length ? '' : '<tr><td colspan="7" class="text-center text-muted py-3">No claims for review.</td></tr>',
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            container.querySelectorAll('button[data-action]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const action = button.getAttribute('data-action');
                    const id = button.getAttribute('data-id');
                    const target = claims.find(function (item) { return item.id === id; });
                    if (!target) {
                        return;
                    }

                    const nextStatus = action === 'approve'
                        ? 'Approved'
                        : action === 'reject'
                            ? 'Rejected'
                            : 'Under Review';

                    showClaimReviewModal({
                        title: 'Update Claim Status',
                        message: 'Set claim ' + target.id + ' for ' + target.employee + ' to ' + nextStatus + '?',
                        footerHtml: [
                            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                            '<button type="button" class="btn btn-primary" id="confirmClaimReviewActionBtn">Confirm</button>'
                        ].join(''),
                        onShown: function (modal) {
                            const confirmBtn = document.getElementById('confirmClaimReviewActionBtn');
                            if (!confirmBtn) {
                                return;
                            }

                            confirmBtn.addEventListener('click', function () {
                                claims = claims.map(function (item) {
                                    if (item.id !== id) {
                                        return item;
                                    }

                                    return {
                                        id: item.id,
                                        employee: item.employee,
                                        category: item.category,
                                        amount: item.amount,
                                        date: item.date,
                                        notes: item.notes,
                                        status: nextStatus,
                                        reimbursed: item.reimbursed === true
                                    };
                                });

                                setStorageList(CLAIMS_RECORDS_KEY, claims);
                                modal.hide();
                                render();

                                showClaimReviewModal({
                                    title: 'Claim Updated',
                                    message: 'Claim ' + target.id + ' is now ' + nextStatus + '.'
                                });
                            }, { once: true });
                        }
                    });
                });
            });
        }

        render();
    };
})(window.HRSubmodules);


window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const CLAIMS_RECORDS_KEY = 'hospitalHrClaimsRecords';

    function ensureReimbursementProcessingModalHost() {
        if (document.getElementById('reimbursementProcessingModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="reimbursementProcessingModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="reimbursementProcessingModalTitle">Reimbursement Processing</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="reimbursementProcessingModalBody"></div>',
            '      <div class="modal-footer" id="reimbursementProcessingModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showReimbursementProcessingModal(config) {
        const modalEl = document.getElementById('reimbursementProcessingModal');
        const titleEl = document.getElementById('reimbursementProcessingModalTitle');
        const bodyEl = document.getElementById('reimbursementProcessingModalBody');
        const footerEl = document.getElementById('reimbursementProcessingModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    function defaultClaims() {
        return [
            { id: 'CLM-801', employee: 'Anna Santos', category: 'Medical', amount: 2500, date: '2026-02-25', notes: 'Outpatient consultation', status: 'Submitted', reimbursed: false },
            { id: 'CLM-802', employee: 'Jude Molina', category: 'Transportation', amount: 850, date: '2026-02-26', notes: 'Official field visit', status: 'Approved', reimbursed: true },
            { id: 'CLM-803', employee: 'Leah Gomez', category: 'Training', amount: 3200, date: '2026-02-28', notes: 'Certification course', status: 'Under Review', reimbursed: false }
        ];
    }

    function getStorageList(key, fallbackFn) {
        const raw = localStorage.getItem(key);
        const fallback = fallbackFn();
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderReimbursementProcessing = function (container) {
        ensureReimbursementProcessingModalHost();

        let claims = getStorageList(CLAIMS_RECORDS_KEY, defaultClaims);

        function render() {
            const approvedPending = claims.filter(function (item) {
                return item.status === 'Approved' && item.reimbursed !== true;
            });

            const processedAmount = claims
                .filter(function (item) { return item.reimbursed === true; })
                .reduce(function (sum, item) { return sum + Number(item.amount || 0); }, 0);

            container.innerHTML = [
                '<div class="row g-3 mb-3 reimbursement-processing-submodule">',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Approved Pending Payout</p><h5 class="mb-0">' + approvedPending.length + '</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Total Processed Amount</p><h5 class="mb-0">₱' + processedAmount.toLocaleString() + '</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Processing Queue</p><h5 class="mb-0">' + approvedPending.length + '</h5></div></div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-money-check-dollar text-primary me-2"></i>Reimbursement Processing</h5></div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>ID</th><th>Employee</th><th>Category</th><th>Amount</th><th>Status</th><th>Action</th></tr></thead>',
                '      <tbody>',
                approvedPending.map(function (item) {
                    return '<tr>'
                        + '<td>' + item.id + '</td>'
                        + '<td>' + item.employee + '</td>'
                        + '<td>' + item.category + '</td>'
                        + '<td>₱' + Number(item.amount).toLocaleString() + '</td>'
                        + '<td><span class="badge bg-success-subtle text-success">Approved</span></td>'
                        + '<td><button class="btn btn-sm btn-outline-primary" data-action="pay" data-id="' + item.id + '">Mark Paid</button></td>'
                        + '</tr>';
                }).join(''),
                approvedPending.length ? '' : '<tr><td colspan="6" class="text-center text-muted py-3">No approved claims waiting for payout.</td></tr>',
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            container.querySelectorAll('button[data-action="pay"]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const id = button.getAttribute('data-id');
                    const target = claims.find(function (item) { return item.id === id; });
                    if (!target) {
                        return;
                    }

                    showReimbursementProcessingModal({
                        title: 'Confirm Payout',
                        message: 'Mark claim ' + target.id + ' for ' + target.employee + ' as paid?',
                        footerHtml: [
                            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                            '<button type="button" class="btn btn-primary" id="confirmReimbursementPayoutBtn">Mark Paid</button>'
                        ].join(''),
                        onShown: function (modal) {
                            const confirmBtn = document.getElementById('confirmReimbursementPayoutBtn');
                            if (!confirmBtn) {
                                return;
                            }

                            confirmBtn.addEventListener('click', function () {
                                claims = claims.map(function (item) {
                                    if (item.id !== id) {
                                        return item;
                                    }
                                    return {
                                        id: item.id,
                                        employee: item.employee,
                                        category: item.category,
                                        amount: item.amount,
                                        date: item.date,
                                        notes: item.notes,
                                        status: item.status,
                                        reimbursed: true
                                    };
                                });

                                setStorageList(CLAIMS_RECORDS_KEY, claims);
                                modal.hide();
                                render();

                                showReimbursementProcessingModal({
                                    title: 'Payout Completed',
                                    message: 'Claim ' + target.id + ' has been marked as paid.'
                                });
                            }, { once: true });
                        }
                    });
                });
            });
        }

        render();
    };
})(window.HRSubmodules);


window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const CLAIMS_RECORDS_KEY = 'hospitalHrClaimsRecords';

    function defaultClaims() {
        return [
            { id: 'CLM-801', employee: 'Anna Santos', category: 'Medical', amount: 2500, date: '2026-02-25', notes: 'Outpatient consultation', status: 'Submitted', reimbursed: false },
            { id: 'CLM-802', employee: 'Jude Molina', category: 'Transportation', amount: 850, date: '2026-02-26', notes: 'Official field visit', status: 'Approved', reimbursed: true },
            { id: 'CLM-803', employee: 'Leah Gomez', category: 'Training', amount: 3200, date: '2026-02-28', notes: 'Certification course', status: 'Under Review', reimbursed: false }
        ];
    }

    function getStorageList(key, fallbackFn) {
        const raw = localStorage.getItem(key);
        const fallback = fallbackFn();
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
    }

    registry.renderClaimHistory = function (container) {
        const claims = getStorageList(CLAIMS_RECORDS_KEY, defaultClaims);

        const submitted = claims.filter(function (item) { return item.status === 'Submitted' || item.status === 'Under Review'; }).length;
        const approved = claims.filter(function (item) { return item.status === 'Approved'; }).length;
        const reimbursed = claims.filter(function (item) { return item.reimbursed === true; }).length;
        const totalAmount = claims.reduce(function (sum, item) { return sum + Number(item.amount || 0); }, 0);

        const rows = claims.map(function (item) {
            const statusBadge = item.status === 'Approved'
                ? 'bg-success-subtle text-success'
                : item.status === 'Rejected'
                    ? 'bg-danger-subtle text-danger'
                    : item.status === 'Under Review'
                        ? 'bg-info-subtle text-info'
                        : 'bg-warning-subtle text-warning';
            const payoutBadge = item.reimbursed === true
                ? '<span class="badge bg-success-subtle text-success">Paid</span>'
                : '<span class="badge bg-secondary-subtle text-secondary">Pending Payout</span>';

            return '<tr>'
                + '<td>' + item.id + '</td>'
                + '<td>' + item.employee + '</td>'
                + '<td>' + item.category + '</td>'
                + '<td>₱' + Number(item.amount).toLocaleString() + '</td>'
                + '<td><span class="badge ' + statusBadge + '">' + item.status + '</span></td>'
                + '<td>' + payoutBadge + '</td>'
                + '</tr>';
        }).join('');

        container.innerHTML = [
            '<div class="d-flex justify-content-between align-items-center mb-3 claim-history-submodule"><h6 class="mb-0"><i class="fas fa-clock-rotate-left text-primary me-2"></i>Claim History</h6></div>',
            '<div class="row g-3 mb-3">',
            '  <div class="col-md-3"><div class="border rounded-3 p-3"><p class="text-muted mb-1">For Processing</p><h5 class="mb-0">' + submitted + '</h5></div></div>',
            '  <div class="col-md-3"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Approved</p><h5 class="mb-0">' + approved + '</h5></div></div>',
            '  <div class="col-md-3"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Reimbursed</p><h5 class="mb-0">' + reimbursed + '</h5></div></div>',
            '  <div class="col-md-3"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Total Claimed</p><h5 class="mb-0">₱' + totalAmount.toLocaleString() + '</h5></div></div>',
            '</div>',
            '<div class="card border-0 shadow-sm">',
            '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-folder-open text-primary me-2"></i>Claims Master History</h5></div>',
            '  <div class="table-responsive">',
            '    <table class="table mb-0 align-middle">',
            '      <thead><tr><th>ID</th><th>Employee</th><th>Category</th><th>Amount</th><th>Status</th><th>Reimbursement</th></tr></thead>',
            '      <tbody>' + rows + '</tbody>',
            '    </table>',
            '  </div>',
            '</div>'
        ].join('');
    };
})(window.HRSubmodules);

(function () {
    var container = document.getElementById('carSubmoduleContainer');
    var buttons = Array.prototype.slice.call(document.querySelectorAll('button[data-submodule]'));

    var rendererMap = {
        'Claim Submission': 'renderClaimSubmission',
        'Claim Review': 'renderClaimReview',
        'Reimbursement Processing': 'renderReimbursementProcessing',
        'Claim History': 'renderClaimHistory'
    };

    function setActiveButton(activeName) {
        buttons.forEach(function (button) {
            button.classList.toggle('active', button.getAttribute('data-submodule') === activeName);
        });
    }

    function renderSubmodule(submoduleName) {
        if (!container) {
            return;
        }

        var rendererName = rendererMap[submoduleName];
        var renderer = rendererName && window.HRSubmodules ? window.HRSubmodules[rendererName] : null;

        if (typeof renderer === 'function') {
            renderer(container);
        } else {
            container.innerHTML = '<div class="alert alert-warning mb-0">Submodule renderer is not available.</div>';
        }

        setActiveButton(submoduleName);
    }

    buttons.forEach(function (button) {
        button.addEventListener('click', function () {
            renderSubmodule(button.getAttribute('data-submodule'));
        });
    });

    if (container && buttons.length) {
        renderSubmodule('Claim Submission');
    }
})();
