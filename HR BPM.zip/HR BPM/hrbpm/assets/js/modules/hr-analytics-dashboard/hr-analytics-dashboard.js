
window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const ANALYTICS_KEY = 'hospitalHrAnalyticsMetrics';

    function ensureWorkforceReportsModalHost() {
        if (document.getElementById('workforceReportsModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="workforceReportsModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="workforceReportsModalTitle">Workforce Reports</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="workforceReportsModalBody"></div>',
            '      <div class="modal-footer" id="workforceReportsModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showWorkforceReportsInfo(title, message) {
        const modalEl = document.getElementById('workforceReportsModal');
        const titleEl = document.getElementById('workforceReportsModalTitle');
        const bodyEl = document.getElementById('workforceReportsModalBody');
        const footerEl = document.getElementById('workforceReportsModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    function defaultAnalytics() {
        return [
            { department: 'Human Resources', headcount: 42, active: 40, attrition: 2.4, attendance: 95, performance: 4.2 },
            { department: 'Finance', headcount: 36, active: 34, attrition: 3.1, attendance: 93, performance: 4.0 },
            { department: 'Operations', headcount: 88, active: 84, attrition: 4.7, attendance: 91, performance: 3.8 },
            { department: 'Nursing', headcount: 82, active: 79, attrition: 3.5, attendance: 94, performance: 4.3 }
        ];
    }

    function getStorageList(key, fallbackFn) {
        const raw = localStorage.getItem(key);
        const fallback = fallbackFn();
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderWorkforceReports = function (container) {
        ensureWorkforceReportsModalHost();

        let metrics = getStorageList(ANALYTICS_KEY, defaultAnalytics);

        function render() {
            const totalHeadcount = metrics.reduce(function (sum, item) { return sum + Number(item.headcount || 0); }, 0);
            const totalActive = metrics.reduce(function (sum, item) { return sum + Number(item.active || 0); }, 0);

            container.innerHTML = [
                '<div class="card border-0 shadow-sm mb-3 workforce-reports-submodule">',
                '  <div class="card-body">',
                '    <h6 class="mb-3"><i class="fas fa-users-viewfinder text-primary me-2"></i>Add Workforce Snapshot</h6>',
                '    <div class="row g-2">',
                '      <div class="col-md-3"><input id="wfDept" class="form-control" placeholder="Department"></div>',
                '      <div class="col-md-2"><input id="wfHeadcount" type="number" min="1" class="form-control" placeholder="Headcount"></div>',
                '      <div class="col-md-2"><input id="wfActive" type="number" min="0" class="form-control" placeholder="Active"></div>',
                '      <div class="col-md-2"><input id="wfAttendance" type="number" min="0" max="100" class="form-control" placeholder="Attendance %"></div>',
                '      <div class="col-md-2"><input id="wfPerformance" type="number" min="1" max="5" step="0.1" class="form-control" placeholder="Perf (1-5)"></div>',
                '      <div class="col-md-1"><button id="wfAddBtn" class="btn btn-primary w-100">Add</button></div>',
                '    </div>',
                '  </div>',
                '</div>',
                '<div class="row g-3 mb-3">',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Departments</p><h5 class="mb-0">' + metrics.length + '</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Total Headcount</p><h5 class="mb-0">' + totalHeadcount + '</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Active Employees</p><h5 class="mb-0">' + totalActive + '</h5></div></div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-table text-primary me-2"></i>Workforce Reports</h5></div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>Department</th><th>Headcount</th><th>Active</th><th>Attendance</th><th>Attrition</th><th>Performance</th></tr></thead>',
                '      <tbody>',
                metrics.map(function (item) {
                    return '<tr>'
                        + '<td>' + item.department + '</td>'
                        + '<td>' + item.headcount + '</td>'
                        + '<td>' + item.active + '</td>'
                        + '<td>' + item.attendance + '%</td>'
                        + '<td>' + Number(item.attrition || 0).toFixed(1) + '%</td>'
                        + '<td>' + Number(item.performance || 0).toFixed(1) + '</td>'
                        + '</tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            const addButton = document.getElementById('wfAddBtn');
            if (!addButton) {
                return;
            }

            addButton.addEventListener('click', function () {
                const department = (document.getElementById('wfDept').value || '').trim();
                const headcount = Number(document.getElementById('wfHeadcount').value || 0);
                const active = Number(document.getElementById('wfActive').value || 0);
                const attendance = Number(document.getElementById('wfAttendance').value || 0);
                const performance = Number(document.getElementById('wfPerformance').value || 0);

                if (!department || !headcount || !attendance || !performance) {
                    showWorkforceReportsInfo('Incomplete Snapshot', 'Department, headcount, attendance, and performance are required.');
                    return;
                }

                metrics.unshift({
                    department: department,
                    headcount: headcount,
                    active: active > headcount ? headcount : active,
                    attendance: attendance,
                    attrition: 0,
                    performance: performance
                });

                setStorageList(ANALYTICS_KEY, metrics);
                render();
                showWorkforceReportsInfo('Snapshot Added', 'Workforce snapshot for ' + department + ' has been added.');
            });
        }

        render();
    };
})(window.HRSubmodules);


window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const ANALYTICS_KEY = 'hospitalHrAnalyticsMetrics';

    function ensureTurnoverAnalysisModalHost() {
        if (document.getElementById('turnoverAnalysisModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="turnoverAnalysisModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="turnoverAnalysisModalTitle">Turnover Analysis</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="turnoverAnalysisModalBody"></div>',
            '      <div class="modal-footer" id="turnoverAnalysisModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showTurnoverAnalysisModal(config) {
        const modalEl = document.getElementById('turnoverAnalysisModal');
        const titleEl = document.getElementById('turnoverAnalysisModalTitle');
        const bodyEl = document.getElementById('turnoverAnalysisModalBody');
        const footerEl = document.getElementById('turnoverAnalysisModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    function defaultAnalytics() {
        return [
            { department: 'Human Resources', headcount: 42, active: 40, attrition: 2.4, attendance: 95, performance: 4.2 },
            { department: 'Finance', headcount: 36, active: 34, attrition: 3.1, attendance: 93, performance: 4.0 },
            { department: 'Operations', headcount: 88, active: 84, attrition: 4.7, attendance: 91, performance: 3.8 },
            { department: 'Nursing', headcount: 82, active: 79, attrition: 3.5, attendance: 94, performance: 4.3 }
        ];
    }

    function getStorageList(key, fallbackFn) {
        const raw = localStorage.getItem(key);
        const fallback = fallbackFn();
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderTurnoverAnalysis = function (container) {
        ensureTurnoverAnalysisModalHost();

        let metrics = getStorageList(ANALYTICS_KEY, defaultAnalytics);

        function render() {
            const highRisk = metrics.filter(function (item) { return Number(item.attrition || 0) >= 4; }).length;
            const avgAttrition = metrics.length
                ? metrics.reduce(function (sum, item) { return sum + Number(item.attrition || 0); }, 0) / metrics.length
                : 0;

            container.innerHTML = [
                '<div class="row g-3 mb-3 turnover-analysis-submodule">',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Avg Attrition</p><h5 class="mb-0">' + avgAttrition.toFixed(2) + '%</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">High Risk Departments</p><h5 class="mb-0">' + highRisk + '</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Retention Focus</p><h5 class="mb-0">Q2 2026</h5></div></div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-arrow-trend-down text-primary me-2"></i>Turnover Analysis</h5></div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>Department</th><th>Headcount</th><th>Active</th><th>Attrition</th><th>Risk</th><th>Action</th></tr></thead>',
                '      <tbody>',
                metrics.map(function (item) {
                    const risk = Number(item.attrition || 0) >= 4 ? 'High' : Number(item.attrition || 0) >= 3 ? 'Medium' : 'Low';
                    const riskBadge = risk === 'High'
                        ? 'bg-danger-subtle text-danger'
                        : risk === 'Medium'
                            ? 'bg-warning-subtle text-warning'
                            : 'bg-success-subtle text-success';

                    return '<tr>'
                        + '<td>' + item.department + '</td>'
                        + '<td>' + item.headcount + '</td>'
                        + '<td>' + item.active + '</td>'
                        + '<td>' + Number(item.attrition || 0).toFixed(1) + '%</td>'
                        + '<td><span class="badge ' + riskBadge + '">' + risk + '</span></td>'
                        + '<td><button class="btn btn-sm btn-outline-primary" data-action="improve" data-dept="' + item.department + '">Improve Retention</button></td>'
                        + '</tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            container.querySelectorAll('button[data-action="improve"]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const department = button.getAttribute('data-dept');
                    const target = metrics.find(function (item) { return item.department === department; });
                    if (!target) {
                        return;
                    }

                    showTurnoverAnalysisModal({
                        title: 'Apply Retention Action',
                        message: 'Apply retention improvement for ' + target.department + ' and reduce attrition by 0.3%?',
                        footerHtml: [
                            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                            '<button type="button" class="btn btn-primary" id="confirmTurnoverImproveBtn">Apply</button>'
                        ].join(''),
                        onShown: function (modal) {
                            const confirmBtn = document.getElementById('confirmTurnoverImproveBtn');
                            if (!confirmBtn) {
                                return;
                            }

                            confirmBtn.addEventListener('click', function () {
                                metrics = metrics.map(function (item) {
                                    if (item.department !== department) {
                                        return item;
                                    }

                                    const nextAttrition = Number(item.attrition || 0) - 0.3;
                                    return {
                                        department: item.department,
                                        headcount: item.headcount,
                                        active: item.active,
                                        attrition: nextAttrition < 0 ? 0 : Number(nextAttrition.toFixed(1)),
                                        attendance: item.attendance,
                                        performance: item.performance
                                    };
                                });

                                setStorageList(ANALYTICS_KEY, metrics);
                                modal.hide();
                                render();

                                showTurnoverAnalysisModal({
                                    title: 'Retention Action Applied',
                                    message: target.department + ' attrition metric has been updated.'
                                });
                            }, { once: true });
                        }
                    });
                });
            });
        }

        render();
    };
})(window.HRSubmodules);


window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const ANALYTICS_KEY = 'hospitalHrAnalyticsMetrics';

    function ensureAttendanceAnalyticsModalHost() {
        if (document.getElementById('attendanceAnalyticsModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="attendanceAnalyticsModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="attendanceAnalyticsModalTitle">Attendance Analytics</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="attendanceAnalyticsModalBody"></div>',
            '      <div class="modal-footer" id="attendanceAnalyticsModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showAttendanceAnalyticsModal(config) {
        const modalEl = document.getElementById('attendanceAnalyticsModal');
        const titleEl = document.getElementById('attendanceAnalyticsModalTitle');
        const bodyEl = document.getElementById('attendanceAnalyticsModalBody');
        const footerEl = document.getElementById('attendanceAnalyticsModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    function defaultAnalytics() {
        return [
            { department: 'Human Resources', headcount: 42, active: 40, attrition: 2.4, attendance: 95, performance: 4.2 },
            { department: 'Finance', headcount: 36, active: 34, attrition: 3.1, attendance: 93, performance: 4.0 },
            { department: 'Operations', headcount: 88, active: 84, attrition: 4.7, attendance: 91, performance: 3.8 },
            { department: 'Nursing', headcount: 82, active: 79, attrition: 3.5, attendance: 94, performance: 4.3 }
        ];
    }

    function getStorageList(key, fallbackFn) {
        const raw = localStorage.getItem(key);
        const fallback = fallbackFn();
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderAttendanceAnalytics = function (container) {
        ensureAttendanceAnalyticsModalHost();

        let metrics = getStorageList(ANALYTICS_KEY, defaultAnalytics);

        function render() {
            const averageAttendance = metrics.length
                ? metrics.reduce(function (sum, item) { return sum + Number(item.attendance || 0); }, 0) / metrics.length
                : 0;

            container.innerHTML = [
                '<div class="card border-0 shadow-sm mb-3 attendance-analytics-submodule">',
                '  <div class="card-body">',
                '    <h6 class="mb-3"><i class="fas fa-user-check text-primary me-2"></i>Attendance Analytics Tuning</h6>',
                '    <p class="text-muted mb-0">Use action buttons to simulate attendance interventions by department.</p>',
                '  </div>',
                '</div>',
                '<div class="row g-3 mb-3">',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Average Attendance</p><h5 class="mb-0">' + averageAttendance.toFixed(2) + '%</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Best Department</p><h5 class="mb-0">' + getBestDepartment(metrics) + '</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Watchlist</p><h5 class="mb-0">' + metrics.filter(function (item) { return Number(item.attendance || 0) < 92; }).length + '</h5></div></div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-clock text-primary me-2"></i>Attendance Analytics</h5></div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>Department</th><th>Attendance</th><th>Active</th><th>Headcount</th><th>Action</th></tr></thead>',
                '      <tbody>',
                metrics.map(function (item) {
                    return '<tr>'
                        + '<td>' + item.department + '</td>'
                        + '<td>' + Number(item.attendance || 0).toFixed(1) + '%</td>'
                        + '<td>' + item.active + '</td>'
                        + '<td>' + item.headcount + '</td>'
                        + '<td><button class="btn btn-sm btn-outline-primary" data-action="boost" data-dept="' + item.department + '">Boost +1%</button></td>'
                        + '</tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            container.querySelectorAll('button[data-action="boost"]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const department = button.getAttribute('data-dept');
                    const target = metrics.find(function (item) { return item.department === department; });
                    if (!target) {
                        return;
                    }

                    showAttendanceAnalyticsModal({
                        title: 'Boost Attendance',
                        message: 'Apply attendance intervention for ' + target.department + ' and boost by 1%?',
                        footerHtml: [
                            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                            '<button type="button" class="btn btn-primary" id="confirmAttendanceBoostBtn">Apply</button>'
                        ].join(''),
                        onShown: function (modal) {
                            const confirmBtn = document.getElementById('confirmAttendanceBoostBtn');
                            if (!confirmBtn) {
                                return;
                            }

                            confirmBtn.addEventListener('click', function () {
                                metrics = metrics.map(function (item) {
                                    if (item.department !== department) {
                                        return item;
                                    }

                                    const nextAttendance = Number(item.attendance || 0) + 1;
                                    return {
                                        department: item.department,
                                        headcount: item.headcount,
                                        active: item.active,
                                        attrition: item.attrition,
                                        attendance: nextAttendance > 100 ? 100 : Number(nextAttendance.toFixed(1)),
                                        performance: item.performance
                                    };
                                });

                                setStorageList(ANALYTICS_KEY, metrics);
                                modal.hide();
                                render();

                                showAttendanceAnalyticsModal({
                                    title: 'Attendance Updated',
                                    message: target.department + ' attendance metric has been updated.'
                                });
                            }, { once: true });
                        }
                    });
                });
            });
        }

        function getBestDepartment(metrics) {
            if (!metrics.length) {
                return 'N/A';
            }
            return metrics.slice().sort(function (a, b) {
                return Number(b.attendance || 0) - Number(a.attendance || 0);
            })[0].department;
        }

        render();
    };
})(window.HRSubmodules);


window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const ANALYTICS_KEY = 'hospitalHrAnalyticsMetrics';

    function ensurePerformanceMetricsModalHost() {
        if (document.getElementById('performanceMetricsModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="performanceMetricsModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="performanceMetricsModalTitle">Performance Metrics</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="performanceMetricsModalBody"></div>',
            '      <div class="modal-footer" id="performanceMetricsModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showPerformanceMetricsModal(config) {
        const modalEl = document.getElementById('performanceMetricsModal');
        const titleEl = document.getElementById('performanceMetricsModalTitle');
        const bodyEl = document.getElementById('performanceMetricsModalBody');
        const footerEl = document.getElementById('performanceMetricsModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    function defaultAnalytics() {
        return [
            { department: 'Human Resources', headcount: 42, active: 40, attrition: 2.4, attendance: 95, performance: 4.2 },
            { department: 'Finance', headcount: 36, active: 34, attrition: 3.1, attendance: 93, performance: 4.0 },
            { department: 'Operations', headcount: 88, active: 84, attrition: 4.7, attendance: 91, performance: 3.8 },
            { department: 'Nursing', headcount: 82, active: 79, attrition: 3.5, attendance: 94, performance: 4.3 }
        ];
    }

    function getStorageList(key, fallbackFn) {
        const raw = localStorage.getItem(key);
        const fallback = fallbackFn();
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderPerformanceMetrics = function (container) {
        ensurePerformanceMetricsModalHost();

        let metrics = getStorageList(ANALYTICS_KEY, defaultAnalytics);

        function render() {
            const avgPerformance = metrics.length
                ? metrics.reduce(function (sum, item) { return sum + Number(item.performance || 0); }, 0) / metrics.length
                : 0;

            const highest = metrics.slice().sort(function (a, b) {
                return Number(b.performance || 0) - Number(a.performance || 0);
            })[0];

            container.innerHTML = [
                '<div class="d-flex justify-content-between align-items-center mb-3 performance-metrics-submodule"><h6 class="mb-0"><i class="fas fa-medal text-primary me-2"></i>Performance Metrics</h6></div>',
                '<div class="row g-3 mb-3">',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Average Score</p><h5 class="mb-0">' + avgPerformance.toFixed(2) + '/5</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Top Department</p><h5 class="mb-0">' + (highest ? highest.department : 'N/A') + '</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Improvement Queue</p><h5 class="mb-0">' + metrics.filter(function (item) { return Number(item.performance || 0) < 4; }).length + '</h5></div></div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-chart-line text-primary me-2"></i>Department Performance Scorecard</h5></div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>Department</th><th>Performance</th><th>Attendance</th><th>Attrition</th><th>Action</th></tr></thead>',
                '      <tbody>',
                metrics.map(function (item) {
                    return '<tr>'
                        + '<td>' + item.department + '</td>'
                        + '<td>' + Number(item.performance || 0).toFixed(1) + '/5</td>'
                        + '<td>' + Number(item.attendance || 0).toFixed(1) + '%</td>'
                        + '<td>' + Number(item.attrition || 0).toFixed(1) + '%</td>'
                        + '<td><button class="btn btn-sm btn-outline-primary" data-action="raise" data-dept="' + item.department + '">Raise +0.1</button></td>'
                        + '</tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            container.querySelectorAll('button[data-action="raise"]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const department = button.getAttribute('data-dept');
                    const target = metrics.find(function (item) { return item.department === department; });
                    if (!target) {
                        return;
                    }

                    showPerformanceMetricsModal({
                        title: 'Raise Performance Score',
                        message: 'Increase performance score for ' + target.department + ' by 0.1?',
                        footerHtml: [
                            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                            '<button type="button" class="btn btn-primary" id="confirmPerformanceRaiseBtn">Apply</button>'
                        ].join(''),
                        onShown: function (modal) {
                            const confirmBtn = document.getElementById('confirmPerformanceRaiseBtn');
                            if (!confirmBtn) {
                                return;
                            }

                            confirmBtn.addEventListener('click', function () {
                                metrics = metrics.map(function (item) {
                                    if (item.department !== department) {
                                        return item;
                                    }

                                    const nextPerformance = Number(item.performance || 0) + 0.1;
                                    return {
                                        department: item.department,
                                        headcount: item.headcount,
                                        active: item.active,
                                        attrition: item.attrition,
                                        attendance: item.attendance,
                                        performance: nextPerformance > 5 ? 5 : Number(nextPerformance.toFixed(1))
                                    };
                                });

                                setStorageList(ANALYTICS_KEY, metrics);
                                modal.hide();
                                render();

                                showPerformanceMetricsModal({
                                    title: 'Performance Updated',
                                    message: target.department + ' performance metric has been updated.'
                                });
                            }, { once: true });
                        }
                    });
                });
            });
        }

        render();
    };
})(window.HRSubmodules);

(function () {
    var container = document.getElementById('hradSubmoduleContainer');
    var buttons = Array.prototype.slice.call(document.querySelectorAll('button[data-submodule]'));

    var rendererMap = {
        'Workforce Reports': 'renderWorkforceReports',
        'Turnover Analysis': 'renderTurnoverAnalysis',
        'Attendance Analytics': 'renderAttendanceAnalytics',
        'Performance Metrics': 'renderPerformanceMetrics'
    };

    function setActiveButton(activeName) {
        buttons.forEach(function (button) {
            button.classList.toggle('active', button.getAttribute('data-submodule') === activeName);
        });
    }

    function renderSubmodule(submoduleName) {
        if (!container) {
            return;
        }

        var rendererName = rendererMap[submoduleName];
        var renderer = rendererName && window.HRSubmodules ? window.HRSubmodules[rendererName] : null;

        if (typeof renderer === 'function') {
            renderer(container);
        } else {
            container.innerHTML = '<div class="alert alert-warning mb-0">Submodule renderer is not available.</div>';
        }

        setActiveButton(submoduleName);
    }

    buttons.forEach(function (button) {
        button.addEventListener('click', function () {
            renderSubmodule(button.getAttribute('data-submodule'));
        });
    });

    if (container && buttons.length) {
        renderSubmodule('Workforce Reports');
    }
})();
