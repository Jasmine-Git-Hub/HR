(function () {
    'use strict';

    let activeSubmoduleName = '';
    let dashboardRealtimeTimer = null;

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    function init() {
        initRoleDashboard();
        initRealtimeProfileSync();
        initRealtimeDashboardSync();
        initSidebar();
        initSidebarNavigation();
        ensureDashboardInfoModalHost();
        initSearch();
        initActionButtons();
        initLogout();
    }

    function initRealtimeProfileSync() {
        window.addEventListener('storage', function (event) {
            if (!event || !event.key) {
                return;
            }

            if (event.key === 'hospitalHrEmployeeId') {
                initRoleDashboard();
            }

            if (event.key.indexOf('hospitalHr') === 0) {
                updateDashboardFromModuleData();
            }
        });

        document.addEventListener('visibilitychange', function () {
            if (!document.hidden) {
                initRoleDashboard();
                updateDashboardFromModuleData();
            }
        });
    }

    function initRealtimeDashboardSync() {
        updateDashboardFromModuleData();

        if (dashboardRealtimeTimer) {
            window.clearInterval(dashboardRealtimeTimer);
        }

        dashboardRealtimeTimer = window.setInterval(function () {
            updateDashboardFromModuleData();
        }, 2000);
    }

    function updateDashboardFromModuleData() {
        // 1. SAFE DATA FETCHING (Existing + New ESS Modules)
        const employees = getStorageList('hospitalHrHcmEmployees');
        const internalRecognitions = getStorageList('hospitalHrRecognitions');
        const officialCommendations = getStorageList('hospitalHrCommendations');
        const skillInventory = getStorageList('hospitalHrSkillInventory');
        const probationEvals = getStorageList('hospitalHrProbationEvals');

        // ESS & Request Data
        const recentActivities = getStorageList('hospitalHrRecentActivities');
        const employeeId = localStorage.getItem('hospitalHrEmployeeId') || "EMP-2024-001";

        // Learning & Compliance Module Data
        const courseCatalog = getStorageList('hospitalHrCourses');
        const assignedCourses = getStorageList('hospitalHrAssignedCourses');
        const completions = getStorageList('hospitalHrCompletions');
        const licenseVault = getStorageList('hospitalHrLicenseVault');

        // Training Workflow Integration Data
        const trainingPrograms = getStorageList('hospitalHrTrainingPrograms');
        const trainingSchedule = getStorageList('hospitalHrTrainingSchedule');
        const trainingAttendance = getStorageList('hospitalHrAttendance');
        const trainingEvaluations = getStorageList('hospitalHrEvaluations');

        // Succession Planning Module Data
        const positionPlanning = getStorageList('hospitalHrPositionPlanning');
        const successorIdentifications = getStorageList('hospitalHrSuccessors');
        const readinessAssessments = getStorageList('hospitalHrReadiness');

        // 2. RECRUITMENT DATA
        let jobPostings = [];
        try {
            const storedJobs = localStorage.getItem('hospitalHrJobPostings');
            jobPostings = storedJobs ? JSON.parse(storedJobs) : [];
        } catch (e) { jobPostings = []; }

        // 3. CALCULATIONS
        const totalEmployees = employees.length;
        
        // Find current user for Profile Syncing
        const currentUser = employees.find(e => e.id === employeeId);
        
        // Integration Logic
        const activeLearners = assignedCourses.filter(a => a.status === 'In Progress').length;
        
        // Calculate Compliance Rate
        const totalCerts = licenseVault.length;
        const expiredCerts = licenseVault.filter(c => c.status === 'Expired').length;
        const activeCerts = totalCerts - expiredCerts;
        const complianceRate = totalCerts > 0 ? Math.round((activeCerts / totalCerts) * 100) : 100;

        // Training Workflow Calculations
        const activePrograms = trainingPrograms.filter(p => p.status === 'In Progress').length;
        const upcomingSessions = trainingSchedule.length;
        
        const totalRating = trainingEvaluations.reduce((acc, curr) => acc + (curr.rating || 0), 0);
        const avgSatisfaction = trainingEvaluations.length > 0 
            ? (totalRating / trainingEvaluations.length).toFixed(1) 
            : "0.0";

        // Succession Planning Calculations
        const criticalPositionsCount = positionPlanning.filter(p => p.priority === 'High' || p.isCritical === true).length;
        const identifiedSuccessorsCount = successorIdentifications.length;
        
        const readyNowCount = readinessAssessments.filter(r => r.status === 'Ready').length;
        const talentReadinessRate = readinessAssessments.length > 0 
            ? Math.round((readyNowCount / readinessAssessments.length) * 100) 
            : 0;

        // 4. UI UPDATES (Stat Cards)
        setText('statLabel1', 'Total Employees');
        setText('statValue1', String(totalEmployees));

        const workflowSummary = collectWorkflowSummary();

        setText('statLabel2', 'Open Vacancies');
        setText('statValue2', String(workflowSummary.openVacancies));

        setText('statLabel3', 'Pending Requests'); 
        // Sync with Submit Requests module
        const pendingReqs = workflowSummary.pendingItems;
        setText('statValue3', String(pendingReqs));

        setText('statLabel4', 'Talent Readiness');
        setText('statValue4', talentReadinessRate + '%');

        // 5. ESS WORKFLOW SYNC (Navbar & Greetings)
        if (currentUser) {
            // Update Navbar name real-time when "Update Personal Info" is saved
            setText('navbarRoleText', currentUser.name);
            setText('sidebarUserName', currentUser.name);
            
            // Update Avatars if name changed
            const avatarUrl = 'https://ui-avatars.com/api/?name=' + encodeURIComponent(currentUser.name) + '&background=0D6EFD&color=fff&bold=true';
            const navAv = document.getElementById('navbarAvatar');
            const sideAv = document.getElementById('sidebarAvatar');
            if (navAv) navAv.src = avatarUrl;
            if (sideAv) sideAv.src = avatarUrl;
        }

        // 6. SECTION METRICS (Smooth Workflow Integration)
        
        // 'attendance' section: Shows live Request Status
        setSectionMetric('attendance', 0, 'Recent Requests', recentActivities.length);
        setSectionMetric('attendance', 1, 'In-Training', activeLearners);
        setSectionMetric('attendance', 2, 'Potential Successors', identifiedSuccessorsCount);

        // 'documents' section: Records & Compliance
        setSectionMetric('documents', 0, 'Critical Positions', criticalPositionsCount);
        setSectionMetric('documents', 1, 'Compliance Rate', complianceRate + '%');
        setSectionMetric('documents', 2, 'Avg Satisfaction', avgSatisfaction + '/5');

        // 7. VISUAL FEEDBACK
        const readinessEl = document.getElementById('statValue4');
        if (readinessEl) {
            readinessEl.style.color = (talentReadinessRate < 70) ? "#dc3545" : "var(--primary-color)";
        }

        renderDashboardGraph({
            totalEmployees: totalEmployees,
            openVacancies: workflowSummary.openVacancies,
            pendingRequests: pendingReqs,
            inTraining: activeLearners,
            complianceRate: complianceRate,
            talentReadinessRate: talentReadinessRate
        });

    }

    function getStorageList(key) {
    const raw = localStorage.getItem(key);
    if (!raw) return [];

    try {
        const parsed = JSON.parse(raw);
        return Array.isArray(parsed) ? parsed : [];
    } catch (error) {
        console.error("Error parsing storage key: " + key, error);
        return [];
    }
}

    function collectWorkflowSummary() {
        let pendingItems = 0;
        let openVacancies = 0;

        for (let i = 0; i < localStorage.length; i += 1) {
            const key = localStorage.key(i);
            if (!key || (key.indexOf('hospitalHr') !== 0 && key !== 'hrCandidates')) {
                continue;
            }

            const records = getStorageList(key);
            if (!records.length) {
                continue;
            }

            const keyLower = key.toLowerCase();
            const vacancySource = keyLower.indexOf('job') !== -1 || keyLower.indexOf('vacancy') !== -1;

            records.forEach(function (record) {
                const status = getRecordStatus(record);

                if (isPendingStatus(status)) {
                    pendingItems += 1;
                }

                if (vacancySource && status === 'active') {
                    openVacancies += 1;
                }
            });
        }

        return {
            pendingItems: pendingItems,
            openVacancies: openVacancies
        };
    }

    function getRecordStatus(record) {
        if (!record || typeof record !== 'object') {
            return '';
        }

        const statusCandidates = [
            record.status,
            record.claimStatus,
            record.workflowStatus,
            record.approvalStatus,
            record.state,
            record.stage
        ];

        for (let i = 0; i < statusCandidates.length; i += 1) {
            const candidate = statusCandidates[i];
            if (typeof candidate === 'string' && candidate.trim().length > 0) {
                return candidate.trim().toLowerCase();
            }
        }

        return '';
    }

    function isPendingStatus(status) {
        return /(pending|for review|under review|submitted|new|draft|queued|processing)/.test(status);
    }

    function setText(elementId, value) {
        const element = document.getElementById(elementId);
        if (element) {
            element.textContent = value;
        }
    }

    function renderDashboardGraph(summary) {
        const countValues = [summary.totalEmployees, summary.openVacancies, summary.pendingRequests, summary.inTraining]
            .map(function (value) { return Number(value) || 0; });
        const maxCount = Math.max.apply(null, countValues.concat([1]));

        setGraphBar('graphEmployeesBar', 'graphEmployeesValue', summary.totalEmployees, Math.round((countValues[0] / maxCount) * 100), false);
        setGraphBar('graphVacanciesBar', 'graphVacanciesValue', summary.openVacancies, Math.round((countValues[1] / maxCount) * 100), false);
        setGraphBar('graphPendingBar', 'graphPendingValue', summary.pendingRequests, Math.round((countValues[2] / maxCount) * 100), false);
        setGraphBar('graphTrainingBar', 'graphTrainingValue', summary.inTraining, Math.round((countValues[3] / maxCount) * 100), false);

        setGraphBar('graphComplianceBar', 'graphComplianceValue', summary.complianceRate, summary.complianceRate, true);
        setGraphBar('graphReadinessBar', 'graphReadinessValue', summary.talentReadinessRate, summary.talentReadinessRate, true);
    }

    function setGraphBar(barId, valueId, rawValue, percentWidth, isPercent) {
        const bar = document.getElementById(barId);
        const value = document.getElementById(valueId);
        const width = Math.max(0, Math.min(100, Number(percentWidth) || 0));

        if (bar) {
            bar.style.width = width + '%';
            bar.setAttribute('aria-valuenow', String(width));
        }

        if (value) {
            value.textContent = isPercent ? (String(rawValue) + '%') : String(rawValue);
        }
    }

    function setSectionMetric(sectionId, index, label, value) {
        const section = document.getElementById(sectionId);
        if (!section) {
            return;
        }

        const metricRows = section.querySelectorAll('.card-body p');
        if (!metricRows[index]) {
            return;
        }

        const labelEl = metricRows[index].querySelector('.metric-label');
        if (labelEl && typeof label === 'string') {
            labelEl.textContent = label;
        }

        const strong = metricRows[index].querySelector('strong');
        if (strong) {
            strong.textContent = String(value);
        }
    }

    function setProgress(barId, labelId, value) {
        const normalized = Math.max(0, Math.min(100, Number(value) || 0));
        const bar = document.getElementById(barId);
        const label = document.getElementById(labelId);

        if (bar) {
            bar.style.width = normalized + '%';
            bar.setAttribute('aria-valuenow', String(normalized));
        }

        if (label) {
            label.textContent = normalized + '%';
        }
    }

    function initRoleDashboard() {
        const selectedConfig = {
            roleName: 'Hospital HR',
            subtitle: 'Manage workforce, operations, and employee lifecycle in one place.',
            sidebarModules: [
                { label: 'Dashboard', target: 'dashboard.html', icon: 'fa-gauge' },
                { type: 'divider', label: 'HR 1', caption: 'Talent Acquisition & Early Engagement' },
                { 
                    label: 'Applicant Management', 
                    target: 'modules/applicant-management.html', 
                    icon: 'fa-users', 
                    submodules: [
                        { label: 'Applicant List', target: '#' },
                        { label: 'Application Tracking', target: '#' },
                        { label: 'Interview Scheduling', target: '#' },
                        { label: 'Applicant Status Monitoring', target: '#' }
                    ]
                },
                { 
                    label: 'Recruitment Management', 
                    target: '#', 
                    icon: 'fa-user-plus',
                    submodules: [
                        { label: 'Job Posting Management', target: '#' },
                        { label: 'Vacancy Requests', target: '#' },
                        { label: 'Candidate Shortlisting', target: '#' },
                        { label: 'Hiring Approval', target: '#' }
                    ]
                },
                { 
                    label: 'New Hire Onboarding', 
                    target: '#', 
                    icon: 'fa-id-card',
                    submodules: [
                        { label: 'Pre-Employment Requirements', target: '#' },
                        { label: 'Document Submission', target: '#' },
                        { label: 'Contract Management', target: '#' },
                        { label: 'Orientation Scheduling', target: '#' }
                    ]
                },
                { 
                    label: 'Performance Management (Initial)', 
                    target: '#', 
                    icon: 'fa-chart-line', 
                    submodules: [
                        { label: 'Probation Evaluation', target: '#' },
                        { label: 'Initial KPI Setup', target: '#' },
                        { label: 'Evaluation Results', target: '#' }
                    ]
                },
                { 
                    label: 'Social Recognition', 
                    target: '#', 
                    icon: 'fa-award', 
                    submodules: [
                        { label: 'Employee Recognition', target: '#' },
                        { label: 'Awards & Commendations', target: '#' },
                        { label: 'Recognition History', target: '#' }
                    ]
                },
                { type: 'divider', label: 'HR 2', caption: 'Capability Building & Employee Experience' },
                { 
                    label: 'Competency Management', 
                    target: '#', 
                    icon: 'fa-brain', 
                    submodules: [
                        { label: 'Skill Inventory', target: '#' },
                        { label: 'Competency Assessment', target: '#' },
                        { label: 'Competency Gap Analysis', target: '#' }
                    ]
                },
                { 
                    label: 'Learning Management', 
                    target: '#', 
                    icon: 'fa-graduation-cap', 
                    submodules: [
                        { label: 'Course Catalog', target: '#' },
                        { label: 'Assigned Courses', target: '#' },
                        { label: 'Course Completion Tracking', target: '#' },
                        { label: 'Certifications', target: '#' }
                    ]
                },
                { 
                    label: 'Training Management', 
                    target: '#', 
                    icon: 'fa-chalkboard-user', 
                    submodules: [
                        { label: 'Training Programs', target: '#' },
                        { label: 'Training Schedule', target: '#' },
                        { label: 'Training Attendance', target: '#' },
                        { label: 'Training Evaluation', target: '#' }
                    ]
                },
                { 
                    label: 'Succession Planning', 
                    target: '#', 
                    icon: 'fa-diagram-project', 
                    submodules: [
                        { label: 'Position Planning', target: '#' },
                        { label: 'Successor Identification', target: '#' },
                        { label: 'Readiness Assessment', target: '#' }
                    ]
                },
                { 
                    label: 'Employee Self-Service (ESS)', 
                    target: '#', 
                    icon: 'fa-user-gear', 
                    submodules: [
                        { label: 'View Profile', target: '#' },
                        { label: 'Update Personal Info', target: '#' },
                        { label: 'Submit Requests', target: '#' },
                        { label: 'View Employment Records', target: '#' }
                    ]
                },
                { type: 'divider', label: 'HR 3', caption: 'Workforce Operations & Daily Requests' },
                {
                    label: 'Time and Attendance System',
                    target: '#',
                    icon: 'fa-clock',
                    submodules: [
                        { label: 'Attendance Monitoring', target: '#' },
                        { label: 'Attendance Validation', target: '#' },
                        { label: 'Attendance Reports', target: '#' },
                        { label: 'Correction Requests', target: '#' }
                    ]
                },
                {
                    label: 'Shift and Schedule Management',
                    target: '#',
                    icon: 'fa-calendar-days',
                    submodules: [
                        { label: 'Shift Creation', target: '#' },
                        { label: 'Staff Scheduling', target: '#' },
                        { label: 'Shift Assignment', target: '#' },
                        { label: 'Schedule Reports', target: '#' }
                    ]
                },
                {
                    label: 'Timesheet Management',
                    target: 'modules/timesheet-management.html',
                    icon: 'fa-file-lines',
                    submodules: [
                        { label: 'Timesheet Submission', target: '#' },
                        { label: 'Timesheet Approval', target: '#' },
                        { label: 'Overtime Tracking', target: '#' }
                    ]
                },
                {
                    label: 'Leave Management',
                    target: 'modules/leave-management.html',
                    icon: 'fa-calendar-check',
                    submodules: [
                        { label: 'Leave Dashboard', target: '#' },
                        { label: 'Leave Request', target: '#' },
                        { label: 'Leave Approval', target: '#' },
                        { label: 'Leave Balance', target: '#' },
                        { label: 'Leave Reports', target: '#' }
                    ]
                },
                {
                    label: 'Claims and Reimbursement',
                    target: 'modules/claims-and-reimbursement.html',
                    icon: 'fa-receipt',
                    submodules: [
                        { label: 'Claim Submission', target: '#' },
                        { label: 'Claim Review', target: '#' },
                        { label: 'Reimbursement Processing', target: '#' },
                        { label: 'Claim History', target: '#' }
                    ]
                },
                { type: 'divider', label: 'HR 4', caption: 'Core HR, Rewards, and Strategic Insights' },
                {
                    label: 'Core Human Capital Management (HCM)',
                    target: 'modules/core-human-capital-management.html',
                    icon: 'fa-people-group',
                    submodules: [
                        { label: 'Employee Master Data', target: '#' },
                        { label: 'Employment Records', target: '#' },
                        { label: 'Position Management', target: '#' },
                        { label: 'Organizational Structure', target: '#' }
                    ]
                },
                {
                    label: 'Payroll Management',
                    target: 'modules/payroll-management.html',
                    icon: 'fa-money-bill-wave',
                    submodules: [
                        { label: 'Payroll Processing', target: '#' },
                        { label: 'Salary Computation', target: '#' },
                        { label: 'Payslip Generation', target: '#' },
                        { label: 'Payroll Reports', target: '#' }
                    ]
                },
                {
                    label: 'Compensation Planning',
                    target: 'modules/compensation-planning.html',
                    icon: 'fa-sack-dollar',
                    submodules: [
                        { label: 'Salary Adjustment', target: '#' },
                        { label: 'Incentive Management', target: '#' },
                        { label: 'Bonus Allocation', target: '#' }
                    ]
                },
                {
                    label: 'HR Analytics Dashboard',
                    target: 'modules/hr-analytics-dashboard.html',
                    icon: 'fa-chart-pie',
                    submodules: [
                        { label: 'Workforce Reports', target: '#' },
                        { label: 'Turnover Analysis', target: '#' },
                        { label: 'Attendance Analytics', target: '#' },
                        { label: 'Performance Metrics', target: '#' }
                    ]
                },
                {
                    label: 'HMO & Benefits Administration',
                    target: '#',
                    icon: 'fa-notes-medical',
                    submodules: [
                        { label: 'HMO Enrollment', target: '#' },
                        { label: 'Benefits Management', target: '#' },
                        { label: 'Benefits Claims', target: '#' },
                        { label: 'Benefits Reports', target: '#' }
                    ]
                }
            ],
            stats: [
                { label: 'Total Employees', value: '248' },
                { label: 'Open Positions', value: '18' },
                { label: 'Attendance Compliance', value: '93%' },
                { label: 'Pending Requests', value: '27' }
            ],
            primaryCardTitle: 'Workforce Overview',
            secondaryCardTitle: 'Pending Actions'
        };

        const employeeId = localStorage.getItem('hospitalHrEmployeeId');
        const displayName = employeeId ? 'ID: ' + employeeId : 'Hospital HR';
        const avatarUrl = 'https://ui-avatars.com/api/?name=' + encodeURIComponent(displayName) + '&background=0D6EFD&color=fff&bold=true';

        const pageTitle = document.getElementById('pageTitle');
        const pageSubtitle = document.getElementById('pageSubtitle');
        const sidebarUserName = document.getElementById('sidebarUserName');
        const sidebarRoleText = document.getElementById('sidebarRoleText');
        const navbarRoleText = document.getElementById('navbarRoleText');
        const sidebarAvatar = document.getElementById('sidebarAvatar');
        const navbarAvatar = document.getElementById('navbarAvatar');
        const primaryCardTitle = document.getElementById('primaryCardTitle');
        const secondaryCardTitle = document.getElementById('secondaryCardTitle');

        if (pageTitle) {
            pageTitle.textContent = selectedConfig.roleName + ' Dashboard';
        }

        if (pageSubtitle) {
            pageSubtitle.textContent = selectedConfig.subtitle;
        }

        applyRoleSidebarModules(selectedConfig);
        applyRoleDashboardOverview(selectedConfig);

        if (sidebarRoleText) {
            sidebarRoleText.textContent = selectedConfig.roleName;
        }

        if (navbarRoleText) {
            navbarRoleText.textContent = displayName;
        }

        if (sidebarUserName) {
            sidebarUserName.textContent = displayName;
        }

        if (sidebarAvatar) {
            sidebarAvatar.src = avatarUrl;
        }

        if (navbarAvatar) {
            navbarAvatar.src = avatarUrl;
        }

        if (primaryCardTitle) {
            primaryCardTitle.textContent = selectedConfig.primaryCardTitle;
        }

        if (secondaryCardTitle) {
            secondaryCardTitle.textContent = selectedConfig.secondaryCardTitle;
        }

        selectedConfig.stats.forEach(function (item, index) {
            const labelEl = document.getElementById('statLabel' + (index + 1));
            const valueEl = document.getElementById('statValue' + (index + 1));

            if (labelEl) {
                labelEl.textContent = item.label;
            }

            if (valueEl) {
                valueEl.textContent = item.value;
            }
        });

        function applyRoleSidebarModules(config) {
            if (!config.sidebarModules || !config.sidebarModules.length) {
                return;
            }

            const navList = document.querySelector('.sidebar-nav .nav.flex-column');
            if (!navList) {
                return;
            }

            const roleModuleItems = config.sidebarModules.map(function (module, index) {
                if (module.type === 'divider') {
                    const dividerCaption = typeof module.caption === 'string' ? module.caption : '';
                    return [
                        '<li class="sidebar-divider" role="separator" aria-label="' + module.label + '">',
                        '  <span class="sidebar-divider-label">' + module.label + '</span>',
                        dividerCaption ? '  <small class="sidebar-divider-caption">' + dividerCaption + '</small>' : '',
                        '</li>'
                    ].join('');
                }

                const activeClass = index === 0 ? ' active' : '';
                const hasSubmodules = Array.isArray(module.submodules) && module.submodules.length > 0;
                const parentClasses = hasSubmodules ? ' has-submodules' : '';
                const submoduleItems = hasSubmodules
                    ? '<ul class="nav flex-column sidebar-subnav">' + module.submodules.map(function (submodule) {
                        const subTarget = submodule.target || '#';
                        return [
                            '<li class="nav-item">',
                            '  <a class="nav-link nav-sublink" href="' + subTarget + '">',
                            '    <span>' + submodule.label + '</span>',
                            '  </a>',
                            '</li>'
                        ].join('');
                    }).join('') + '</ul>'
                    : '';

                return [
                    '<li class="nav-item">',
                    '  <a class="nav-link' + activeClass + parentClasses + '" href="' + module.target + '">',
                    '    <i class="fas ' + module.icon + '"></i>',
                    '    <span>' + module.label + '</span>',
                    hasSubmodules ? '    <i class="fas fa-chevron-down subnav-caret"></i>' : '',
                    '  </a>',
                    submoduleItems,
                    '</li>'
                ].join('');
            }).join('');

            navList.innerHTML = roleModuleItems;
        }

        function applyRoleDashboardOverview(config) {
            const overviewTitle = document.getElementById('roleOverviewTitle');
            const overviewBody = document.getElementById('roleModuleOverviewBody');

            if (!overviewBody) {
                return;
            }

            if (overviewTitle) {
                overviewTitle.textContent = config.roleName + ' Modules';
            }

            const modulesForOverview = (config.sidebarModules || []).filter(function (module) {
                return module.label !== 'Dashboard' && module.type !== 'divider';
            });

            if (!modulesForOverview.length) {
                overviewBody.innerHTML = '<p class="text-muted mb-0">No role modules available.</p>';
                return;
            }

            overviewBody.innerHTML = '<div class="role-module-grid">' + modulesForOverview.map(function (module) {
                const submodules = Array.isArray(module.submodules) ? module.submodules : [];
                const submoduleMarkup = submodules.length
                    ? '<div class="role-submodule-list">' + submodules.map(function (submodule) {
                        return '<span class="role-submodule-pill">' + submodule.label + '</span>';
                    }).join('') + '</div>'
                    : '<p class="text-muted small mb-0">No submodules.</p>';

                return [
                    '<div class="role-module-item">',
                    '  <div class="role-module-name">' + module.label + '</div>',
                    submoduleMarkup,
                    '</div>'
                ].join('');
            }).join('') + '</div>';
        }
    }

    function initSidebar() {
        const toggle = document.getElementById('sidebarToggle');
        const close = document.getElementById('sidebarClose');
        const sidebar = document.getElementById('sidebar');
        const storageKey = 'hospitalHrSidebarCollapsed';

        if (!toggle || !sidebar) {
            return;
        }

        applyStoredSidebarState();

        toggle.addEventListener('click', function (event) {
            event.preventDefault();
            if (window.innerWidth >= 992) {
                sidebar.classList.toggle('collapsed');
                persistSidebarState();
                return;
            }

            sidebar.classList.toggle('show');
        });

        if (close) {
            close.addEventListener('click', function (event) {
                event.preventDefault();
                sidebar.classList.remove('show');
            });
        }

        document.addEventListener('click', function (event) {
            if (window.innerWidth >= 992) {
                return;
            }

            if (!sidebar.contains(event.target) && !toggle.contains(event.target)) {
                sidebar.classList.remove('show');
            }
        });

        window.addEventListener('resize', function () {
            if (window.innerWidth >= 992) {
                sidebar.classList.remove('show');
                applyStoredSidebarState();
            }
        });

        function persistSidebarState() {
            const isCollapsed = sidebar.classList.contains('collapsed');
            localStorage.setItem(storageKey, isCollapsed ? '1' : '0');
        }

        function applyStoredSidebarState() {
            if (window.innerWidth < 992) {
                return;
            }

            const isCollapsed = localStorage.getItem(storageKey) === '1';
            sidebar.classList.toggle('collapsed', isCollapsed);
        }
    }

    function initSidebarNavigation() {
        const navLinks = document.querySelectorAll('.sidebar-nav .nav-link');
        const sidebar = document.getElementById('sidebar');

        if (!navLinks.length) {
            return;
        }

        navLinks.forEach(function (link) {
            link.addEventListener('click', function (event) {
                const isSubmoduleLink = link.classList.contains('nav-sublink');

                if (link.classList.contains('has-submodules')) {
                    event.preventDefault();

                    const parentItem = link.closest('.nav-item');
                    if (!parentItem) {
                        return;
                    }

                    const isOpen = parentItem.classList.contains('open');
                    const allParentItems = document.querySelectorAll('.sidebar-nav > .nav > .nav-item');

                    allParentItems.forEach(function (item) {
                        item.classList.remove('open');
                    });

                    if (!isOpen) {
                        parentItem.classList.add('open');
                    }

                    return;
                }

                const targetSelector = link.getAttribute('href');
                if (!targetSelector) {
                    return;
                }

                if (isSubmoduleLink) {
                    event.preventDefault();
                    setActiveNavLink(link);
                    renderInlineSubmoduleContent(link.textContent.trim());
                    if (window.innerWidth < 992 && sidebar) {
                        sidebar.classList.remove('show');
                    }
                    return;
                }

                if (!isSubmoduleLink) {
                    event.preventDefault();
                    setActiveNavLink(link);

                    if (link.textContent.trim() === 'Dashboard') {
                        restoreDashboardView();
                        const dashboardSection = document.getElementById('dashboard');
                        if (dashboardSection) {
                            dashboardSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
                        }
                    }

                    if (window.innerWidth < 992 && sidebar) {
                        sidebar.classList.remove('show');
                    }
                    return;
                }

                event.preventDefault();

                const targetElement = document.querySelector(targetSelector);
                if (!targetElement) {
                    return;
                }

                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });

                setActiveNavLink(link);

                if (window.innerWidth < 992 && sidebar) {
                    sidebar.classList.remove('show');
                }
            });
        });

        const sectionLinks = Array.from(navLinks).filter(function (link) {
            const selector = link.getAttribute('href');
            return !!selector && selector.charAt(0) === '#' && selector.length > 1;
        });

        const sections = sectionLinks
            .map(function (link) {
                const selector = link.getAttribute('href');
                return selector ? document.querySelector(selector) : null;
            })
            .filter(Boolean);

        if (!sections.length) {
            return;
        }

        const observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (!entry.isIntersecting) {
                    return;
                }

                const id = entry.target.getAttribute('id');
                const activeLink = document.querySelector('.sidebar-nav .nav-link[href="#' + id + '"]');
                if (activeLink) {
                    setActiveNavLink(activeLink);
                }
            });
        }, {
            rootMargin: '-120px 0px -55% 0px',
            threshold: 0.1
        });

        sections.forEach(function (section) {
            observer.observe(section);
        });
    }

    function setActiveNavLink(activeLink) {
        const navLinks = document.querySelectorAll('.sidebar-nav .nav-link');
        navLinks.forEach(function (link) {
            link.classList.remove('active');
        });
        activeLink.classList.add('active');
    }

    function renderInlineSubmoduleContent(submoduleName) {
        const titleEl = document.getElementById('roleOverviewTitle');
        const bodyEl = document.getElementById('roleModuleOverviewBody');
        const sectionEl = document.getElementById('roleOverview');
        const pageTitle = document.getElementById('pageTitle');
        const pageSubtitle = document.getElementById('pageSubtitle');

        if (!titleEl || !bodyEl) {
            return;
        }

        activeSubmoduleName = submoduleName;

        setDashboardContentMode('submodule');
        titleEl.textContent = submoduleName;

        if (pageTitle) {
            pageTitle.textContent = submoduleName;
        }

        if (pageSubtitle) {
            pageSubtitle.textContent = 'Operational view for ' + submoduleName + ' with real-time HR workflow data.';
        }

        const submoduleRenderers = {
            'Applicant List': 'renderApplicantList',
            'Application Tracking': 'renderApplicationTracking',
            'Interview Scheduling': 'renderInterviewScheduling',
            'Applicant Status Monitoring': 'renderApplicantStatusMonitoring',
            'Job Posting Management': 'renderJobPostingManagement',
            'Vacancy Requests': 'renderVacancyRequests',
            'Candidate Shortlisting': 'renderCandidateShortlisting',
            'Hiring Approval': 'renderHiringApproval',
            'Pre-Employment Requirements': 'renderPreEmployment',
            'Document Submission': 'renderDocumentSubmission',
            'Contract Management': 'renderContractManagement',
            'Orientation Scheduling': 'renderOrientationScheduling',
            'Probation Evaluation': 'renderProbationEvaluation',
            'Initial KPI Setup': 'renderInitialKPISetup',
            'Evaluation Results': 'renderEvaluationResults',
            'Employee Recognition': 'renderEmployeeRecognition',
            'Awards & Commendations': 'renderAwardsCommendations',
            'Recognition History': 'renderRecognitionHistory',
            'Skill Inventory': 'renderSkillInventory',
            'Competency Assessment': 'renderCompetencyAssessment',
            'Competency Gap Analysis': 'renderCompetencyGapAnalysis',
            'Course Catalog': 'renderCourseCatalog',
            'Assigned Courses': 'renderAssignedCourses',
            'Course Completion Tracking': 'renderCourseCompletionTracking',
            'Certifications': 'renderCertifications',
            'Training Programs': 'renderTrainingPrograms',
            'Training Schedule': 'renderTrainingSchedule',
            'Training Attendance': 'renderTrainingAttendance',
            'Training Evaluation': 'renderTrainingEvaluation',
            'Position Planning': 'renderPositionPlanning',
            'Successor Identification': 'renderSuccessorIdentification',
            'Readiness Assessment': 'renderReadinessAssessment',
            'View Profile': 'renderViewProfile',
            'Update Personal Info': 'renderUpdatePersonalInfo',
            'Submit Requests': 'renderSubmitRequests',
            'View Employment Records': 'renderViewEmploymentRecords',
            'Attendance Monitoring': 'renderAttendanceMonitoring',
            'Attendance Validation': 'renderAttendanceValidation',
            'Attendance Reports': 'renderAttendanceReports',
            'Correction Requests': 'renderCorrectionRequests',
            'Shift Creation': 'renderShiftCreation',
            'Staff Scheduling': 'renderStaffScheduling',
            'Shift Assignment': 'renderShiftAssignment',
            'Schedule Reports': 'renderScheduleReports',
            'Timesheet Submission': 'renderTimesheetSubmission',
            'Timesheet Approval': 'renderTimesheetApproval',
            'Overtime Tracking': 'renderOvertimeTracking',
            'Leave Dashboard': 'renderLeaveDashboard',
            'Leave Request': 'renderLeaveRequest',
            'Leave Approval': 'renderLeaveApproval',
            'Leave Balance': 'renderLeaveBalance',
            'Leave Reports': 'renderLeaveReports',
            'Claim Submission': 'renderClaimSubmission',
            'Claim Review': 'renderClaimReview',
            'Reimbursement Processing': 'renderReimbursementProcessing',
            'Claim History': 'renderClaimHistory',
            'Employee Master Data': 'renderEmployeeMasterData',
            'Employment Records': 'renderEmploymentRecords',
            'Position Management': 'renderPositionManagement',
            'Organizational Structure': 'renderOrganizationalStructure',
            'Payroll Processing': 'renderPayrollProcessing',
            'Salary Computation': 'renderSalaryComputation',
            'Payslip Generation': 'renderPayslipGeneration',
            'Payroll Reports': 'renderPayrollReports',
            'Salary Adjustment': 'renderSalaryAdjustment',
            'Incentive Management': 'renderIncentiveManagement',
            'Bonus Allocation': 'renderBonusAllocation',
            'Workforce Reports': 'renderWorkforceReports',
            'Turnover Analysis': 'renderTurnoverAnalysis',
            'Attendance Analytics': 'renderAttendanceAnalytics',
            'Performance Metrics': 'renderPerformanceMetrics',
            'HMO Enrollment': 'renderHmoEnrollment',
            'Benefits Management': 'renderBenefitsManagement',
            'Benefits Claims': 'renderBenefitsClaims',
            'Benefits Reports': 'renderBenefitsReports'
        };

        const rendererName = submoduleRenderers[submoduleName];
        const renderer = rendererName && window.HRSubmodules ? window.HRSubmodules[rendererName] : null;

        if (typeof renderer === 'function') {
            renderer(bodyEl);
        } else {
            bodyEl.innerHTML = '<div class="border rounded-3 p-3">'
                + '<p class="mb-1 fw-semibold">' + submoduleName + '</p>'
                + '<p class="text-muted mb-0">This submodule is loaded in the same dashboard page. Content can be expanded here next.</p>'
                + '</div>';
        }

        injectSubmoduleActionBar(bodyEl, submoduleName);

        if (sectionEl) {
            sectionEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }

    function injectSubmoduleActionBar(container, submoduleName) {
        if (!container) {
            return;
        }

        const existingBar = container.querySelector('.submodule-actionbar');
        if (existingBar) {
            existingBar.remove();
        }

        const toolbar = document.createElement('div');
        toolbar.className = 'submodule-actionbar d-flex justify-content-between align-items-center mb-3';
        toolbar.innerHTML = [
            '<div class="submodule-actionbar-title">',
            '  <span class="badge bg-primary-subtle text-primary px-2 py-1">HR Workspace</span>',
            '</div>',
            '<div class="submodule-actionbar-buttons d-flex gap-2">',
            '  <button type="button" class="btn btn-sm btn-outline-secondary" data-submodule-action="filter"><i class="fas fa-filter me-1"></i>Filter</button>',
            '  <button type="button" class="btn btn-sm btn-outline-secondary" data-submodule-action="export"><i class="fas fa-file-export me-1"></i>Export</button>',
            '  <button type="button" class="btn btn-sm btn-outline-primary" data-submodule-action="refresh"><i class="fas fa-rotate-right me-1"></i>Refresh</button>',
            '</div>'
        ].join('');

        container.prepend(toolbar);

        toolbar.querySelectorAll('button[data-submodule-action]').forEach(function (button) {
            button.addEventListener('click', function () {
                const action = button.getAttribute('data-submodule-action');

                if (action === 'filter') {
                    const firstInput = container.querySelector('input:not([type="hidden"]), select, textarea');
                    if (firstInput) {
                        firstInput.focus();
                    }
                    return;
                }

                if (action === 'export') {
                    const knownExportIds = ['attExportCsv', 'exportScheduleCsv', 'leaveExportCsv'];
                    const exportButton = knownExportIds
                        .map(function (id) { return document.getElementById(id); })
                        .find(Boolean);

                    if (exportButton) {
                        exportButton.click();
                        return;
                    }

                    exportFirstTableAsCsv(container, submoduleName);
                    return;
                }

                if (action === 'refresh' && activeSubmoduleName) {
                    renderInlineSubmoduleContent(activeSubmoduleName);
                }
            });
        });
    }

    function exportFirstTableAsCsv(container, submoduleName) {
        const table = container.querySelector('table');
        if (!table) {
            return;
        }

        const rows = Array.from(table.querySelectorAll('tr')).map(function (row) {
            return Array.from(row.querySelectorAll('th, td')).map(function (cell) {
                const raw = (cell.textContent || '').trim().replace(/\s+/g, ' ');
                return '"' + raw.replace(/"/g, '""') + '"';
            }).join(',');
        });

        if (!rows.length) {
            return;
        }

        const safeName = (submoduleName || 'submodule-report').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
        const blob = new Blob([rows.join('\n')], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = (safeName || 'submodule-report') + '.csv';
        link.click();
        URL.revokeObjectURL(link.href);
    }

    function setDashboardContentMode(mode) {
        const sections = document.querySelectorAll('.content-section');
        const contentWrapper = document.querySelector('.content-wrapper');

        if (contentWrapper) {
            contentWrapper.classList.toggle('submodule-view', mode === 'submodule');
        }

        sections.forEach(function (section) {
            if (mode === 'submodule') {
                section.classList.toggle('d-none', section.id !== 'roleOverview');
                return;
            }

            section.classList.toggle('d-none', section.id === 'roleOverview');
        });
    }

    function restoreDashboardView() {
        const pageTitle = document.getElementById('pageTitle');
        const pageSubtitle = document.getElementById('pageSubtitle');

        setDashboardContentMode('dashboard');

        if (pageTitle) {
            pageTitle.textContent = 'Hospital HR Dashboard';
        }

        if (pageSubtitle) {
            pageSubtitle.textContent = 'Manage workforce, operations, and employee lifecycle in one place.';
        }
    }

    function ensureDashboardInfoModalHost() {
        if (document.getElementById('dashboardInfoModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="dashboardInfoModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="dashboardInfoModalTitle">Dashboard Action</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="dashboardInfoModalBody"></div>',
            '      <div class="modal-footer" id="dashboardInfoModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showDashboardInfoModal(title, message) {
        const modalEl = document.getElementById('dashboardInfoModal');
        const titleEl = document.getElementById('dashboardInfoModalTitle');
        const bodyEl = document.getElementById('dashboardInfoModalBody');
        const footerEl = document.getElementById('dashboardInfoModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    function initSearch() {
        const searchForm = document.querySelector('form[role="search"]');
        if (!searchForm) {
            return;
        }

        searchForm.addEventListener('submit', function (event) {
            event.preventDefault();
            const input = searchForm.querySelector('input[type="search"]');
            if (!input) {
                return;
            }

            const query = input.value.trim();
            if (query.length > 0) {
                showDashboardInfoModal('Search', 'Search query: ' + query);
            }
        });
    }

    function initActionButtons() {
        const buttons = document.querySelectorAll('.table .btn-sm');

        buttons.forEach(function (button) {
            button.addEventListener('click', function (event) {
                event.preventDefault();
                const icon = button.querySelector('i');
                if (!icon) {
                    return;
                }

                if (icon.classList.contains('fa-eye')) {
                    showDashboardInfoModal('Employee Profile', 'Opening employee profile.');
                }

                if (icon.classList.contains('fa-edit')) {
                    showDashboardInfoModal('Edit Employee', 'Editing employee record.');
                }
            });
        });
    }

    function initLogout() {
        const logoutButton = document.getElementById('logoutButton');
        if (!logoutButton) {
            return;
        }

        logoutButton.addEventListener('click', function (event) {
            event.preventDefault();
            showLogoutNotification(function () {
                localStorage.removeItem('hospitalHrEmployeeId');
                localStorage.removeItem('hospitalHrSidebarCollapsed');
                window.location.href = 'dashboard.html';
            });
        });
    }

    function showLogoutNotification(onConfirm) {
        let overlay = document.getElementById('logoutNotificationOverlay');

        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id = 'logoutNotificationOverlay';
            overlay.className = 'app-notification-overlay';
            overlay.innerHTML = [
                '<div class="app-notification-box" role="dialog" aria-modal="true" aria-labelledby="logoutNotifTitle">',
                '  <div class="app-notification-title" id="logoutNotifTitle">Confirm Logout</div>',
                '  <div class="app-notification-text">Are you sure you want to logout?</div>',
                '  <div class="app-notification-actions">',
                '    <button type="button" class="btn btn-sm btn-outline-secondary" id="cancelLogoutBtn">Cancel</button>',
                '    <button type="button" class="btn btn-sm btn-danger" id="confirmLogoutBtn">Logout</button>',
                '  </div>',
                '</div>'
            ].join('');
            document.body.appendChild(overlay);

            overlay.addEventListener('click', function (event) {
                if (event.target === overlay) {
                    overlay.classList.remove('show');
                }
            });
        }

        const cancelButton = overlay.querySelector('#cancelLogoutBtn');
        const confirmButton = overlay.querySelector('#confirmLogoutBtn');

        overlay.classList.add('show');

        if (cancelButton) {
            cancelButton.onclick = function () {
                overlay.classList.remove('show');
            };
        }

        if (confirmButton) {
            confirmButton.onclick = function () {
                overlay.classList.remove('show');
                if (typeof onConfirm === 'function') {
                    onConfirm();
                }
            };
        }
    }
})();
