<?php
// dashboard.php - Hospital HR Dashboard with Database Connection
require_once 'php/connect.php';

// Initialize variables with default values
$totalEmployees = 0;
$openLeaveRequests = 0;
$newApplicants = 0;
$payrollReady = 0;
$presentToday = 0;
$lateEntries = 0;
$onLeave = 0;
$openPositions = 0;
$interviewsToday = 0;
$offersSent = 0;

// Fetch data from database if connection is successful
try {
    if ($conn) {
        // Get total employees
        $stmt = $conn->query("SELECT COUNT(*) as total FROM employees");
        if ($stmt) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $totalEmployees = $row['total'] ?: 248; // Fallback to 248 if no data
        }
        
        // Get open leave requests
        $stmt = $conn->query("SELECT COUNT(*) as total FROM leave_requests WHERE status = 'pending'");
        if ($stmt) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $openLeaveRequests = $row['total'] ?: 19;
        }
        
        // Get new applicants
        $stmt = $conn->query("SELECT COUNT(*) as total FROM applicants WHERE application_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)");
        if ($stmt) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $newApplicants = $row['total'] ?: 34;
        }
        
        // Get payroll ready percentage
        $stmt = $conn->query("SELECT 
            ROUND((COUNT(CASE WHEN payroll_status = 'ready' THEN 1 END) / COUNT(*)) * 100) as percentage 
            FROM employees");
        if ($stmt) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $payrollReady = $row['percentage'] ?: 92;
        }
        
        // Get attendance data
        $stmt = $conn->query("SELECT 
            COUNT(CASE WHEN status = 'present' THEN 1 END) as present,
            COUNT(CASE WHEN status = 'late' THEN 1 END) as late,
            COUNT(CASE WHEN status = 'on_leave' THEN 1 END) as leave_count
            FROM attendance WHERE attendance_date = CURDATE()");
        if ($stmt) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $presentToday = $row['present'] ?: 223;
            $lateEntries = $row['late'] ?: 11;
            $onLeave = $row['leave_count'] ?: 14;
        }
        
        // Get recruitment data
        $stmt = $conn->query("SELECT 
            COUNT(CASE WHEN status = 'open' THEN 1 END) as open_positions,
            COUNT(CASE WHEN interview_date = CURDATE() THEN 1 END) as interviews_today,
            COUNT(CASE WHEN offer_status = 'sent' THEN 1 END) as offers_sent
            FROM job_positions");
        if ($stmt) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $openPositions = $row['open_positions'] ?: 6;
            $interviewsToday = $row['interviews_today'] ?: 4;
            $offersSent = $row['offers_sent'] ?: 3;
        }
    }
} catch(PDOException $e) {
    // Silently handle error - use default values
    error_log("Database error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hospital HR Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/modules/applicant-management/submodules/applicant-list.css">
    <link rel="stylesheet" href="assets/css/modules/applicant-management/submodules/application-tracking.css">
    <link rel="stylesheet" href="assets/css/modules/applicant-management/submodules/interview-scheduling.css">
    <link rel="stylesheet" href="assets/css/modules/applicant-management/submodules/applicant-status-monitoring.css">
    <link rel="stylesheet" href="assets/css/modules/recruitment-management/submodules/job-posting-management.css">
    <link rel="stylesheet" href="assets/css/modules/recruitment-management/submodules/vacancy-requests.css">
    <link rel="stylesheet" href="assets/css/modules/recruitment-management/submodules/candidate-shortlisting.css">
    <link rel="stylesheet" href="assets/css/modules/recruitment-management/submodules/hiring-approval.css">
    <link rel="stylesheet" href="assets/css/modules/new-hire-onboarding/submodules/pre-employment-requirements.css">
    <link rel="stylesheet" href="assets/css/modules/new-hire-onboarding/submodules/document-submission.css">
    <link rel="stylesheet" href="assets/css/modules/new-hire-onboarding/submodules/contract-management.css">
    <link rel="stylesheet" href="assets/css/modules/new-hire-onboarding/submodules/orientation-scheduling.css">
    <link rel="stylesheet" href="assets/css/modules/performance-management/submodules/probation-evaluation.css">
    <link rel="stylesheet" href="assets/css/modules/performance-management/submodules/initial-kpi-setup.css">
    <link rel="stylesheet" href="assets/css/modules/performance-management/submodules/evaluation-results.css">
    <link rel="stylesheet" href="assets/css/modules/social-recognition/submodules/employee-recognition.css">
    <link rel="stylesheet" href="assets/css/modules/social-recognition/submodules/awards-commendations.css">
    <link rel="stylesheet" href="assets/css/modules/social-recognition/submodules/recognition-history.css">
    <link rel="stylesheet" href="assets/css/modules/competency-management/submodules/skill-inventory.css">
    <link rel="stylesheet" href="assets/css/modules/competency-management/submodules/competency-assessment.css">
    <link rel="stylesheet" href="assets/css/modules/competency-management/submodules/competency-gap-analysis.css">
    <link rel="stylesheet" href="assets/css/modules/learning-management/submodules/course-catalog.css">
    <link rel="stylesheet" href="assets/css/modules/learning-management/submodules/assigned-courses.css">
    <link rel="stylesheet" href="assets/css/modules/learning-management/submodules/course-completion-tracking.css">
    <link rel="stylesheet" href="assets/css/modules/learning-management/submodules/certifications.css">
    <link rel="stylesheet" href="assets/css/modules/training-management/submodules/training-programs.css">
    <link rel="stylesheet" href="assets/css/modules/training-management/submodules/training-schedule.css">
    <link rel="stylesheet" href="assets/css/modules/training-management/submodules/training-attendance.css">
    <link rel="stylesheet" href="assets/css/modules/training-management/submodules/training-evaluation.css">
    <link rel="stylesheet" href="assets/css/modules/succession-planning/submodules/position-planning.css">
    <link rel="stylesheet" href="assets/css/modules/succession-planning/submodules/successor-identification.css">
    <link rel="stylesheet" href="assets/css/modules/succession-planning/submodules/readiness-assessment.css">
    <link rel="stylesheet" href="assets/css/modules/employee-self-service/submodules/view-profile.css">
    <link rel="stylesheet" href="assets/css/modules/employee-self-service/submodules/update-personal-info.css">
    <link rel="stylesheet" href="assets/css/modules/employee-self-service/submodules/submit-requests.css">
    <link rel="stylesheet" href="assets/css/modules/employee-self-service/submodules/view-employment-records.css">
    <link rel="stylesheet" href="assets/css/modules/time-and-attendance-system/submodules/attendance-monitoring.css">
    <link rel="stylesheet" href="assets/css/modules/time-and-attendance-system/submodules/attendance-validation.css">
    <link rel="stylesheet" href="assets/css/modules/time-and-attendance-system/submodules/attendance-reports.css">
    <link rel="stylesheet" href="assets/css/modules/time-and-attendance-system/submodules/correction-requests.css">
    <link rel="stylesheet" href="assets/css/modules/shift-and-schedule-management/submodules/shift-creation.css">
    <link rel="stylesheet" href="assets/css/modules/shift-and-schedule-management/submodules/staff-scheduling.css">
    <link rel="stylesheet" href="assets/css/modules/shift-and-schedule-management/submodules/shift-assignment.css">
    <link rel="stylesheet" href="assets/css/modules/shift-and-schedule-management/submodules/schedule-reports.css">
    <link rel="stylesheet" href="assets/css/modules/timesheet-management/submodules/timesheet-submission.css">
    <link rel="stylesheet" href="assets/css/modules/timesheet-management/submodules/timesheet-approval.css">
    <link rel="stylesheet" href="assets/css/modules/timesheet-management/submodules/overtime-tracking.css">
    <link rel="stylesheet" href="assets/css/modules/leave-management/submodules/leave-dashboard.css">
    <link rel="stylesheet" href="assets/css/modules/leave-management/submodules/leave-request.css">
    <link rel="stylesheet" href="assets/css/modules/leave-management/submodules/leave-approval.css">
    <link rel="stylesheet" href="assets/css/modules/leave-management/submodules/leave-balance.css">
    <link rel="stylesheet" href="assets/css/modules/leave-management/submodules/leave-reports.css">
    <link rel="stylesheet" href="assets/css/modules/claims-and-reimbursement/submodules/claim-submission.css">
    <link rel="stylesheet" href="assets/css/modules/claims-and-reimbursement/submodules/claim-review.css">
    <link rel="stylesheet" href="assets/css/modules/claims-and-reimbursement/submodules/reimbursement-processing.css">
    <link rel="stylesheet" href="assets/css/modules/claims-and-reimbursement/submodules/claim-history.css">
    <link rel="stylesheet" href="assets/css/modules/core-human-capital-management/submodules/employee-master-data.css">
    <link rel="stylesheet" href="assets/css/modules/core-human-capital-management/submodules/employment-records.css">
    <link rel="stylesheet" href="assets/css/modules/core-human-capital-management/submodules/position-management.css">
    <link rel="stylesheet" href="assets/css/modules/core-human-capital-management/submodules/organizational-structure.css">
    <link rel="stylesheet" href="assets/css/modules/payroll-management/submodules/payroll-processing.css">
    <link rel="stylesheet" href="assets/css/modules/payroll-management/submodules/salary-computation.css">
    <link rel="stylesheet" href="assets/css/modules/payroll-management/submodules/payslip-generation.css">
    <link rel="stylesheet" href="assets/css/modules/payroll-management/submodules/payroll-reports.css">
    <link rel="stylesheet" href="assets/css/modules/compensation-planning/submodules/salary-adjustment.css">
    <link rel="stylesheet" href="assets/css/modules/compensation-planning/submodules/incentive-management.css">
    <link rel="stylesheet" href="assets/css/modules/compensation-planning/submodules/bonus-allocation.css">
    <link rel="stylesheet" href="assets/css/modules/hr-analytics-dashboard/submodules/workforce-reports.css">
    <link rel="stylesheet" href="assets/css/modules/hr-analytics-dashboard/submodules/turnover-analysis.css">
    <link rel="stylesheet" href="assets/css/modules/hr-analytics-dashboard/submodules/attendance-analytics.css">
    <link rel="stylesheet" href="assets/css/modules/hr-analytics-dashboard/submodules/performance-metrics.css">
    <link rel="stylesheet" href="assets/css/modules/hmo-benefits-administration/submodules/hmo-enrollment.css">
    <link rel="stylesheet" href="assets/css/modules/hmo-benefits-administration/submodules/benefits-management.css">
    <link rel="stylesheet" href="assets/css/modules/hmo-benefits-administration/submodules/benefits-claims.css">
    <link rel="stylesheet" href="assets/css/modules/hmo-benefits-administration/submodules/benefits-reports.css">
    <style>
        /* Additional styles for connection status */
        .connection-status {
            position: fixed;
            bottom: 20px;
            right: 20px;
            padding: 10px 20px;
            border-radius: 30px;
            font-size: 14px;
            z-index: 9999;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        .connection-status.connected {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .connection-status.disconnected {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <!-- Connection Status Indicator -->
    <?php if (isset($conn) && $conn): ?>
        <div class="connection-status connected">
            <i class="fas fa-check-circle me-2"></i> Database Connected
        </div>
    <?php else: ?>
        <div class="connection-status disconnected">
            <i class="fas fa-exclamation-circle me-2"></i> Database Disconnected (Using Sample Data)
        </div>
    <?php endif; ?>

    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="d-flex align-items-center gap-2">
                <i class="fas fa-user-shield text-primary fs-4"></i>
                <h4 class="mb-0">Hospital HR</h4>
            </div>
            <button class="btn btn-link sidebar-toggle d-lg-none" id="sidebarClose" aria-label="Close sidebar">
                <i class="fas fa-times"></i>
            </button>
        </div>

        <nav class="sidebar-nav">
            <ul class="nav flex-column">
                <li class="nav-item"><a class="nav-link active" href="#dashboard"><i class="fas fa-gauge"></i><span>Dashboard</span></a></li>
                <!-- Add more navigation items as needed -->
            </ul>
        </nav>

        <div class="sidebar-footer">
            <div class="user-info">
                <img id="sidebarAvatar" src="https://ui-avatars.com/api/?name=Hospital+HR&background=0D6EFD&color=fff&bold=true" alt="Hospital HR avatar" class="rounded-circle">
                <div class="ms-2">
                    <h6 class="mb-0 small fw-bold" id="sidebarUserName">Hospital HR</h6>
                    <small class="text-muted" id="sidebarRoleText">People Operations</small>
                </div>
            </div>
        </div>
    </aside>

    <div class="main-content">
        <nav class="navbar navbar-expand-lg bg-white border-bottom sticky-top">
            <div class="container-fluid">
                <button class="btn btn-link sidebar-toggle" id="sidebarToggle" aria-label="Open sidebar">
                    <i class="fas fa-bars"></i>
                </button>

                <div class="ms-auto d-flex align-items-center navbar-actions">
                    <form class="d-none d-md-flex navbar-search" role="search">
                        <div class="input-group">
                            <input class="form-control" type="search" placeholder="Search" aria-label="Search">
                            <button class="btn btn-outline-secondary search-icon-btn" type="submit" aria-label="Submit search">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </form>

                    <button class="btn btn-link position-relative notif-center-btn" aria-label="Notifications">
                        <i class="fas fa-bell"></i>
                        <span class="badge rounded-pill bg-danger notification-badge">3</span>
                    </button>

                    <div class="dropdown">
                        <button class="btn btn-link d-flex align-items-center text-decoration-none text-dark" data-bs-toggle="dropdown" aria-expanded="false">
                            <img id="navbarAvatar" src="https://ui-avatars.com/api/?name=Hospital+HR&background=0D6EFD&color=fff&bold=true" class="rounded-circle me-2" width="32" alt="User avatar">
                            <span class="d-none d-md-inline small" id="navbarRoleText">Hospital HR</span>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="profile.php">Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="#" id="logoutButton">Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <div class="content-wrapper p-4">
            <div class="page-header mb-4">
                <h2 class="page-title fw-bold" id="pageTitle">Hospital HR Dashboard</h2>
                <p class="text-muted mb-0" id="pageSubtitle">Manage workforce, operations, and employee lifecycle in one place.</p>
                <?php if(isset($conn) && $conn): ?>
                    <small class="text-success mt-2 d-block"><i class="fas fa-database me-1"></i> Live data from database</small>
                <?php else: ?>
                    <small class="text-warning mt-2 d-block"><i class="fas fa-exclamation-triangle me-1"></i> Using sample data (Database not connected)</small>
                <?php endif; ?>
            </div>

            <section class="row g-4 mb-4 content-section" id="dashboard">
                <div class="col-xl-3 col-md-6">
                    <div class="card stat-card border-0 shadow-sm">
                        <div class="card-body d-flex align-items-center justify-content-between">
                            <div>
                                <p class="text-muted mb-1" id="statLabel1">Total Employees</p>
                                <h3 class="mb-0 fw-bold" id="statValue1"><?php echo number_format($totalEmployees); ?></h3>
                            </div>
                            <div class="stat-icon bg-primary-subtle text-primary"><i class="fas fa-users"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="card stat-card border-0 shadow-sm">
                        <div class="card-body d-flex align-items-center justify-content-between">
                            <div>
                                <p class="text-muted mb-1" id="statLabel2">Open Leave Requests</p>
                                <h3 class="mb-0 fw-bold" id="statValue2"><?php echo number_format($openLeaveRequests); ?></h3>
                            </div>
                            <div class="stat-icon bg-warning-subtle text-warning"><i class="fas fa-calendar-check"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="card stat-card border-0 shadow-sm">
                        <div class="card-body d-flex align-items-center justify-content-between">
                            <div>
                                <p class="text-muted mb-1" id="statLabel3">New Applicants</p>
                                <h3 class="mb-0 fw-bold" id="statValue3"><?php echo number_format($newApplicants); ?></h3>
                            </div>
                            <div class="stat-icon bg-success-subtle text-success"><i class="fas fa-user-plus"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="card stat-card border-0 shadow-sm">
                        <div class="card-body d-flex align-items-center justify-content-between">
                            <div>
                                <p class="text-muted mb-1" id="statLabel4">Payroll Ready</p>
                                <h3 class="mb-0 fw-bold" id="statValue4"><?php echo $payrollReady; ?>%</h3>
                            </div>
                            <div class="stat-icon bg-info-subtle text-info"><i class="fas fa-money-bill-wave"></i></div>
                        </div>
                    </div>
                </div>
            </section>

            <section class="row g-4 mb-4 content-section" id="dashboardGraph">
                <div class="col-12">
                    <div class="card border-0 shadow-sm graph-card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="card-title mb-0"><i class="fas fa-chart-bar me-2"></i>Dashboard Overview Graph</h5>
                            <span class="small text-muted">Live module insights</span>
                        </div>
                        <div class="card-body">
                            <div class="ui-graph-wrap">
                                <div class="ui-graph-row">
                                    <div class="ui-graph-head"><span>Total Employees</span><strong id="graphEmployeesValue"><?php echo number_format($totalEmployees); ?></strong></div>
                                    <div class="ui-graph-track"><div class="ui-graph-fill" id="graphEmployeesBar" style="width: <?php echo min(100, $totalEmployees/3); ?>%"></div></div>
                                </div>
                                <div class="ui-graph-row">
                                    <div class="ui-graph-head"><span>Open Vacancies</span><strong id="graphVacanciesValue"><?php echo number_format($openPositions); ?></strong></div>
                                    <div class="ui-graph-track"><div class="ui-graph-fill warning" id="graphVacanciesBar" style="width: <?php echo $openPositions * 10; ?>%"></div></div>
                                </div>
                                <div class="ui-graph-row">
                                    <div class="ui-graph-head"><span>Pending Requests</span><strong id="graphPendingValue"><?php echo number_format($openLeaveRequests); ?></strong></div>
                                    <div class="ui-graph-track"><div class="ui-graph-fill danger" id="graphPendingBar" style="width: <?php echo $openLeaveRequests * 3; ?>%"></div></div>
                                </div>
                                <div class="ui-graph-row">
                                    <div class="ui-graph-head"><span>In-Training</span><strong id="graphTrainingValue">0</strong></div>
                                    <div class="ui-graph-track"><div class="ui-graph-fill mint" id="graphTrainingBar" style="width: 0%"></div></div>
                                </div>
                                <div class="ui-graph-row">
                                    <div class="ui-graph-head"><span>Compliance Rate</span><strong id="graphComplianceValue">0%</strong></div>
                                    <div class="ui-graph-track"><div class="ui-graph-fill success" id="graphComplianceBar" style="width: 0%"></div></div>
                                </div>
                                <div class="ui-graph-row">
                                    <div class="ui-graph-head"><span>Talent Readiness</span><strong id="graphReadinessValue">0%</strong></div>
                                    <div class="ui-graph-track"><div class="ui-graph-fill info" id="graphReadinessBar" style="width: 0%"></div></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section class="row g-4 mb-4 content-section d-none" id="roleOverview">
                <div class="col-12">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header">
                            <h5 class="card-title mb-0" id="roleOverviewTitle">Submodule Workspace</h5>
                        </div>
                        <div class="card-body" id="roleModuleOverviewBody">
                            <p class="text-muted mb-0">Select a submodule from the sidebar to view its content.</p>
                        </div>
                    </div>
                </div>
            </section>

            <section class="row g-4 content-section">
                <div class="col-lg-7" id="employees">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="card-title mb-0" id="primaryCardTitle">Employee Directory</h5>
                            <button class="btn btn-sm btn-primary">Add Employee</button>
                        </div>
                        <div class="table-responsive">
                            <table class="table mb-0 align-middle">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Department</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    // Try to fetch employees from database
                                    try {
                                        if ($conn) {
                                            $stmt = $conn->query("SELECT name, department, status FROM employees LIMIT 3");
                                            if ($stmt && $stmt->rowCount() > 0) {
                                                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                                    $statusClass = '';
                                                    switch(strtolower($row['status'])) {
                                                        case 'active':
                                                            $statusClass = 'bg-success-subtle text-success';
                                                            break;
                                                        case 'probation':
                                                            $statusClass = 'bg-warning-subtle text-warning';
                                                            break;
                                                        default:
                                                            $statusClass = 'bg-secondary-subtle text-secondary';
                                                    }
                                                    echo '<tr>';
                                                    echo '<td>' . htmlspecialchars($row['name']) . '</td>';
                                                    echo '<td>' . htmlspecialchars($row['department']) . '</td>';
                                                    echo '<td><span class="badge ' . $statusClass . '">' . htmlspecialchars($row['status']) . '</span></td>';
                                                    echo '<td>
                                                            <button class="btn btn-link btn-sm"><i class="fas fa-eye"></i></button>
                                                            <button class="btn btn-link btn-sm"><i class="fas fa-edit"></i></button>
                                                          </td>';
                                                    echo '</tr>';
                                                }
                                            } else {
                                                // Fallback to sample data
                                                ?>
                                                <tr>
                                                    <td>Anna Santos</td>
                                                    <td>Human Resources</td>
                                                    <td><span class="badge bg-success-subtle text-success">Active</span></td>
                                                    <td>
                                                        <button class="btn btn-link btn-sm"><i class="fas fa-eye"></i></button>
                                                        <button class="btn btn-link btn-sm"><i class="fas fa-edit"></i></button>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Mark Rivera</td>
                                                    <td>Finance</td>
                                                    <td><span class="badge bg-warning-subtle text-warning">Probation</span></td>
                                                    <td>
                                                        <button class="btn btn-link btn-sm"><i class="fas fa-eye"></i></button>
                                                        <button class="btn btn-link btn-sm"><i class="fas fa-edit"></i></button>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Jude Molina</td>
                                                    <td>Operations</td>
                                                    <td><span class="badge bg-success-subtle text-success">Active</span></td>
                                                    <td>
                                                        <button class="btn btn-link btn-sm"><i class="fas fa-eye"></i></button>
                                                        <button class="btn btn-link btn-sm"><i class="fas fa-edit"></i></button>
                                                    </td>
                                                </tr>
                                                <?php
                                            }
                                        } else {
                                            // Connection failed, show sample data
                                            ?>
                                            <tr>
                                                <td>Anna Santos</td>
                                                <td>Human Resources</td>
                                                <td><span class="badge bg-success-subtle text-success">Active</span></td>
                                                <td>
                                                    <button class="btn btn-link btn-sm"><i class="fas fa-eye"></i></button>
                                                    <button class="btn btn-link btn-sm"><i class="fas fa-edit"></i></button>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Mark Rivera</td>
                                                <td>Finance</td>
                                                <td><span class="badge bg-warning-subtle text-warning">Probation</span></td>
                                                <td>
                                                    <button class="btn btn-link btn-sm"><i class="fas fa-eye"></i></button>
                                                    <button class="btn btn-link btn-sm"><i class="fas fa-edit"></i></button>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Jude Molina</td>
                                                <td>Operations</td>
                                                <td><span class="badge bg-success-subtle text-success">Active</span></td>
                                                <td>
                                                    <button class="btn btn-link btn-sm"><i class="fas fa-eye"></i></button>
                                                    <button class="btn btn-link btn-sm"><i class="fas fa-edit"></i></button>
                                                </td>
                                            </tr>
                                            <?php
                                        }
                                    } catch(PDOException $e) {
                                        // Error fetching data, show sample data
                                        ?>
                                        <tr>
                                            <td>Anna Santos</td>
                                            <td>Human Resources</td>
                                            <td><span class="badge bg-success-subtle text-success">Active</span></td>
                                            <td>
                                                <button class="btn btn-link btn-sm"><i class="fas fa-eye"></i></button>
                                                <button class="btn btn-link btn-sm"><i class="fas fa-edit"></i></button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Mark Rivera</td>
                                            <td>Finance</td>
                                            <td><span class="badge bg-warning-subtle text-warning">Probation</span></td>
                                            <td>
                                                <button class="btn btn-link btn-sm"><i class="fas fa-eye"></i></button>
                                                <button class="btn btn-link btn-sm"><i class="fas fa-edit"></i></button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Jude Molina</td>
                                            <td>Operations</td>
                                            <td><span class="badge bg-success-subtle text-success">Active</span></td>
                                            <td>
                                                <button class="btn btn-link btn-sm"><i class="fas fa-eye"></i></button>
                                                <button class="btn btn-link btn-sm"><i class="fas fa-edit"></i></button>
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="col-lg-5" id="leave">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-header">
                            <h5 class="card-title mb-0" id="secondaryCardTitle">Pending Leave Approvals</h5>
                        </div>
                        <div class="card-body">
                            <ul class="list-group list-group-flush">
                                <?php
                                // Try to fetch pending leave requests from database
                                try {
                                    if ($conn) {
                                        $stmt = $conn->query("SELECT employee_name, leave_type, days FROM leave_requests WHERE status = 'pending' LIMIT 3");
                                        if ($stmt && $stmt->rowCount() > 0) {
                                            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                                echo '<li class="list-group-item px-0 d-flex justify-content-between align-items-center">';
                                                echo '<div>';
                                                echo '<h6 class="mb-1">' . htmlspecialchars($row['employee_name']) . '</h6>';
                                                echo '<small class="text-muted">' . htmlspecialchars($row['leave_type']) . ' • ' . $row['days'] . ' days</small>';
                                                echo '</div>';
                                                echo '<span class="badge bg-warning-subtle text-warning">Pending</span>';
                                                echo '</li>';
                                            }
                                        } else {
                                            // Fallback to sample data
                                            ?>
                                            <li class="list-group-item px-0 d-flex justify-content-between align-items-center">
                                                <div>
                                                    <h6 class="mb-1">Maria Cruz</h6>
                                                    <small class="text-muted">Vacation Leave • 3 days</small>
                                                </div>
                                                <span class="badge bg-warning-subtle text-warning">Pending</span>
                                            </li>
                                            <li class="list-group-item px-0 d-flex justify-content-between align-items-center">
                                                <div>
                                                    <h6 class="mb-1">Leo Fernandez</h6>
                                                    <small class="text-muted">Sick Leave • 2 days</small>
                                                </div>
                                                <span class="badge bg-warning-subtle text-warning">Pending</span>
                                            </li>
                                            <li class="list-group-item px-0 d-flex justify-content-between align-items-center">
                                                <div>
                                                    <h6 class="mb-1">Pat Gomez</h6>
                                                    <small class="text-muted">Emergency Leave • 1 day</small>
                                                </div>
                                                <span class="badge bg-warning-subtle text-warning">Pending</span>
                                            </li>
                                            <?php
                                        }
                                    } else {
                                        // Connection failed, show sample data
                                        ?>
                                        <li class="list-group-item px-0 d-flex justify-content-between align-items-center">
                                            <div>
                                                <h6 class="mb-1">Maria Cruz</h6>
                                                <small class="text-muted">Vacation Leave • 3 days</small>
                                            </div>
                                            <span class="badge bg-warning-subtle text-warning">Pending</span>
                                        </li>
                                        <li class="list-group-item px-0 d-flex justify-content-between align-items-center">
                                            <div>
                                                <h6 class="mb-1">Leo Fernandez</h6>
                                                <small class="text-muted">Sick Leave • 2 days</small>
                                            </div>
                                            <span class="badge bg-warning-subtle text-warning">Pending</span>
                                        </li>
                                        <li class="list-group-item px-0 d-flex justify-content-between align-items-center">
                                            <div>
                                                <h6 class="mb-1">Pat Gomez</h6>
                                                <small class="text-muted">Emergency Leave • 1 day</small>
                                            </div>
                                            <span class="badge bg-warning-subtle text-warning">Pending</span>
                                        </li>
                                        <?php
                                    }
                                } catch(PDOException $e) {
                                    // Error fetching data, show sample data
                                    ?>
                                    <li class="list-group-item px-0 d-flex justify-content-between align-items-center">
                                        <div>
                                            <h6 class="mb-1">Maria Cruz</h6>
                                            <small class="text-muted">Vacation Leave • 3 days</small>
                                        </div>
                                        <span class="badge bg-warning-subtle text-warning">Pending</span>
                                    </li>
                                    <li class="list-group-item px-0 d-flex justify-content-between align-items-center">
                                        <div>
                                            <h6 class="mb-1">Leo Fernandez</h6>
                                            <small class="text-muted">Sick Leave • 2 days</small>
                                        </div>
                                        <span class="badge bg-warning-subtle text-warning">Pending</span>
                                    </li>
                                    <li class="list-group-item px-0 d-flex justify-content-between align-items-center">
                                        <div>
                                            <h6 class="mb-1">Pat Gomez</h6>
                                            <small class="text-muted">Emergency Leave • 1 day</small>
                                        </div>
                                        <span class="badge bg-warning-subtle text-warning">Pending</span>
                                    </li>
                                    <?php
                                }
                                ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </section>

            <section class="row g-4 mt-1 content-section">
                <div class="col-md-4" id="attendance">
                    <div class="card border-0 shadow-sm h-100 insight-card">
                        <div class="card-header"><h5 class="card-title mb-0"><i class="fas fa-user-check me-2"></i>Attendance</h5></div>
                        <div class="card-body">
                            <p class="metric-line mb-2"><span class="metric-label">Present Today</span><strong class="metric-value"><?php echo number_format($presentToday); ?></strong></p>
                            <p class="metric-line mb-2"><span class="metric-label">Late Entries</span><strong class="metric-value"><?php echo number_format($lateEntries); ?></strong></p>
                            <p class="metric-line mb-0"><span class="metric-label">On Leave</span><strong class="metric-value"><?php echo number_format($onLeave); ?></strong></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4" id="payroll">
                    <div class="card border-0 shadow-sm h-100 insight-card">
                        <div class="card-header"><h5 class="card-title mb-0"><i class="fas fa-wallet me-2"></i>Payroll</h5></div>
                        <div class="card-body">
                            <p class="metric-line mb-2"><span class="metric-label">Cut-off</span><strong class="metric-value">Feb 29, 2026</strong></p>
                            <p class="metric-line mb-2"><span class="metric-label">Processed</span><strong class="metric-value">231/<?php echo $totalEmployees; ?></strong></p>
                            <p class="metric-line mb-0"><span class="metric-label">Outstanding</span><strong class="metric-value">17</strong></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4" id="recruitment">
                    <div class="card border-0 shadow-sm h-100 insight-card">
                        <div class="card-header"><h5 class="card-title mb-0"><i class="fas fa-user-plus me-2"></i>Recruitment</h5></div>
                        <div class="card-body">
                            <p class="metric-line mb-2"><span class="metric-label">Open Positions</span><strong class="metric-value"><?php echo number_format($openPositions); ?></strong></p>
                            <p class="metric-line mb-2"><span class="metric-label">Interviews Today</span><strong class="metric-value"><?php echo number_format($interviewsToday); ?></strong></p>
                            <p class="metric-line mb-0"><span class="metric-label">Offers Sent</span><strong class="metric-value"><?php echo number_format($offersSent); ?></strong></p>
                        </div>
                    </div>
                </div>
            </section>

            <section class="row g-4 mt-1 content-section" id="documents">
                <div class="col-12">
                    <div class="card border-0 shadow-sm insight-card">
                        <div class="card-header"><h5 class="card-title mb-0"><i class="fas fa-folder-open me-2"></i>Documents</h5></div>
                        <div class="card-body">
                            <p class="metric-line mb-1"><span class="metric-label">Employee Files</span><strong class="metric-value"><?php echo number_format($totalEmployees); ?></strong></p>
                            <p class="metric-line mb-1"><span class="metric-label">Contracts Pending Signature</span><strong class="metric-value">7</strong></p>
                            <p class="metric-line mb-0"><span class="metric-label">Policy Updates This Month</span><strong class="metric-value">2</strong></p>
                        </div>
                    </div>
                </div>
            </section>

            <section class="row g-4 mt-1 content-section" id="settings">
                <div class="col-12">
                    <div class="card border-0 shadow-sm insight-card">
                        <div class="card-header"><h5 class="card-title mb-0"><i class="fas fa-gear me-2"></i>Settings</h5></div>
                        <div class="card-body">
                            <p class="metric-line mb-1"><span class="metric-label">Access Control</span><strong class="metric-value">Role-based</strong></p>
                            <p class="metric-line mb-1"><span class="metric-label">Notification Preferences</span><strong class="metric-value">Enabled</strong></p>
                            <p class="metric-line mb-0"><span class="metric-label">System Timezone</span><strong class="metric-value">Asia/Manila</strong></p>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Combined JavaScript includes - fixed paths and formatting -->
    <script src="assets/js/modules/applicant-management/submodules/applicant-list.js"></script>
    <script src="assets/js/modules/applicant-management/submodules/application-tracking.js"></script>
    <script src="assets/js/modules/applicant-management/submodules/interview-scheduling.js"></script>
    <script src="assets/js/modules/applicant-management/submodules/applicant-status-monitoring.js"></script>
    <script src="assets/js/modules/recruitment-management/submodules/job-posting-management.js"></script>
    <script src="assets/js/modules/recruitment-management/submodules/vacancy-requests.js"></script>
    <script src="assets/js/modules/recruitment-management/submodules/candidate-shortlisting.js"></script>
    <script src="assets/js/modules/recruitment-management/submodules/hiring-approval.js"></script>
    <script src="assets/js/modules/new-hire-onboarding/submodules/pre-employment-requirements.js"></script>
    <script src="assets/js/modules/new-hire-onboarding/submodules/document-submission.js"></script>
    <script src="assets/js/modules/new-hire-onboarding/submodules/contract-management.js"></script>
    <script src="assets/js/modules/new-hire-onboarding/submodules/orientation-scheduling.js"></script>
    <script src="assets/js/modules/performance-management/submodules/probation-evaluation.js"></script>
    <script src="assets/js/modules/performance-management/submodules/initial-kpi-setup.js"></script>
    <script src="assets/js/modules/performance-management/submodules/evaluation-results.js"></script>
    <script src="assets/js/modules/social-recognition/submodules/employee-recognition.js"></script>
    <script src="assets/js/modules/social-recognition/submodules/awards-commendations.js"></script>
    <script src="assets/js/modules/social-recognition/submodules/recognition-history.js"></script>
    <script src="assets/js/modules/competency-management/submodules/skill-inventory.js"></script>
    <script src="assets/js/modules/competency-management/submodules/competency-assessment.js"></script>
    <script src="assets/js/modules/competency-management/submodules/competency-gap-analysis.js"></script>
    <script src="assets/js/modules/learning-management/submodules/course-catalog.js"></script>
    <script src="assets/js/modules/learning-management/submodules/assigned-courses.js"></script>
    <script src="assets/js/modules/learning-management/submodules/course-completion-tracking.js"></script>
    <script src="assets/js/modules/learning-management/submodules/certifications.js"></script>
    <script src="assets/js/modules/training-management/submodules/training-programs.js"></script>
    <script src="assets/js/modules/training-management/submodules/training-schedule.js"></script>
    <script src="assets/js/modules/training-management/submodules/training-attendance.js"></script>
    <script src="assets/js/modules/training-management/submodules/training-evaluation.js"></script>
    <script src="assets/js/modules/succession-planning/submodules/position-planning.js"></script>
    <script src="assets/js/modules/succession-planning/submodules/successor-identification.js"></script>
    <script src="assets/js/modules/succession-planning/submodules/readiness-assessment.js"></script>
    <script src="assets/js/modules/employee-self-service/submodules/view-profile.js"></script>
    <script src="assets/js/modules/employee-self-service/submodules/update-personal-info.js"></script>
    <script src="assets/js/modules/employee-self-service/submodules/submit-requests.js"></script>
    <script src="assets/js/modules/employee-self-service/submodules/view-employment-records.js"></script>
    <script src="assets/js/modules/time-and-attendance-system/submodules/attendance-monitoring.js"></script>
    <script src="assets/js/modules/time-and-attendance-system/submodules/attendance-validation.js"></script>
    <script src="assets/js/modules/time-and-attendance-system/submodules/attendance-reports.js"></script>
    <script src="assets/js/modules/time-and-attendance-system/submodules/correction-requests.js"></script>
    <script src="assets/js/modules/shift-and-schedule-management/submodules/shift-creation.js"></script>
    <script src="assets/js/modules/shift-and-schedule-management/submodules/staff-scheduling.js"></script>
    <script src="assets/js/modules/shift-and-schedule-management/submodules/shift-assignment.js"></script>
    <script src="assets/js/modules/shift-and-schedule-management/submodules/schedule-reports.js"></script>
    <script src="assets/js/modules/timesheet-management/submodules/timesheet-submission.js"></script>
    <script src="assets/js/modules/timesheet-management/submodules/timesheet-approval.js"></script>
    <script src="assets/js/modules/timesheet-management/submodules/overtime-tracking.js"></script>
    <script src="assets/js/modules/leave-management/submodules/leave-dashboard.js"></script>
    <script src="assets/js/modules/leave-management/submodules/leave-request.js"></script>
    <script src="assets/js/modules/leave-management/submodules/leave-approval.js"></script>
    <script src="assets/js/modules/leave-management/submodules/leave-balance.js"></script>
    <script src="assets/js/modules/leave-management/submodules/leave-reports.js"></script>
    <script src="assets/js/modules/claims-and-reimbursement/submodules/claim-submission.js"></script>
    <script src="assets/js/modules/claims-and-reimbursement/submodules/claim-review.js"></script>
    <script src="assets/js/modules/claims-and-reimbursement/submodules/reimbursement-processing.js"></script>
    <script src="assets/js/modules/claims-and-reimbursement/submodules/claim-history.js"></script>
    <script src="assets/js/modules/core-human-capital-management/submodules/employee-master-data.js"></script>
    <script src="assets/js/modules/core-human-capital-management/submodules/employment-records.js"></script>
    <script src="assets/js/modules/core-human-capital-management/submodules/position-management.js"></script>
    <script src="assets/js/modules/core-human-capital-management/submodules/organizational-structure.js"></script>
    <script src="assets/js/modules/payroll-management/submodules/payroll-processing.js"></script>
    <script src="assets/js/modules/payroll-management/submodules/salary-computation.js"></script>
    <script src="assets/js/modules/payroll-management/submodules/payslip-generation.js"></script>
    <script src="assets/js/modules/payroll-management/submodules/payroll-reports.js"></script>
    <script src="assets/js/modules/compensation-planning/submodules/salary-adjustment.js"></script>
    <script src="assets/js/modules/compensation-planning/submodules/incentive-management.js"></script>
    <script src="assets/js/modules/compensation-planning/submodules/bonus-allocation.js"></script>
    <script src="assets/js/modules/hr-analytics-dashboard/submodules/workforce-reports.js"></script>
    <script src="assets/js/modules/hr-analytics-dashboard/submodules/turnover-analysis.js"></script>
    <script src="assets/js/modules/hr-analytics-dashboard/submodules/attendance-analytics.js"></script>
    <script src="assets/js/modules/hr-analytics-dashboard/submodules/performance-metrics.js"></script>
    <script src="assets/js/modules/hmo-benefits-administration/submodules/hmo-enrollment.js"></script>
    <script src="assets/js/modules/hmo-benefits-administration/submodules/benefits-management.js"></script>
    <script src="assets/js/modules/hmo-benefits-administration/submodules/benefits-claims.js"></script>
    <script src="assets/js/modules/hmo-benefits-administration/submodules/benefits-reports.js"></script>
    <script src="assets/js/main.js"></script>

    <script>
        // Auto-hide connection status after 5 seconds
        setTimeout(function() {
            var statusDiv = document.querySelector('.connection-status');
            if (statusDiv) {
                statusDiv.style.transition = 'opacity 1s';
                statusDiv.style.opacity = '0';
                setTimeout(function() {
                    statusDiv.style.display = 'none';
                }, 1000);
            }
        }, 5000);
        
        // Logout functionality
        document.getElementById('logoutButton').addEventListener('click', function(e) {
            e.preventDefault();
            window.location.href = 'logout.php';
        });
    </script>
</body>
</html>