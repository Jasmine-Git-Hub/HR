/**
 * Successor Identification Submodule
 * Professional Talent Bench & Readiness Mapping
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrSuccessors';

    const getSuccessors = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Baseline Talent Bench Data
        return [
            { id: "TAL-01", name: "Dr. Sarah Chen", targetRole: "Chief Nursing Officer", readiness: "Ready Now", potential: "High", performance: "Exceeding" },
            { id: "TAL-02", name: "Robert Miller", targetRole: "IT Infrastructure Director", readiness: "1-2 Years", potential: "Medium", performance: "Consistent" },
            { id: "TAL-03", name: "Nurse Elena Rodriguez", targetRole: "Nursing Admin Manager", readiness: "Ready Now", potential: "High", performance: "Exceeding" }
        ];
    };

    function ensureSuccessorModalHost() {
        if (document.getElementById('successorIdentificationModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="successorIdentificationModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="successorIdentificationModalTitle">Successor Identification</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="successorIdentificationModalBody"></div>',
            '      <div class="modal-footer" id="successorIdentificationModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showSuccessorInfo(title, message) {
        const modalEl = document.getElementById('successorIdentificationModal');
        const titleEl = document.getElementById('successorIdentificationModalTitle');
        const bodyEl = document.getElementById('successorIdentificationModalBody');
        const footerEl = document.getElementById('successorIdentificationModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderSuccessorIdentification = function (container) {
        ensureSuccessorModalHost();

        const successors = getSuccessors();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-user-graduate text-success me-2"></i>Talent Bench & Successor Pool</h6>
                        <small class="text-muted text-uppercase extra-small" style="letter-spacing: 1px;">Identifying Future Leadership Capacity</small>
                    </div>
                    <button class="btn btn-success btn-sm rounded-pill px-4 shadow-sm" onclick="window.HRSubmodules.nominateSuccessor()">
                        <i class="fas fa-user-plus me-1"></i> Nominate Successor
                    </button>
                </div>

                <div class="table-responsive border rounded-3 bg-white shadow-sm">
                    <table class="table table-hover align-middle mb-0 custom-talent-table">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4" style="width: 25%">Candidate</th>
                                <th style="width: 25%">Target Role</th>
                                <th style="width: 15%">Readiness</th>
                                <th style="width: 15%">Potential</th>
                                <th class="text-end pe-4" style="width: 20%">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${successors.map(person => `
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark">${person.name}</div>
                                        <div class="extra-small text-muted">Perf: ${person.performance}</div>
                                    </td>
                                    <td>
                                        <div class="small fw-semibold text-primary">${person.targetRole}</div>
                                    </td>
                                    <td>
                                        <span class="readiness-tag ${person.readiness.replace(/\s+/g, '-').toLowerCase()}">
                                            ${person.readiness}
                                        </span>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="potential-bar flex-grow-1 me-2">
                                                <div class="potential-fill ${person.potential.toLowerCase()}" style="width: ${person.potential === 'High' ? '100%' : '60%'}"></div>
                                            </div>
                                            <span class="extra-small fw-bold">${person.potential}</span>
                                        </div>
                                    </td>
                                    <td class="text-end pe-4">
                                        <button class="btn btn-sm btn-outline-secondary py-0 px-2" onclick="window.HRSubmodules.openDevelopmentPlan('${person.id}')">
                                            <i class="fas fa-chart-line"></i>
                                        </button>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    };

    window.HRSubmodules.nominateSuccessor = function() {
        const modalEl = document.getElementById('successorIdentificationModal');
        const titleEl = document.getElementById('successorIdentificationModalTitle');
        const bodyEl = document.getElementById('successorIdentificationModalBody');
        const footerEl = document.getElementById('successorIdentificationModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Nominate Successor';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Candidate Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="successorCandidateName" placeholder="e.g. Dr. Sarah Chen">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Target Future Role</label>',
            '  <input type="text" class="form-control form-control-sm" id="successorTargetRole" placeholder="e.g. Chief Nursing Officer">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Potential</label>',
            '  <select class="form-select form-select-sm" id="successorPotential">',
            '    <option value="High">High</option>',
            '    <option value="Medium">Medium</option>',
            '    <option value="TBD">TBD</option>',
            '  </select>',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-success" id="saveSuccessorNominationBtn">Save</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const saveBtn = document.getElementById('saveSuccessorNominationBtn');
        if (saveBtn) {
            saveBtn.addEventListener('click', function () {
                const name = (document.getElementById('successorCandidateName').value || '').trim();
                const role = (document.getElementById('successorTargetRole').value || '').trim();
                const potential = (document.getElementById('successorPotential').value || '').trim() || 'TBD';
                if (!name || !role) {
                    return;
                }

                let successors = getSuccessors();
                successors.unshift({
                    id: 'TAL-' + Math.floor(10 + Math.random() * 89),
                    name: name,
                    targetRole: role,
                    readiness: 'Emergency Only',
                    potential: potential,
                    performance: 'Under Review'
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(successors));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderSuccessorIdentification(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showSuccessorInfo('Nomination Saved', name + ' was added to the successor pool.');
            });
        }

        modal.show();
    };

    window.HRSubmodules.openDevelopmentPlan = function (successorId) {
        const successors = getSuccessors();
        const target = successors.find(function (person) { return person.id === successorId; });
        if (!target) {
            return;
        }

        showSuccessorInfo('Development Plan', 'Opening development plan for ' + target.name + ' toward ' + target.targetRole + '.');
    };
})();