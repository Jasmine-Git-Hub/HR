/**
 * Orientation Scheduling Submodule
 * Professional Induction & Training Coordinator
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrOrientations';

    const getSessions = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Default Professional Orientation Schedule
        return [
            { id: "ORI-101", title: "General Hospital Induction", date: "2026-03-10", time: "09:00 AM", venue: "Main Conference Hall", facilitator: "Director Maria Santos", status: "Scheduled" },
            { id: "ORI-102", title: "Nurse Protocol Training", date: "2026-03-12", time: "01:30 PM", venue: "Training Room B", facilitator: "Head Nurse Sarah J.", status: "Confirmed" }
        ];
    };

    function ensureOrientationModalHost() {
        if (document.getElementById('orientationSchedulingModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="orientationSchedulingModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="orientationSchedulingModalTitle">Orientation Scheduling</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="orientationSchedulingModalBody"></div>',
            '      <div class="modal-footer" id="orientationSchedulingModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showOrientationInfo(title, message) {
        const modalEl = document.getElementById('orientationSchedulingModal');
        const titleEl = document.getElementById('orientationSchedulingModalTitle');
        const bodyEl = document.getElementById('orientationSchedulingModalBody');
        const footerEl = document.getElementById('orientationSchedulingModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderOrientationScheduling = function (container) {
        ensureOrientationModalHost();

        const sessions = getSessions();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-calendar-alt text-primary me-2"></i>Induction Schedule</h6>
                        <small class="text-muted">Coordinate orientation dates for newly onboarded staff</small>
                    </div>
                    <button class="btn btn-primary btn-sm rounded-pill px-3" onclick="window.HRSubmodules.addNewOrientation()">
                        <i class="fas fa-plus me-1"></i> Schedule Session
                    </button>
                </div>

                <div class="row g-3">
                    ${sessions.map(session => `
                        <div class="col-12">
                            <div class="orientation-card p-3 border rounded-3 bg-white shadow-sm">
                                <div class="row align-items-center">
                                    <div class="col-md-2 border-end text-center">
                                        <div class="fw-bold text-primary mb-0">${session.date.split('-')[2]} ${new Date(session.date).toLocaleString('default', { month: 'short' })}</div>
                                        <div class="small text-muted">${session.time}</div>
                                    </div>
                                    
                                    <div class="col-md-7 ps-md-4">
                                        <h6 class="fw-bold mb-1 text-dark">${session.title}</h6>
                                        <div class="d-flex gap-3 flex-wrap">
                                            <span class="small text-muted"><i class="fas fa-map-marker-alt me-1 text-danger"></i> ${session.venue}</span>
                                            <span class="small text-muted"><i class="fas fa-user-tie me-1 text-info"></i> ${session.facilitator}</span>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-3 text-end">
                                        <span class="badge-status ${session.status.toLowerCase()} mb-2 d-inline-block">${session.status}</span>
                                        <div class="d-flex justify-content-end gap-2">
                                            <button class="btn btn-xs btn-outline-secondary" onclick="window.HRSubmodules.sendOrientationInvite('${session.id}')"><i class="fas fa-envelope"></i> Invite</button>
                                            <button class="btn btn-xs btn-outline-danger" onclick="window.HRSubmodules.deleteOrientation('${session.id}')"><i class="fas fa-trash"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.addNewOrientation = function() {
        const modalEl = document.getElementById('orientationSchedulingModal');
        const titleEl = document.getElementById('orientationSchedulingModalTitle');
        const bodyEl = document.getElementById('orientationSchedulingModalBody');
        const footerEl = document.getElementById('orientationSchedulingModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Schedule Orientation Session';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Session Title</label>',
            '  <input type="text" class="form-control form-control-sm" id="oriSessionTitle" placeholder="e.g. Safety Orientation">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Date</label>',
            '  <input type="date" class="form-control form-control-sm" id="oriSessionDate">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Venue</label>',
            '  <input type="text" class="form-control form-control-sm" id="oriSessionVenue" value="To Be Announced">',
            '</div>'
        ].join('');

        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="oriSessionCreateBtn">Create Session</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const createBtn = document.getElementById('oriSessionCreateBtn');
        if (createBtn) {
            createBtn.addEventListener('click', function () {
                const sessionTitle = (document.getElementById('oriSessionTitle').value || '').trim();
                const sessionDate = (document.getElementById('oriSessionDate').value || '').trim();
                const sessionVenue = (document.getElementById('oriSessionVenue').value || '').trim() || 'To Be Announced';

                if (!sessionTitle || !sessionDate) {
                    return;
                }

                let sessions = getSessions();
                sessions.push({
                    id: 'ORI-' + Math.floor(Math.random() * 900),
                    title: sessionTitle,
                    date: sessionDate,
                    time: '09:00 AM',
                    venue: sessionVenue,
                    facilitator: 'HR Coordinator',
                    status: 'Scheduled'
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(sessions));
                window.HRSubmodules.renderOrientationScheduling(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showOrientationInfo('Session Scheduled', 'Orientation session "' + sessionTitle + '" was added successfully.');
            });
        }

        modal.show();
    };

    window.HRSubmodules.deleteOrientation = function(id) {
        const sessions = getSessions();
        const target = sessions.find(function (session) {
            return session.id === id;
        });

        if (!target) {
            return;
        }

        const modalEl = document.getElementById('orientationSchedulingModal');
        const titleEl = document.getElementById('orientationSchedulingModalTitle');
        const bodyEl = document.getElementById('orientationSchedulingModalBody');
        const footerEl = document.getElementById('orientationSchedulingModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Cancel Session';
        bodyEl.innerHTML = '<p class="mb-0">Cancel orientation session <strong>' + target.title + '</strong> scheduled on ' + target.date + '?</p>';
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">No</button>',
            '<button type="button" class="btn btn-danger" id="oriDeleteConfirmBtn">Yes, Cancel</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const deleteBtn = document.getElementById('oriDeleteConfirmBtn');
        if (deleteBtn) {
            deleteBtn.addEventListener('click', function () {
                const updated = getSessions().filter(function (session) {
                    return session.id !== id;
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
                window.HRSubmodules.renderOrientationScheduling(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
            });
        }

        modal.show();
    };

    window.HRSubmodules.sendOrientationInvite = function(id) {
        const sessions = getSessions();
        const target = sessions.find(function (session) {
            return session.id === id;
        });

        if (!target) {
            return;
        }

        showOrientationInfo('Invite Sent', 'Invitation has been queued for "' + target.title + '" at ' + target.time + '.');
    };

})();