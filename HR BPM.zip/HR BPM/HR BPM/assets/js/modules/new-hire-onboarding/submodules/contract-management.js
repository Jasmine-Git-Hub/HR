/**
 * Contract Management Submodule
 * Professional Legal Document Workflow
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrContracts';

    // Helper: Initialize or fetch data
    const getContracts = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Professional Mock Data for Medical Contracts
        return [
            { id: "CON-2026-001", name: "Dr. Aris Thorne", type: "Full-Time Physician", status: "Executed", date: "2026-03-01" },
            { id: "CON-2026-002", name: "Sarah Jenkins", type: "Nursing Head", status: "Sent for Signature", date: "2026-03-05" },
            { id: "CON-2026-003", name: "James Miller", type: "Radiology Tech", status: "Drafting", date: "2026-03-06" }
        ];
    };

    function ensureContractModalHost() {
        if (document.getElementById('contractManagementModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="contractManagementModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="contractManagementModalTitle">Contract Management</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="contractManagementModalBody"></div>',
            '      <div class="modal-footer" id="contractManagementModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showContractInfo(title, message) {
        const modalEl = document.getElementById('contractManagementModal');
        const titleEl = document.getElementById('contractManagementModalTitle');
        const bodyEl = document.getElementById('contractManagementModalBody');
        const footerEl = document.getElementById('contractManagementModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderContractManagement = function (container) {
        ensureContractModalHost();

        const contracts = getContracts();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-file-signature text-primary me-2"></i>Contract Lifecycle</h6>
                        <small class="text-muted">Manage employment agreements and legal terms</small>
                    </div>
                    <button class="btn btn-primary btn-sm px-3" onclick="window.HRSubmodules.createNewContract()">
                        <i class="fas fa-plus me-1"></i> New Contract
                    </button>
                </div>

                <div class="row g-3">
                    ${contracts.map(con => `
                        <div class="col-xl-4 col-md-6">
                            <div class="contract-card p-3 border rounded-3 bg-white h-100 position-relative">
                                <div class="d-flex justify-content-between mb-2">
                                    <span class="text-muted extra-small fw-bold">${con.id}</span>
                                    <span class="badge-status ${con.status.replace(/\s+/g, '-').toLowerCase()}">${con.status}</span>
                                </div>
                                
                                <h6 class="fw-bold text-dark text-truncate mb-1" title="${con.name}">${con.name}</h6>
                                <p class="text-primary small mb-3">${con.type}</p>
                                
                                <div class="d-flex justify-content-between align-items-center pt-2 border-top">
                                    <span class="text-muted" style="font-size: 11px;">Updated: ${con.date}</span>
                                    <div class="action-btns">
                                        ${con.status === 'Drafting' ? 
                                            `<button class="btn btn-xs btn-outline-primary" onclick="window.HRSubmodules.updateContractStatus('${con.id}', 'Sent for Signature')">Send</button>` : 
                                            `<button class="btn btn-xs btn-light text-primary" onclick="window.HRSubmodules.viewContract('${con.id}')"><i class="fas fa-eye"></i></button>`
                                        }
                                        ${con.status === 'Sent for Signature' ? 
                                            `<button class="btn btn-xs btn-success" onclick="window.HRSubmodules.updateContractStatus('${con.id}', 'Executed')">Mark Signed</button>` : ''
                                        }
                                    </div>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.updateContractStatus = function(id, newStatus) {
        let contracts = getContracts();
        const idx = contracts.findIndex(c => c.id === id);
        if (idx !== -1) {
            const candidateName = contracts[idx].name;
            contracts[idx].status = newStatus;
            contracts[idx].date = new Date().toLocaleDateString();
            localStorage.setItem(STORAGE_KEY, JSON.stringify(contracts));
            this.renderContractManagement(document.getElementById('roleModuleOverviewBody'));
            showContractInfo('Contract Updated', candidateName + ' contract is now marked as ' + newStatus + '.');
        }
    };

    window.HRSubmodules.createNewContract = function() {
        const modalEl = document.getElementById('contractManagementModal');
        const titleEl = document.getElementById('contractManagementModalTitle');
        const bodyEl = document.getElementById('contractManagementModalBody');
        const footerEl = document.getElementById('contractManagementModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Create New Contract';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Candidate Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="contractCandidateName" placeholder="e.g. John Doe">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Agreement Type</label>',
            '  <input type="text" class="form-control form-control-sm" id="contractAgreementType" value="Standard Employment Agreement">',
            '</div>'
        ].join('');

        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="contractCreateConfirm">Create</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const createBtn = document.getElementById('contractCreateConfirm');
        if (createBtn) {
            createBtn.addEventListener('click', function () {
                const name = (document.getElementById('contractCandidateName').value || '').trim();
                const type = (document.getElementById('contractAgreementType').value || '').trim() || 'Standard Employment Agreement';
                if (!name) {
                    return;
                }

                let contracts = getContracts();
                contracts.unshift({
                    id: 'CON-2026-' + Math.floor(100 + Math.random() * 900),
                    name: name,
                    type: type,
                    status: 'Drafting',
                    date: new Date().toLocaleDateString()
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(contracts));
                window.HRSubmodules.renderContractManagement(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showContractInfo('Contract Created', 'New contract draft has been created for ' + name + '.');
            });
        }

        modal.show();
    };

    window.HRSubmodules.viewContract = function(id) {
        const contracts = getContracts();
        const target = contracts.find(function (contract) {
            return contract.id === id;
        });

        if (!target) {
            return;
        }

        showContractInfo('Contract Preview', target.name + ' - ' + target.type + ' (' + target.status + ').');
    };

})();