/**
 * Assigned Courses Submodule
 * Professional Enrollment & Progress Tracking
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrAssignedCourses';

    const getAssignments = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Initial Professional Enrollment Data
        return [
            { id: "ENR-001", name: "Dr. Aris Thorne", course: "Advanced Life Support", progress: 75, deadline: "2026-04-01", status: "In Progress" },
            { id: "ENR-002", name: "Sarah Jenkins", course: "Patient Privacy & HIPAA", progress: 100, deadline: "2026-03-15", status: "Completed" },
            { id: "ENR-003", name: "James Miller", course: "Radiology Safety", progress: 10, deadline: "2026-03-20", status: "Overdue" }
        ];
    };

    function ensureAssignedCoursesModalHost() {
        if (document.getElementById('assignedCoursesModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="assignedCoursesModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="assignedCoursesModalTitle">Training Assignments</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="assignedCoursesModalBody"></div>',
            '      <div class="modal-footer" id="assignedCoursesModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showAssignedCoursesInfo(title, message) {
        const modalEl = document.getElementById('assignedCoursesModal');
        const titleEl = document.getElementById('assignedCoursesModalTitle');
        const bodyEl = document.getElementById('assignedCoursesModalBody');
        const footerEl = document.getElementById('assignedCoursesModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderAssignedCourses = function (container) {
        ensureAssignedCoursesModalHost();

        const data = getAssignments();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-tasks text-warning me-2"></i>Training Assignments</h6>
                        <small class="text-muted">Monitor employee enrollment and completion rates</small>
                    </div>
                    <div class="d-flex gap-2">
                        <button class="btn btn-outline-dark btn-sm" onclick="window.HRSubmodules.exportEnrollment()">
                            <i class="fas fa-download me-1"></i> Export
                        </button>
                        <button class="btn btn-primary btn-sm px-3" onclick="window.HRSubmodules.assignNewCourse()">
                            <i class="fas fa-user-plus me-1"></i> Assign Course
                        </button>
                    </div>
                </div>

                <div class="table-responsive border rounded-3 bg-white shadow-sm overflow-hidden">
                    <table class="table table-hover align-middle mb-0 custom-assign-table">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4" style="width: 25%">Employee</th>
                                <th style="width: 25%">Course Title</th>
                                <th style="width: 30%">Progress</th>
                                <th class="text-end pe-4" style="width: 20%">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${data.map(item => `
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark">${item.name}</div>
                                        <div class="extra-small text-muted">ID: ${item.id}</div>
                                    </td>
                                    <td>
                                        <div class="text-dark small fw-medium">${item.course}</div>
                                        <div class="extra-small text-muted">Due: ${item.deadline}</div>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="progress flex-grow-1" style="height: 6px; border-radius: 10px;">
                                                <div class="progress-bar ${getProgressColor(item.status)}" 
                                                     role="progressbar" style="width: ${item.progress}%"></div>
                                            </div>
                                            <span class="extra-small fw-bold text-muted" style="min-width: 35px;">${item.progress}%</span>
                                        </div>
                                    </td>
                                    <td class="text-end pe-4">
                                        <span class="status-badge ${item.status.toLowerCase().replace(/\s+/g, '-')}">
                                            ${item.status}
                                        </span>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    };

    function getProgressColor(status) {
        if (status === 'Completed') return 'bg-success';
        if (status === 'Overdue') return 'bg-danger';
        return 'bg-warning';
    }

    window.HRSubmodules.exportEnrollment = function () {
        const data = getAssignments();
        showAssignedCoursesInfo('Export Enrollment', 'Prepared ' + data.length + ' assignment records for export.');
    };

    window.HRSubmodules.assignNewCourse = function() {
        const modalEl = document.getElementById('assignedCoursesModal');
        const titleEl = document.getElementById('assignedCoursesModalTitle');
        const bodyEl = document.getElementById('assignedCoursesModalBody');
        const footerEl = document.getElementById('assignedCoursesModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Assign New Course';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Staff Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="assignCourseStaff" placeholder="e.g. Sarah Jenkins">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Course Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="assignCourseName" placeholder="e.g. HIPAA Basics">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Deadline</label>',
            '  <input type="date" class="form-control form-control-sm" id="assignCourseDeadline" value="' + new Date(Date.now() + 12096e5).toISOString().split('T')[0] + '">',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="assignCourseCreateBtn">Assign</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const createBtn = document.getElementById('assignCourseCreateBtn');
        if (createBtn) {
            createBtn.addEventListener('click', function () {
                const name = (document.getElementById('assignCourseStaff').value || '').trim();
                const course = (document.getElementById('assignCourseName').value || '').trim();
                const deadline = (document.getElementById('assignCourseDeadline').value || '').trim();
                if (!name || !course || !deadline) {
                    return;
                }

                let data = getAssignments();
                data.unshift({
                    id: 'ENR-' + Math.floor(100 + Math.random() * 900),
                    name: name,
                    course: course,
                    progress: 0,
                    deadline: deadline,
                    status: 'In Progress'
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderAssignedCourses(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showAssignedCoursesInfo('Course Assigned', course + ' has been assigned to ' + name + '.');
            });
        }

        modal.show();
    };
})();