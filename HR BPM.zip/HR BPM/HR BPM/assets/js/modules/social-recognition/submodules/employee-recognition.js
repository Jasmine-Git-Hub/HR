/**
 * Employee Recognition Submodule
 * Professional "Wall of Fame" and Award System
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrRecognitions';

    const getAwards = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Default Recognition Data
        return [
            { id: "AWARD-001", name: "Dr. Aris Thorne", award: "Physician of the Month", date: "2026-02-28", icon: "fa-stethoscopes", color: "#0d6efd" },
            { id: "AWARD-002", name: "Sarah Jenkins", award: "Leadership Excellence", date: "2026-03-01", icon: "fa-star", color: "#ffc107" },
            { id: "AWARD-003", name: "James Miller", award: "Service Reliability", date: "2026-03-04", icon: "fa-check-circle", color: "#198754" }
        ];
    };

    function ensureRecognitionModalHost() {
        if (document.getElementById('employeeRecognitionModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="employeeRecognitionModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="employeeRecognitionModalTitle">Employee Recognition</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="employeeRecognitionModalBody"></div>',
            '      <div class="modal-footer" id="employeeRecognitionModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showRecognitionInfo(title, message) {
        const modalEl = document.getElementById('employeeRecognitionModal');
        const titleEl = document.getElementById('employeeRecognitionModalTitle');
        const bodyEl = document.getElementById('employeeRecognitionModalBody');
        const footerEl = document.getElementById('employeeRecognitionModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderEmployeeRecognition = function (container) {
        ensureRecognitionModalHost();

        const awards = getAwards();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-trophy text-warning me-2"></i>Employee Recognition</h6>
                        <small class="text-muted">Celebrating excellence and commitment in healthcare</small>
                    </div>
                    <button class="btn btn-primary btn-sm rounded-pill px-4" onclick="window.HRSubmodules.nominateStaff()">
                        <i class="fas fa-medal me-1"></i> Nominate Staff
                    </button>
                </div>

                <div class="row g-4">
                    ${awards.map(item => `
                        <div class="col-xl-4 col-md-6">
                            <div class="recognition-card p-4 border rounded-4 bg-white shadow-sm text-center">
                                <div class="award-icon-wrapper mb-3" style="background-color: ${item.color}15; color: ${item.color};">
                                    <i class="fas ${item.icon} fa-2x"></i>
                                </div>
                                <h5 class="fw-bold text-dark mb-1">${item.name}</h5>
                                <p class="text-primary fw-semibold mb-3 small text-uppercase">${item.award}</p>
                                
                                <div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top">
                                    <span class="text-muted extra-small">ID: ${item.id}</span>
                                    <span class="text-muted extra-small"><i class="far fa-calendar-alt me-1"></i>${item.date}</span>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.nominateStaff = function() {
        const modalEl = document.getElementById('employeeRecognitionModal');
        const titleEl = document.getElementById('employeeRecognitionModalTitle');
        const bodyEl = document.getElementById('employeeRecognitionModalBody');
        const footerEl = document.getElementById('employeeRecognitionModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Nominate Staff';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Staff Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="recognitionStaffName" placeholder="e.g. Maria Santos">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Award Title</label>',
            '  <input type="text" class="form-control form-control-sm" id="recognitionAwardTitle" placeholder="e.g. Service Excellence">',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="recognitionNominateBtn">Submit Nomination</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const nominateBtn = document.getElementById('recognitionNominateBtn');
        if (nominateBtn) {
            nominateBtn.addEventListener('click', function () {
                const name = (document.getElementById('recognitionStaffName').value || '').trim();
                const awardType = (document.getElementById('recognitionAwardTitle').value || '').trim();
                if (!name || !awardType) {
                    return;
                }

                let awards = getAwards();
                awards.unshift({
                    id: 'AWARD-' + Math.floor(100 + Math.random() * 900),
                    name: name,
                    award: awardType,
                    date: new Date().toLocaleDateString(),
                    icon: 'fa-award',
                    color: '#6f42c1'
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(awards));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderEmployeeRecognition(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showRecognitionInfo('Nomination Submitted', name + ' has been nominated for ' + awardType + '.');
            });
        }

        modal.show();
    };

})();