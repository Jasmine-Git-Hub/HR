window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const CLAIMS_RECORDS_KEY = 'hospitalHrClaimsRecords';

    function ensureReimbursementProcessingModalHost() {
        if (document.getElementById('reimbursementProcessingModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="reimbursementProcessingModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="reimbursementProcessingModalTitle">Reimbursement Processing</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="reimbursementProcessingModalBody"></div>',
            '      <div class="modal-footer" id="reimbursementProcessingModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showReimbursementProcessingModal(config) {
        const modalEl = document.getElementById('reimbursementProcessingModal');
        const titleEl = document.getElementById('reimbursementProcessingModalTitle');
        const bodyEl = document.getElementById('reimbursementProcessingModalBody');
        const footerEl = document.getElementById('reimbursementProcessingModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    function defaultClaims() {
        return [
            { id: 'CLM-801', employee: 'Anna Santos', category: 'Medical', amount: 2500, date: '2026-02-25', notes: 'Outpatient consultation', status: 'Submitted', reimbursed: false },
            { id: 'CLM-802', employee: 'Jude Molina', category: 'Transportation', amount: 850, date: '2026-02-26', notes: 'Official field visit', status: 'Approved', reimbursed: true },
            { id: 'CLM-803', employee: 'Leah Gomez', category: 'Training', amount: 3200, date: '2026-02-28', notes: 'Certification course', status: 'Under Review', reimbursed: false }
        ];
    }

    function getStorageList(key, fallbackFn) {
        const raw = localStorage.getItem(key);
        const fallback = fallbackFn();
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback;
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderReimbursementProcessing = function (container) {
        ensureReimbursementProcessingModalHost();

        let claims = getStorageList(CLAIMS_RECORDS_KEY, defaultClaims);

        function render() {
            const approvedPending = claims.filter(function (item) {
                return item.status === 'Approved' && item.reimbursed !== true;
            });

            const processedAmount = claims
                .filter(function (item) { return item.reimbursed === true; })
                .reduce(function (sum, item) { return sum + Number(item.amount || 0); }, 0);

            container.innerHTML = [
                '<div class="row g-3 mb-3 reimbursement-processing-submodule">',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Approved Pending Payout</p><h5 class="mb-0">' + approvedPending.length + '</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Total Processed Amount</p><h5 class="mb-0">₱' + processedAmount.toLocaleString() + '</h5></div></div>',
                '  <div class="col-md-4"><div class="border rounded-3 p-3"><p class="text-muted mb-1">Processing Queue</p><h5 class="mb-0">' + approvedPending.length + '</h5></div></div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white"><h5 class="mb-0"><i class="fas fa-money-check-dollar text-primary me-2"></i>Reimbursement Processing</h5></div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>ID</th><th>Employee</th><th>Category</th><th>Amount</th><th>Status</th><th>Action</th></tr></thead>',
                '      <tbody>',
                approvedPending.map(function (item) {
                    return '<tr>'
                        + '<td>' + item.id + '</td>'
                        + '<td>' + item.employee + '</td>'
                        + '<td>' + item.category + '</td>'
                        + '<td>₱' + Number(item.amount).toLocaleString() + '</td>'
                        + '<td><span class="badge bg-success-subtle text-success">Approved</span></td>'
                        + '<td><button class="btn btn-sm btn-outline-primary" data-action="pay" data-id="' + item.id + '">Mark Paid</button></td>'
                        + '</tr>';
                }).join(''),
                approvedPending.length ? '' : '<tr><td colspan="6" class="text-center text-muted py-3">No approved claims waiting for payout.</td></tr>',
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            container.querySelectorAll('button[data-action="pay"]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const id = button.getAttribute('data-id');
                    const target = claims.find(function (item) { return item.id === id; });
                    if (!target) {
                        return;
                    }

                    showReimbursementProcessingModal({
                        title: 'Confirm Payout',
                        message: 'Mark claim ' + target.id + ' for ' + target.employee + ' as paid?',
                        footerHtml: [
                            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                            '<button type="button" class="btn btn-primary" id="confirmReimbursementPayoutBtn">Mark Paid</button>'
                        ].join(''),
                        onShown: function (modal) {
                            const confirmBtn = document.getElementById('confirmReimbursementPayoutBtn');
                            if (!confirmBtn) {
                                return;
                            }

                            confirmBtn.addEventListener('click', function () {
                                claims = claims.map(function (item) {
                                    if (item.id !== id) {
                                        return item;
                                    }
                                    return {
                                        id: item.id,
                                        employee: item.employee,
                                        category: item.category,
                                        amount: item.amount,
                                        date: item.date,
                                        notes: item.notes,
                                        status: item.status,
                                        reimbursed: true
                                    };
                                });

                                setStorageList(CLAIMS_RECORDS_KEY, claims);
                                modal.hide();
                                render();

                                showReimbursementProcessingModal({
                                    title: 'Payout Completed',
                                    message: 'Claim ' + target.id + ' has been marked as paid.'
                                });
                            }, { once: true });
                        }
                    });
                });
            });
        }

        render();
    };
})(window.HRSubmodules);
