/**
 * Applicant Status Monitoring Submodule
 * Professional Real-time Monitoring Logic
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};

    function ensureMonitorFeedbackModal() {
        if (document.getElementById('monitorFeedbackModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="monitorFeedbackModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title">Status Monitoring</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="monitorFeedbackBody"></div>',
            '      <div class="modal-footer">',
            '        <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Close</button>',
            '      </div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showMonitorFeedback(message) {
        const bodyEl = document.getElementById('monitorFeedbackBody');
        const modalEl = document.getElementById('monitorFeedbackModal');
        if (!bodyEl || !modalEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    // Initial Data State
    let monitoringData = [
        { id: "APP-99", name: "Clarice Starling", status: "Active", lastUpdate: "2 mins ago", stage: "Technical Review", health: "On Track" },
        { id: "APP-85", name: "Harvey Specter", status: "Pending", lastUpdate: "1 hour ago", stage: "Background Check", health: "Delayed" },
        { id: "APP-42", name: "Donna Paulsen", status: "Active", lastUpdate: "Just now", stage: "Contract Drafting", health: "Urgent" }
    ];

    window.HRSubmodules.renderApplicantStatusMonitoring = function (container) {
        ensureMonitorFeedbackModal();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="submodule-actionbar d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h6 class="mb-0 fw-bold"><i class="fas fa-satellite-dish text-primary me-2"></i>Live Status Monitor</h6>
                        <small class="text-muted">Tracking ${monitoringData.length} high-priority candidates</small>
                    </div>
                    <div class="status-indicator-group d-flex gap-3">
                        <div class="small"><span class="status-dot bg-success"></span> Healthy</div>
                        <div class="small"><span class="status-dot bg-warning"></span> Attention</div>
                        <div class="small"><span class="status-dot bg-danger"></span> Critical</div>
                    </div>
                </div>

                <div class="row g-4">
                    <div class="col-lg-12">
                        <div class="monitoring-grid">
                            ${monitoringData.map(item => `
                                <div class="monitor-card p-3 mb-3 border rounded-3 bg-white shadow-sm">
                                    <div class="row align-items-center">
                                        <div class="col-md-3">
                                            <div class="fw-bold text-dark">${item.name}</div>
                                            <div class="extra-small text-muted font-monospace">${item.id}</div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="extra-small text-uppercase fw-bold text-muted mb-1">Current Stage</div>
                                            <div class="badge bg-primary-subtle text-primary border-primary-subtle">${item.stage}</div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="extra-small text-uppercase fw-bold text-muted mb-1">Health</div>
                                            <span class="text-${getHealthColor(item.health)} small fw-medium">
                                                <i class="fas fa-circle me-1" style="font-size: 8px;"></i>${item.health}
                                            </span>
                                        </div>
                                        <div class="col-md-2 text-center">
                                            <div class="extra-small text-uppercase fw-bold text-muted mb-1">Last Update</div>
                                            <div class="small text-dark">${item.lastUpdate}</div>
                                        </div>
                                        <div class="col-md-2 text-end">
                                            <button class="btn btn-sm btn-outline-secondary border-0" onclick="window.HRSubmodules.triggerMonitorSync()">
                                                <i class="fas fa-ellipsis-h"></i>
                                            </button>
                                        </div>
                                    </div>
                                    <div class="progress mt-3" style="height: 4px;">
                                        <div class="progress-bar bg-${getHealthColor(item.health)}" style="width: ${item.health === 'Urgent' ? '90%' : '45%'}"></div>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                </div>
            </div>
        `;
    };

    function getHealthColor(health) {
        if (health === 'On Track') return 'success';
        if (health === 'Delayed') return 'warning';
        return 'danger';
    }

    /**
     * Real-time Dashboard Sync
     * Updates the main dashboard metrics when changes occur here
     */
    window.HRSubmodules.triggerMonitorSync = function() {
        // Update local storage keys that main.js is listening to
        localStorage.setItem('hospitalHrMonitorAlerts', Math.floor(Math.random() * 5));
        localStorage.setItem('hospitalHrLastSync', new Date().toLocaleTimeString());
        
        // Broadcast the update
        window.dispatchEvent(new Event('storage'));
        
        showMonitorFeedback('Monitor data synced with dashboard at ' + new Date().toLocaleTimeString() + '.');
    };

})();