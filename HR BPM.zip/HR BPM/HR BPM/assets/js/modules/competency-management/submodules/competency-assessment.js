/**
 * Competency Assessment Submodule
 * Professional Grading & Proficiency Standards
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrCompetencyEvals';

    const getAssessments = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Initial Professional Data
        return [
            { id: "CMP-001", name: "Dr. Aris Thorne", area: "Clinical Expertise", score: 95, status: "Certified" },
            { id: "CMP-002", name: "Sarah Jenkins", area: "Patient Safety", score: 88, status: "Certified" },
            { id: "CMP-003", name: "James Miller", area: "Technical Ops", score: 72, status: "Training Required" }
        ];
    };

    function ensureCompetencyAssessmentModalHost() {
        if (document.getElementById('competencyAssessmentModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="competencyAssessmentModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="competencyAssessmentModalTitle">Competency Assessment</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="competencyAssessmentModalBody"></div>',
            '      <div class="modal-footer" id="competencyAssessmentModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    window.HRSubmodules.renderCompetencyAssessment = function (container) {
        ensureCompetencyAssessmentModalHost();

        const data = getAssessments();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-chart-line text-success me-2"></i>Competency Assessment</h6>
                        <small class="text-muted">Measure staff proficiency against healthcare benchmarks</small>
                    </div>
                    <button class="btn btn-outline-primary btn-sm rounded-pill px-3" onclick="window.HRSubmodules.startNewAssessment()">
                        <i class="fas fa-clipboard-check me-1"></i> New Assessment
                    </button>
                </div>

                <div class="row g-3">
                    ${data.map(item => `
                        <div class="col-md-6 col-xl-4">
                            <div class="comp-card bg-white p-3 border rounded-3 shadow-sm h-100">
                                <div class="d-flex justify-content-between align-items-start mb-3">
                                    <div class="text-truncate" style="max-width: 70%;">
                                        <div class="fw-bold text-dark">${item.name}</div>
                                        <div class="extra-small text-primary">${item.area}</div>
                                    </div>
                                    <span class="comp-badge ${item.status.toLowerCase().replace(/\s+/g, '-')}">${item.status}</span>
                                </div>

                                <div class="mb-2 d-flex justify-content-between align-items-center">
                                    <span class="small text-muted">Proficiency Score</span>
                                    <span class="fw-bold ${item.score >= 80 ? 'text-success' : 'text-warning'}">${item.score}%</span>
                                </div>
                                
                                <div class="progress mb-3" style="height: 8px; border-radius: 10px;">
                                    <div class="progress-bar ${item.score >= 80 ? 'bg-success' : 'bg-warning'}" 
                                         role="progressbar" style="width: ${item.score}%"></div>
                                </div>

                                <div class="d-flex justify-content-between align-items-center pt-2 border-top">
                                    <span class="extra-small text-muted">ID: ${item.id}</span>
                                    <button class="btn btn-link btn-sm p-0 text-decoration-none extra-small" onclick="window.HRSubmodules.updateCompScore('${item.id}')">Update Score</button>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.startNewAssessment = function() {
        const modalEl = document.getElementById('competencyAssessmentModal');
        const titleEl = document.getElementById('competencyAssessmentModalTitle');
        const bodyEl = document.getElementById('competencyAssessmentModalBody');
        const footerEl = document.getElementById('competencyAssessmentModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'New Competency Assessment';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Staff Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="assessmentStaffName" placeholder="e.g. John Doe">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Assessment Area</label>',
            '  <input type="text" class="form-control form-control-sm" id="assessmentArea" placeholder="e.g. Clinical, Ethics">',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="assessmentCreateBtn">Create</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const createBtn = document.getElementById('assessmentCreateBtn');
        if (createBtn) {
            createBtn.addEventListener('click', function () {
                const name = (document.getElementById('assessmentStaffName').value || '').trim();
                const area = (document.getElementById('assessmentArea').value || '').trim();
                if (!name || !area) {
                    return;
                }

                let data = getAssessments();
                data.unshift({
                    id: 'CMP-' + Math.floor(100 + Math.random() * 900),
                    name: name,
                    area: area,
                    score: 0,
                    status: 'Pending'
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderCompetencyAssessment(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
            });
        }

        modal.show();
    };

    window.HRSubmodules.updateCompScore = function(id) {
        let data = getAssessments();
        const idx = data.findIndex(function (i) { return i.id === id; });
        if (idx === -1) {
            return;
        }

        const modalEl = document.getElementById('competencyAssessmentModal');
        const titleEl = document.getElementById('competencyAssessmentModalTitle');
        const bodyEl = document.getElementById('competencyAssessmentModalBody');
        const footerEl = document.getElementById('competencyAssessmentModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Update Competency Score';
        bodyEl.innerHTML = [
            '<p class="mb-2">Employee: <strong>' + data[idx].name + '</strong></p>',
            '<label class="form-label small mb-1">Score (0-100)</label>',
            '<input type="number" min="0" max="100" class="form-control form-control-sm" id="assessmentScoreInput" value="' + data[idx].score + '">'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="assessmentScoreSaveBtn">Save</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const saveBtn = document.getElementById('assessmentScoreSaveBtn');
        if (saveBtn) {
            saveBtn.addEventListener('click', function () {
                const score = Number(document.getElementById('assessmentScoreInput').value);
                if (Number.isNaN(score) || score < 0 || score > 100) {
                    return;
                }

                data[idx].score = Math.round(score);
                data[idx].status = data[idx].score >= 75 ? 'Certified' : 'Training Required';
                localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderCompetencyAssessment(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
            });
        }

        modal.show();
    };

})();