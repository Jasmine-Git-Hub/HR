/**
 * Competency Gap Analysis Submodule
 * Identifies training needs by comparing Actual vs. Required skills
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrCompetencyGaps';

    const getGaps = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Professional Baseline Data
        return [
            { id: "GAP-001", name: "Dr. Aris Thorne", skill: "Robotic Surgery", required: 90, actual: 85, status: "Critical" },
            { id: "GAP-002", name: "Sarah Jenkins", skill: "Disaster Response", required: 95, actual: 95, status: "Optimized" },
            { id: "GAP-003", name: "James Miller", skill: "Advanced Imaging", required: 80, actual: 60, status: "High Risk" }
        ];
    };

    function ensureGapAnalysisModalHost() {
        if (document.getElementById('competencyGapModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="competencyGapModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="competencyGapModalTitle">Gap Analysis</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="competencyGapModalBody"></div>',
            '      <div class="modal-footer" id="competencyGapModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    window.HRSubmodules.renderCompetencyGapAnalysis = function (container) {
        ensureGapAnalysisModalHost();

        const gaps = getGaps();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-microscope text-danger me-2"></i>Gap Analysis Matrix</h6>
                        <small class="text-muted">Strategic comparison of current talent vs. institutional requirements</small>
                    </div>
                    <button class="btn btn-dark btn-sm px-3 shadow-sm" onclick="window.HRSubmodules.analyzeNewSkill()">
                        <i class="fas fa-search-plus me-1"></i> New Analysis
                    </button>
                </div>

                <div class="table-responsive border rounded-3 bg-white shadow-sm overflow-hidden">
                    <table class="table table-hover align-middle mb-0 custom-gap-table">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4" style="width: 25%">Staff & Skill</th>
                                <th style="width: 35%">Proficiency Variance</th>
                                <th style="width: 20%">Gap Score</th>
                                <th class="text-end pe-4" style="width: 20%">Priority</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${gaps.map(item => {
                                const variance = item.actual - item.required;
                                const isNegative = variance < 0;
                                return `
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark">${item.name}</div>
                                        <div class="extra-small text-muted">${item.skill}</div>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center gap-2">
                                            <span class="small text-muted" style="width: 30px;">${item.actual}%</span>
                                            <div class="progress flex-grow-1" style="height: 6px;">
                                                <div class="progress-bar ${isNegative ? 'bg-danger' : 'bg-success'}" 
                                                     style="width: ${item.actual}%"></div>
                                            </div>
                                            <span class="small text-muted" style="width: 30px;">${item.required}%</span>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="fw-bold ${isNegative ? 'text-danger' : 'text-success'}">
                                            ${isNegative ? variance : '+' + variance}%
                                        </span>
                                    </td>
                                    <td class="text-end pe-4">
                                        <span class="priority-pill ${item.status.toLowerCase().replace(' ', '-')}">
                                            ${item.status}
                                        </span>
                                    </td>
                                </tr>
                            `}).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    };

    window.HRSubmodules.analyzeNewSkill = function() {
        const modalEl = document.getElementById('competencyGapModal');
        const titleEl = document.getElementById('competencyGapModalTitle');
        const bodyEl = document.getElementById('competencyGapModalBody');
        const footerEl = document.getElementById('competencyGapModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'New Gap Analysis';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Staff Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="gapStaffName" placeholder="e.g. Jane Doe">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Skill to Analyze</label>',
            '  <input type="text" class="form-control form-control-sm" id="gapSkillName" placeholder="e.g. Robotic Surgery">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Required Proficiency (%)</label>',
            '  <input type="number" min="0" max="100" class="form-control form-control-sm" id="gapRequiredScore" value="90">',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-dark" id="gapCreateBtn">Analyze</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const createBtn = document.getElementById('gapCreateBtn');
        if (createBtn) {
            createBtn.addEventListener('click', function () {
                const name = (document.getElementById('gapStaffName').value || '').trim();
                const skill = (document.getElementById('gapSkillName').value || '').trim();
                const required = Number(document.getElementById('gapRequiredScore').value);
                if (!name || !skill || Number.isNaN(required) || required < 0 || required > 100) {
                    return;
                }

                let gaps = getGaps();
                gaps.unshift({
                    id: 'GAP-' + Math.floor(100 + Math.random() * 899),
                    name: name,
                    skill: skill,
                    required: Math.round(required),
                    actual: 0,
                    status: 'High Risk'
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(gaps));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderCompetencyGapAnalysis(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
            });
        }

        modal.show();
    };
})();