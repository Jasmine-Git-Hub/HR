/**
 * Training Programs Submodule
 * Professional Strategic Initiative Management
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrTrainingPrograms';

    const getPrograms = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Initial Professional Training Initiatives
        return [
            { id: "PROG-001", name: "2024 Leadership Excellence", type: "Workshop Series", cohorts: 3, lead: "Dr. Elena Vance", status: "In Progress" },
            { id: "PROG-002", name: "Emergency Response Drill", type: "Simulation", cohorts: 12, lead: "Marcus Thorne", status: "Scheduled" },
            { id: "PROG-003", name: "Digital Records Migration", type: "Technical", cohorts: 5, lead: "IT Dept", status: "Completed" }
        ];
    };

    function ensureTrainingProgramModalHost() {
        if (document.getElementById('trainingProgramsModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="trainingProgramsModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="trainingProgramsModalTitle">Training Programs</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="trainingProgramsModalBody"></div>',
            '      <div class="modal-footer" id="trainingProgramsModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showTrainingProgramInfo(title, message) {
        const modalEl = document.getElementById('trainingProgramsModal');
        const titleEl = document.getElementById('trainingProgramsModalTitle');
        const bodyEl = document.getElementById('trainingProgramsModalBody');
        const footerEl = document.getElementById('trainingProgramsModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderTrainingPrograms = function (container) {
        ensureTrainingProgramModalHost();

        const programs = getPrograms();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-chalkboard-user text-info me-2"></i>Strategic Training Initiatives</h6>
                        <small class="text-muted">High-level developmental programs and institutional workshops</small>
                    </div>
                    <button class="btn btn-info btn-sm text-white rounded-pill px-4 shadow-sm" onclick="window.HRSubmodules.initiateNewProgram()">
                        <i class="fas fa-rocket me-1"></i> New Initiative
                    </button>
                </div>

                <div class="row g-4">
                    ${programs.map(prog => `
                        <div class="col-xl-4 col-md-6">
                            <div class="program-card border rounded-4 bg-white shadow-sm h-100 position-relative overflow-hidden">
                                <div class="program-type-tag">${prog.type}</div>
                                <div class="p-4 pt-5">
                                    <div class="d-flex justify-content-between align-items-start mb-3">
                                        <h6 class="fw-bold text-dark mb-0 pe-2" style="line-height: 1.4; min-height: 44px;">${prog.name}</h6>
                                        <span class="badge ${getStatusBadgeClass(prog.status)}">${prog.status}</span>
                                    </div>
                                    
                                    <div class="program-meta-grid border-top pt-3 mt-2">
                                        <div class="row text-center">
                                            <div class="col-6 border-end">
                                                <div class="extra-small text-muted text-uppercase fw-bold">Cohorts</div>
                                                <div class="fw-bold text-primary">${prog.cohorts}</div>
                                            </div>
                                            <div class="col-6">
                                                <div class="extra-small text-muted text-uppercase fw-bold">Program Lead</div>
                                                <div class="small fw-semibold text-dark text-truncate px-1">${prog.lead}</div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="mt-4 pt-2 d-flex gap-2">
                                        <button class="btn btn-light btn-sm flex-grow-1 border" onclick="window.HRSubmodules.viewProgramDetails('${prog.id}')">Details</button>
                                        <button class="btn btn-outline-info btn-sm flex-grow-1" onclick="window.HRSubmodules.viewProgramCohorts('${prog.id}')">Cohorts</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    function getStatusBadgeClass(status) {
        switch(status) {
            case 'Completed': return 'bg-success-subtle text-success';
            case 'In Progress': return 'bg-info-subtle text-info';
            case 'Scheduled': return 'bg-warning-subtle text-warning';
            default: return 'bg-secondary-subtle text-secondary';
        }
    }

    window.HRSubmodules.initiateNewProgram = function() {
        const modalEl = document.getElementById('trainingProgramsModal');
        const titleEl = document.getElementById('trainingProgramsModalTitle');
        const bodyEl = document.getElementById('trainingProgramsModalBody');
        const footerEl = document.getElementById('trainingProgramsModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'New Training Initiative';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Program Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="trainingProgramName" placeholder="e.g. Emergency Drill Bootcamp">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Program Type</label>',
            '  <input type="text" class="form-control form-control-sm" id="trainingProgramType" placeholder="Workshop/Simulation/Series">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Program Lead</label>',
            '  <input type="text" class="form-control form-control-sm" id="trainingProgramLead" value="Unassigned">',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-info text-white" id="trainingProgramCreateBtn">Create</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const createBtn = document.getElementById('trainingProgramCreateBtn');
        if (createBtn) {
            createBtn.addEventListener('click', function () {
                const name = (document.getElementById('trainingProgramName').value || '').trim();
                const type = (document.getElementById('trainingProgramType').value || '').trim();
                const lead = (document.getElementById('trainingProgramLead').value || '').trim() || 'Unassigned';
                if (!name || !type) {
                    return;
                }

                let programs = getPrograms();
                programs.unshift({
                    id: 'PROG-' + Math.floor(100 + Math.random() * 900),
                    name: name,
                    type: type,
                    cohorts: 1,
                    lead: lead,
                    status: 'Scheduled'
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(programs));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderTrainingPrograms(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showTrainingProgramInfo('Initiative Created', name + ' has been added as a new training initiative.');
            });
        }

        modal.show();
    };

    window.HRSubmodules.viewProgramDetails = function (programId) {
        const programs = getPrograms();
        const target = programs.find(function (item) { return item.id === programId; });
        if (!target) {
            return;
        }

        showTrainingProgramInfo('Program Details', target.id + ' - ' + target.name + ' (' + target.status + ').');
    };

    window.HRSubmodules.viewProgramCohorts = function (programId) {
        const programs = getPrograms();
        const target = programs.find(function (item) { return item.id === programId; });
        if (!target) {
            return;
        }

        showTrainingProgramInfo('Cohort Overview', target.name + ' currently has ' + target.cohorts + ' active cohort(s).');
    };
})();