/**
 * Training Schedule Submodule
 * Professional Timeline & Session Management
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrTrainingSchedule';

    const getSchedule = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Baseline Professional Schedule
        return [
            { id: "SCH-001", title: "Advanced Life Support Prep", date: "2024-06-15", time: "09:00 AM", location: "Room 302", instructor: "Dr. Aris Thorne", type: "Clinical" },
            { id: "SCH-002", title: "New Employee Orientation", date: "2024-06-18", time: "10:30 AM", location: "Main Hall", instructor: "HR Dept", type: "Admin" },
            { id: "SCH-003", title: "Cybersecurity Protocol Update", date: "2024-06-20", time: "02:00 PM", location: "Virtual", instructor: "IT Security", type: "Technical" }
        ];
    };

    function ensureTrainingScheduleModalHost() {
        if (document.getElementById('trainingScheduleModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="trainingScheduleModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="trainingScheduleModalTitle">Training Schedule</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="trainingScheduleModalBody"></div>',
            '      <div class="modal-footer" id="trainingScheduleModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showTrainingScheduleInfo(title, message) {
        const modalEl = document.getElementById('trainingScheduleModal');
        const titleEl = document.getElementById('trainingScheduleModalTitle');
        const bodyEl = document.getElementById('trainingScheduleModalBody');
        const footerEl = document.getElementById('trainingScheduleModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderTrainingSchedule = function (container) {
        ensureTrainingScheduleModalHost();

        const schedule = getSchedule();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-calendar-alt text-primary me-2"></i>Institutional Training Schedule</h6>
                        <small class="text-muted">Live calendar of upcoming workshops, drills, and certifications</small>
                    </div>
                    <button class="btn btn-primary btn-sm rounded-pill px-4 shadow-sm" onclick="window.HRSubmodules.createNewEvent()">
                        <i class="fas fa-plus me-1"></i> Add Session
                    </button>
                </div>

                <div class="timeline-container bg-white border rounded-3 shadow-sm p-4">
                    ${schedule.map((item, index) => `
                        <div class="timeline-item d-flex pb-4 ${index === schedule.length - 1 ? 'mb-0' : 'mb-4 border-bottom'}">
                            <div class="date-badge text-center me-4" style="min-width: 60px;">
                                <div class="month extra-small fw-bold text-uppercase text-primary">${new Date(item.date).toLocaleString('default', { month: 'short' })}</div>
                                <div class="day h4 fw-bold mb-0">${new Date(item.date).getDate()}</div>
                            </div>
                            <div class="flex-grow-1">
                                <div class="d-flex justify-content-between align-items-start mb-1">
                                    <h6 class="fw-bold text-dark mb-0">${item.title}</h6>
                                    <span class="badge ${item.type === 'Clinical' ? 'bg-danger-subtle text-danger' : 'bg-info-subtle text-info'} extra-small rounded-pill">${item.type}</span>
                                </div>
                                <div class="d-flex flex-wrap gap-3 text-muted extra-small mt-2">
                                    <span><i class="far fa-clock me-1"></i> ${item.time}</span>
                                    <span><i class="fas fa-map-marker-alt me-1"></i> ${item.location}</span>
                                    <span><i class="fas fa-user-tie me-1"></i> ${item.instructor}</span>
                                </div>
                            </div>
                            <div class="ms-3">
                                <button class="btn btn-outline-secondary btn-sm rounded-circle" onclick="window.HRSubmodules.viewSessionRegistry('${item.id}')"><i class="fas fa-users"></i></button>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    };

    window.HRSubmodules.createNewEvent = function() {
        const modalEl = document.getElementById('trainingScheduleModal');
        const titleEl = document.getElementById('trainingScheduleModalTitle');
        const bodyEl = document.getElementById('trainingScheduleModalBody');
        const footerEl = document.getElementById('trainingScheduleModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Add Training Session';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Session Title</label>',
            '  <input type="text" class="form-control form-control-sm" id="trainingSessionTitle" placeholder="e.g. ER Protocol Review">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Date</label>',
            '  <input type="date" class="form-control form-control-sm" id="trainingSessionDate">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Session Type</label>',
            '  <input type="text" class="form-control form-control-sm" id="trainingSessionType" value="Admin">',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="trainingSessionCreateBtn">Create Session</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const createBtn = document.getElementById('trainingSessionCreateBtn');
        if (createBtn) {
            createBtn.addEventListener('click', function () {
                const title = (document.getElementById('trainingSessionTitle').value || '').trim();
                const date = (document.getElementById('trainingSessionDate').value || '').trim();
                const type = (document.getElementById('trainingSessionType').value || '').trim() || 'Admin';
                if (!title || !date) {
                    return;
                }

                let schedule = getSchedule();
                schedule.unshift({
                    id: 'SCH-' + Math.floor(100 + Math.random() * 900),
                    title: title,
                    date: date,
                    time: '09:00 AM',
                    location: 'TBD',
                    instructor: 'To Be Assigned',
                    type: type
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(schedule));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderTrainingSchedule(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
                showTrainingScheduleInfo('Session Added', title + ' was added to the training calendar.');
            });
        }

        modal.show();
    };

    window.HRSubmodules.viewSessionRegistry = function (sessionId) {
        const schedule = getSchedule();
        const target = schedule.find(function (item) { return item.id === sessionId; });
        if (!target) {
            return;
        }

        showTrainingScheduleInfo('Session Registry', 'Registry for ' + target.title + ' is available for facilitator ' + target.instructor + '.');
    };
})();