/**
 * Initial KPI Setup Submodule
 * Defines performance targets for new staff
 */
(function () {
    'use strict';

    window.HRSubmodules = window.HRSubmodules || {};
    const STORAGE_KEY = 'hospitalHrKpiSetup';

    const getKpis = () => {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return JSON.parse(stored);
        
        // Professional Medical KPI Defaults
        return [
            { id: "KPI-2026-01", name: "Dr. Aris Thorne", category: "Clinical", metric: "Patient Satisfaction Score", target: ">= 90%", status: "Approved" },
            { id: "KPI-2026-02", name: "Sarah Jenkins", category: "Administrative", metric: "Staff Retention Rate", target: ">= 85%", status: "Pending Approval" },
            { id: "KPI-2026-03", name: "James Miller", category: "Technical", metric: "Imaging Turnaround Time", target: "< 2 Hours", status: "Draft" }
        ];
    };

    function ensureKpiModalHost() {
        if (document.getElementById('kpiSetupModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="kpiSetupModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="kpiSetupModalTitle">KPI Setup</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="kpiSetupModalBody"></div>',
            '      <div class="modal-footer" id="kpiSetupModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showKpiInfo(title, message) {
        const modalEl = document.getElementById('kpiSetupModal');
        const titleEl = document.getElementById('kpiSetupModalTitle');
        const bodyEl = document.getElementById('kpiSetupModalBody');
        const footerEl = document.getElementById('kpiSetupModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = title;
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }

    window.HRSubmodules.renderInitialKPISetup = function (container) {
        ensureKpiModalHost();

        const kpis = getKpis();

        container.innerHTML = `
            <div class="submodule-content-wrapper animate-fade-in">
                <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 border rounded-3 shadow-sm">
                    <div>
                        <h6 class="fw-bold mb-0 text-dark"><i class="fas fa-tasks text-primary me-2"></i>KPI Framework</h6>
                        <small class="text-muted">Establish baseline performance metrics for new personnel</small>
                    </div>
                    <button class="btn btn-primary btn-sm rounded-pill px-3" onclick="window.HRSubmodules.createNewKpi()">
                        <i class="fas fa-plus me-1"></i> Define KPI
                    </button>
                </div>

                <div class="table-responsive border rounded-3 bg-white shadow-sm">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4">Employee</th>
                                <th>Category</th>
                                <th>Metric & Target</th>
                                <th>Status</th>
                                <th class="text-end pe-4">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${kpis.map(kpi => `
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark">${kpi.name}</div>
                                        <div class="text-muted extra-small">${kpi.id}</div>
                                    </td>
                                    <td>
                                        <span class="badge bg-light text-dark border">${kpi.category}</span>
                                    </td>
                                    <td>
                                        <div class="fw-medium text-primary">${kpi.metric}</div>
                                        <div class="small text-muted">Goal: ${kpi.target}</div>
                                    </td>
                                    <td>
                                        <span class="kpi-status-pill ${kpi.status.toLowerCase().replace(/\s+/g, '-')}">${kpi.status}</span>
                                    </td>
                                    <td class="text-end pe-4">
                                        <div class="d-flex justify-content-end gap-2">
                                            <button class="btn btn-xs btn-outline-primary" onclick="window.HRSubmodules.updateKpiStatus('${kpi.id}', 'Approved')">Approve</button>
                                            <button class="btn btn-xs btn-outline-danger" onclick="window.HRSubmodules.deleteKpi('${kpi.id}')"><i class="fas fa-trash"></i></button>
                                        </div>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    };

    window.HRSubmodules.updateKpiStatus = function(id, status) {
        let kpis = getKpis();
        const idx = kpis.findIndex(k => k.id === id);
        if (idx !== -1) {
            const employeeName = kpis[idx].name;
            kpis[idx].status = status;
            localStorage.setItem(STORAGE_KEY, JSON.stringify(kpis));
            window.dispatchEvent(new Event('storage')); // Trigger Dashboard Update
            this.renderInitialKPISetup(document.getElementById('roleModuleOverviewBody'));
            showKpiInfo('KPI Updated', employeeName + ' KPI was marked as ' + status + '.');
        }
    };

    window.HRSubmodules.createNewKpi = function() {
        const modalEl = document.getElementById('kpiSetupModal');
        const titleEl = document.getElementById('kpiSetupModalTitle');
        const bodyEl = document.getElementById('kpiSetupModalBody');
        const footerEl = document.getElementById('kpiSetupModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Define New KPI';
        bodyEl.innerHTML = [
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Employee Name</label>',
            '  <input type="text" class="form-control form-control-sm" id="kpiEmployeeName" placeholder="e.g. Sarah Jenkins">',
            '</div>',
            '<div class="mb-2">',
            '  <label class="form-label small mb-1">Metric</label>',
            '  <input type="text" class="form-control form-control-sm" id="kpiMetric" placeholder="e.g. Case Resolution Time">',
            '</div>',
            '<div class="mb-0">',
            '  <label class="form-label small mb-1">Target</label>',
            '  <input type="text" class="form-control form-control-sm" id="kpiTarget" value="TBD">',
            '</div>'
        ].join('');
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-primary" id="kpiCreateBtn">Create KPI</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const createBtn = document.getElementById('kpiCreateBtn');
        if (createBtn) {
            createBtn.addEventListener('click', function () {
                const name = (document.getElementById('kpiEmployeeName').value || '').trim();
                const metric = (document.getElementById('kpiMetric').value || '').trim();
                const target = (document.getElementById('kpiTarget').value || '').trim() || 'TBD';
                if (!name || !metric) {
                    return;
                }

                let kpis = getKpis();
                kpis.unshift({
                    id: 'KPI-2026-' + Math.floor(Math.random() * 1000),
                    name: name,
                    category: 'General',
                    metric: metric,
                    target: target,
                    status: 'Draft'
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(kpis));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderInitialKPISetup(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
            });
        }

        modal.show();
    };

    window.HRSubmodules.deleteKpi = function(id) {
        const kpis = getKpis();
        const target = kpis.find(function (kpi) {
            return kpi.id === id;
        });
        if (!target) {
            return;
        }

        const modalEl = document.getElementById('kpiSetupModal');
        const titleEl = document.getElementById('kpiSetupModalTitle');
        const bodyEl = document.getElementById('kpiSetupModalBody');
        const footerEl = document.getElementById('kpiSetupModalFooter');

        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = 'Delete KPI';
        bodyEl.innerHTML = '<p class="mb-0">Remove KPI <strong>' + target.metric + '</strong> for ' + target.name + '?</p>';
        footerEl.innerHTML = [
            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
            '<button type="button" class="btn btn-danger" id="kpiDeleteBtn">Delete</button>'
        ].join('');

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        const deleteBtn = document.getElementById('kpiDeleteBtn');
        if (deleteBtn) {
            deleteBtn.addEventListener('click', function () {
                let filtered = getKpis().filter(function (kpi) {
                    return kpi.id !== id;
                });
                localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
                window.dispatchEvent(new Event('storage'));
                window.HRSubmodules.renderInitialKPISetup(document.getElementById('roleModuleOverviewBody'));
                modal.hide();
            });
        }

        modal.show();
    };

})();