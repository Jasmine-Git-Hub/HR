window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const VALIDATION_QUEUE_KEY = 'hospitalHrAttendanceValidationQueue';

    function ensureAttendanceValidationModalHost() {
        if (document.getElementById('attendanceValidationModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="attendanceValidationModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="attendanceValidationModalTitle">Attendance Validation</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="attendanceValidationModalBody"></div>',
            '      <div class="modal-footer" id="attendanceValidationModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showAttendanceValidationModal(config) {
        const modalEl = document.getElementById('attendanceValidationModal');
        const titleEl = document.getElementById('attendanceValidationModalTitle');
        const bodyEl = document.getElementById('attendanceValidationModalBody');
        const footerEl = document.getElementById('attendanceValidationModalFooter');
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            return;
        }

        titleEl.textContent = config.title;
        bodyEl.innerHTML = '<p class="mb-0">' + config.message + '</p>';
        footerEl.innerHTML = config.footerHtml || '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';

        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        if (typeof config.onShown === 'function') {
            config.onShown(modal);
        }
    }

    function getStorageList(key, fallback) {
        const raw = localStorage.getItem(key);
        if (!raw) {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback.slice();
        }

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed;
            }
        } catch (error) {
        }

        localStorage.setItem(key, JSON.stringify(fallback));
        return fallback.slice();
    }

    function setStorageList(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }

    registry.renderAttendanceValidation = function (container) {
        ensureAttendanceValidationModalHost();

        const fallback = [
            { id: 'VAL-1001', employee: 'Paolo Cruz', issue: 'Missing Time In', status: 'Pending' },
            { id: 'VAL-1002', employee: 'Rina Torres', issue: 'Late Log Entry', status: 'Pending' },
            { id: 'VAL-1003', employee: 'John Lim', issue: 'Early Out Dispute', status: 'For Review' }
        ];
        let queue = getStorageList(VALIDATION_QUEUE_KEY, fallback);

        function render() {
            container.innerHTML = [
                '<div class="card border-0 shadow-sm att-val-submodule">',
                '  <div class="card-header bg-white d-flex justify-content-between align-items-center">',
                '    <h5 class="mb-0"><i class="fas fa-clipboard-check text-primary me-2"></i>Pending Validation Queue</h5>',
                '    <span class="badge bg-warning-subtle text-warning">' + queue.filter(function (item) { return item.status === 'Pending' || item.status === 'For Review'; }).length + ' Open</span>',
                '  </div>',
                '  <div class="table-responsive">',
                '    <table class="table mb-0 align-middle">',
                '      <thead><tr><th>ID</th><th>Employee</th><th>Issue</th><th>Status</th><th>Action</th></tr></thead>',
                '      <tbody>',
                queue.map(function (item) {
                    return '<tr>'
                        + '<td>' + item.id + '</td>'
                        + '<td>' + item.employee + '</td>'
                        + '<td>' + item.issue + '</td>'
                        + '<td><span class="badge ' + (item.status === 'Approved' ? 'bg-success-subtle text-success' : item.status === 'Rejected' ? 'bg-danger-subtle text-danger' : 'bg-warning-subtle text-warning') + '">' + item.status + '</span></td>'
                        + '<td>'
                        + '<button class="btn btn-sm btn-outline-success me-1" data-action="approve" data-id="' + item.id + '">Approve</button>'
                        + '<button class="btn btn-sm btn-outline-danger" data-action="reject" data-id="' + item.id + '">Reject</button>'
                        + '</td>'
                        + '</tr>';
                }).join(''),
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            container.querySelectorAll('button[data-action]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const action = button.getAttribute('data-action');
                    const id = button.getAttribute('data-id');
                    const target = queue.find(function (item) { return item.id === id; });
                    if (!target) {
                        return;
                    }

                    const nextStatus = action === 'approve' ? 'Approved' : 'Rejected';
                    showAttendanceValidationModal({
                        title: nextStatus === 'Approved' ? 'Approve Validation' : 'Reject Validation',
                        message: 'Set request ' + target.id + ' for ' + target.employee + ' to ' + nextStatus + '?',
                        footerHtml: [
                            '<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>',
                            '<button type="button" class="btn ' + (nextStatus === 'Approved' ? 'btn-success' : 'btn-danger') + '" id="confirmAttendanceValidationActionBtn">Confirm</button>'
                        ].join(''),
                        onShown: function (modal) {
                            const confirmBtn = document.getElementById('confirmAttendanceValidationActionBtn');
                            if (!confirmBtn) {
                                return;
                            }

                            confirmBtn.addEventListener('click', function () {
                                queue = queue.map(function (item) {
                                    if (item.id !== id) {
                                        return item;
                                    }
                                    return {
                                        id: item.id,
                                        employee: item.employee,
                                        issue: item.issue,
                                        status: nextStatus
                                    };
                                });
                                setStorageList(VALIDATION_QUEUE_KEY, queue);
                                modal.hide();
                                render();

                                showAttendanceValidationModal({
                                    title: 'Validation Updated',
                                    message: 'Request ' + target.id + ' is now marked as ' + nextStatus + '.'
                                });
                            }, { once: true });
                        }
                    });
                });
            });
        }

        render();
    };
})(window.HRSubmodules);
