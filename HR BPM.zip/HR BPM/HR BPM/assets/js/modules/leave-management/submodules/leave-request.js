window.HRSubmodules = window.HRSubmodules || {};

(function (registry) {
    const LEAVE_REQUESTS_API = 'php/leave-request-api.php';

    function ensureLeaveRequestModalHost() {
        if (document.getElementById('leaveRequestModal')) {
            return;
        }

        const modalHost = document.createElement('div');
        modalHost.innerHTML = [
            '<div class="modal fade" id="leaveRequestModal" tabindex="-1" aria-hidden="true">',
            '  <div class="modal-dialog modal-dialog-centered">',
            '    <div class="modal-content">',
            '      <div class="modal-header">',
            '        <h5 class="modal-title" id="leaveRequestModalTitle">Leave Request</h5>',
            '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>',
            '      </div>',
            '      <div class="modal-body" id="leaveRequestModalBody"></div>',
            '      <div class="modal-footer" id="leaveRequestModalFooter"></div>',
            '    </div>',
            '  </div>',
            '</div>'
        ].join('');

        document.body.appendChild(modalHost.firstElementChild);
    }

    function showLeaveRequestInfo(title, message, isError = false) {
        const modalEl = document.getElementById('leaveRequestModal');
        const titleEl = document.getElementById('leaveRequestModalTitle');
        const bodyEl = document.getElementById('leaveRequestModalBody');
        const footerEl = document.getElementById('leaveRequestModalFooter');
        
        if (!modalEl || !titleEl || !bodyEl || !footerEl || !(window.bootstrap && window.bootstrap.Modal)) {
            alert(title + ': ' + message);
            return;
        }

        titleEl.textContent = title;
        titleEl.style.color = isError ? '#dc3545' : '';
        bodyEl.innerHTML = '<p class="mb-0">' + message + '</p>';
        footerEl.innerHTML = '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>';
        
        const modal = window.bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();
        
        // Reset title color after modal is hidden
        modalEl.addEventListener('hidden.bs.modal', function() {
            titleEl.style.color = '';
        }, { once: true });
    }

    function calcDays(fromValue, toValue) {
        if (!fromValue || !toValue) return 0;
        
        const fromDate = new Date(fromValue);
        const toDate = new Date(toValue);
        
        if (Number.isNaN(fromDate.getTime()) || Number.isNaN(toDate.getTime()) || toDate < fromDate) {
            return 0;
        }

        const msPerDay = 1000 * 60 * 60 * 24;
        return Math.floor((toDate - fromDate) / msPerDay) + 1;
    }

    async function fetchRequestsFromDB() {
        try {
            const response = await fetch(LEAVE_REQUESTS_API);
            const result = await response.json();
            
            if (result.success && result.data) {
                return result.data;
            }
            return [];
        } catch (error) {
            console.error('Error fetching leave requests:', error);
            showLeaveRequestInfo('Database Error', 'Could not fetch leave requests. Please check your connection.', true);
            return [];
        }
    }

    async function saveRequestToDB(requestData) {
        try {
            const response = await fetch(LEAVE_REQUESTS_API, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(requestData)
            });
            
            const result = await response.json();
            
            if (!result.success) {
                throw new Error(result.error || 'Failed to save request');
            }
            
            return result.data;
        } catch (error) {
            console.error('Error saving leave request:', error);
            showLeaveRequestInfo('Database Error', 'Could not save leave request. Please try again.', true);
            throw error;
        }
    }

    registry.renderLeaveRequest = async function (container) {
        if (!container) {
            console.error('Container element is required');
            return;
        }

        ensureLeaveRequestModalHost();

        // Show loading state
        container.innerHTML = '<div class="text-center p-4"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></div>';

        // Fetch initial data from database
        let requests = await fetchRequestsFromDB();

        async function render() {
            const today = new Date().toISOString().split('T')[0];
            
            container.innerHTML = [
                '<div class="card border-0 shadow-sm mb-3 leave-request-submodule">',
                '  <div class="card-body">',
                '    <h6 class="mb-3"><i class="fas fa-calendar-plus text-primary me-2"></i>Create Leave Request</h6>',
                '    <div class="row g-2">',
                '      <div class="col-md-3">',
                '        <input id="lvEmp" class="form-control" placeholder="Employee Name" list="employeeList">',
                '        <datalist id="employeeList">',
                '          <option value="Anna Santos">',
                '          <option value="Jude Molina">',
                '          <option value="Leah Gomez">',
                '          <option value="Maria Cruz">',
                '          <option value="Mark Rivera">',
                '        </datalist>',
                '      </div>',
                '      <div class="col-md-2">',
                '        <select id="lvType" class="form-select">',
                '          <option value="Vacation">Vacation</option>',
                '          <option value="Sick">Sick</option>',
                '          <option value="Emergency">Emergency</option>',
                '        </select>',
                '      </div>',
                '      <div class="col-md-2">',
                '        <input id="lvFrom" type="date" class="form-control" min="' + today + '">',
                '      </div>',
                '      <div class="col-md-2">',
                '        <input id="lvTo" type="date" class="form-control" min="' + today + '">',
                '      </div>',
                '      <div class="col-md-2">',
                '        <input id="lvReason" class="form-control" placeholder="Reason">',
                '      </div>',
                '      <div class="col-md-1">',
                '        <button id="lvAddBtn" class="btn btn-primary w-100">',
                '          <i class="fas fa-paper-plane"></i>',
                '        </button>',
                '      </div>',
                '    </div>',
                '  </div>',
                '</div>',
                '<div class="card border-0 shadow-sm">',
                '  <div class="card-header bg-white d-flex justify-content-between align-items-center">',
                '    <h5 class="mb-0"><i class="fas fa-inbox text-primary me-2"></i>Leave Requests</h5>',
                '    <div>',
                '      <button id="refreshLeaveBtn" class="btn btn-sm btn-outline-primary me-2" title="Refresh">',
                '        <i class="fas fa-sync-alt"></i>',
                '      </button>',
                '      <span class="badge bg-primary">' + requests.length + ' total</span>',
                '    </div>',
                '  </div>',
                '  <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">',
                '    <table class="table table-hover mb-0 align-middle">',
                '      <thead class="sticky-top bg-white">',
                '        <tr>',
                '          <th>ID</th>',
                '          <th>Employee</th>',
                '          <th>Type</th>',
                '          <th>From</th>',
                '          <th>To</th>',
                '          <th>Days</th>',
                '          <th>Reason</th>',
                '          <th>Status</th>',
                '        </tr>',
                '      </thead>',
                '      <tbody id="leaveRequestsTableBody">',
                requests.length ? requests.map(function (item) {
                    const badgeClass = item.status.toLowerCase() === 'approved' ? 'bg-success-subtle text-success' : 
                                     item.status.toLowerCase() === 'rejected' ? 'bg-danger-subtle text-danger' : 
                                     'bg-warning-subtle text-warning';
                    
                    const statusBadge = item.status.toLowerCase() === 'approved' ? '✅' :
                                      item.status.toLowerCase() === 'rejected' ? '❌' : '⏳';
                    
                    return '<tr>' + 
                        '<td><code>' + item.id + '</code></td>' +
                        '<td><strong>' + item.employee + '</strong></td>' +
                        '<td>' + item.type + '</td>' +
                        '<td>' + item.from + '</td>' +
                        '<td>' + item.to + '</td>' +
                        '<td><span class="badge bg-secondary">' + item.days + ' day' + (item.days > 1 ? 's' : '') + '</span></td>' +
                        '<td><small>' + (item.reason ? item.reason.substring(0, 20) + (item.reason.length > 20 ? '...' : '') : '-') + '</small></td>' +
                        '<td><span class="badge ' + badgeClass + '">' + statusBadge + ' ' + item.status + '</span></td>' +
                    '</tr>';
                }).join('') : 
                '<tr><td colspan="8" class="text-center text-muted py-4"><i class="fas fa-inbox fa-2x mb-2 d-block"></i>No leave requests found</td></tr>',
                '      </tbody>',
                '    </table>',
                '  </div>',
                '</div>'
            ].join('');

            // Add button event listener
            const addButton = document.getElementById('lvAddBtn');
            if (addButton) {
                addButton.addEventListener('click', async function () {
                    const employee = (document.getElementById('lvEmp').value || '').trim();
                    const type = document.getElementById('lvType').value;
                    const from = document.getElementById('lvFrom').value;
                    const to = document.getElementById('lvTo').value;
                    const reason = (document.getElementById('lvReason').value || '').trim();
                    const days = calcDays(from, to);

                    // Validation
                    if (!employee) {
                        showLeaveRequestInfo('Missing Information', 'Please enter employee name.', true);
                        document.getElementById('lvEmp').focus();
                        return;
                    }

                    if (!from) {
                        showLeaveRequestInfo('Missing Information', 'Please select start date.', true);
                        document.getElementById('lvFrom').focus();
                        return;
                    }

                    if (!to) {
                        showLeaveRequestInfo('Missing Information', 'Please select end date.', true);
                        document.getElementById('lvTo').focus();
                        return;
                    }

                    if (!reason) {
                        showLeaveRequestInfo('Missing Information', 'Please enter a reason.', true);
                        document.getElementById('lvReason').focus();
                        return;
                    }

                    if (!days) {
                        showLeaveRequestInfo('Invalid Date Range', 'End date must be on or after start date.', true);
                        document.getElementById('lvTo').focus();
                        return;
                    }

                    // Disable button to prevent double submission
                    addButton.disabled = true;
                    addButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>';

                    try {
                        // Save to database
                        const newRequest = await saveRequestToDB({
                            employee: employee,
                            type: type,
                            from: from,
                            to: to,
                            days: days,
                            reason: reason
                        });

                        // Update local array
                        requests.unshift(newRequest);
                        
                        // Re-render the table
                        await render();
                        
                        showLeaveRequestInfo('Success!', 'Leave request for ' + employee + ' has been submitted for approval.');
                    } catch (error) {
                        // Error already handled in saveRequestToDB
                        addButton.disabled = false;
                        addButton.innerHTML = '<i class="fas fa-paper-plane"></i>';
                    }
                });
            }

            // Refresh button event listener
            const refreshBtn = document.getElementById('refreshLeaveBtn');
            if (refreshBtn) {
                refreshBtn.addEventListener('click', async function () {
                    refreshBtn.disabled = true;
                    refreshBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>';
                    
                    requests = await fetchRequestsFromDB();
                    await render();
                    
                    showLeaveRequestInfo('Refreshed', 'Leave requests have been refreshed from the database.');
                });
            }

            // Auto-update "to" date minimum based on "from" date
            const fromInput = document.getElementById('lvFrom');
            const toInput = document.getElementById('lvTo');
            
            if (fromInput && toInput) {
                fromInput.addEventListener('change', function() {
                    toInput.min = this.value;
                    if (toInput.value && toInput.value < this.value) {
                        toInput.value = this.value;
                    }
                });
            }
        }

        await render();
    };
})(window.HRSubmodules);