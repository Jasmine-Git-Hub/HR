<?php
// php/leave-request-api.php
require_once 'connect.php';

header('Content-Type: application/json');

// Get the request method
$method = $_SERVER['REQUEST_METHOD'];

try {
    switch ($method) {
        case 'GET':
            // Get all leave requests with employee names
            // Since your table has employee_id, we need to join with employees table
            $sql = "SELECT l.*, e.name as employee_name 
                    FROM leave_requests l 
                    LEFT JOIN employees e ON l.employee_id = e.id 
                    ORDER BY l.leave_id DESC";
            
            $stmt = $conn->query($sql);
            $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Format the data to match the JS expected format
            $formattedRequests = array_map(function($row) {
                return [
                    'id' => 'LV-' . $row['leave_id'],
                    'employee' => $row['employee_name'] ?? 'Employee #' . $row['employee_id'],
                    'type' => $row['leave_type'],
                    'from' => $row['start_date'],
                    'to' => $row['end_date'],
                    'days' => $this->calculateDays($row['start_date'], $row['end_date']),
                    'reason' => $row['leave_reason'],
                    'status' => ucfirst($row['leave_status'])
                ];
            }, $requests);
            
            echo json_encode(['success' => true, 'data' => $formattedRequests]);
            break;
            
        case 'POST':
            // Create a new leave request
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data) {
                throw new Exception('Invalid request data');
            }
            
            // First, get or create employee ID
            // For simplicity, we'll check if employee exists by name
            $stmt = $conn->prepare("SELECT id FROM employees WHERE name = :name LIMIT 1");
            $stmt->execute([':name' => $data['employee']]);
            $employee = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($employee) {
                $employee_id = $employee['id'];
            } else {
                // Create new employee if not exists
                $stmt = $conn->prepare("INSERT INTO employees (name, department, status) VALUES (:name, 'General', 'Active')");
                $stmt->execute([':name' => $data['employee']]);
                $employee_id = $conn->lastInsertId();
            }
            
            // Insert leave request
            $sql = "INSERT INTO leave_requests (employee_id, leave_type, start_date, end_date, leave_reason, leave_status) 
                    VALUES (:employee_id, :type, :from_date, :to_date, :reason, :status)";
            
            $stmt = $conn->prepare($sql);
            $stmt->execute([
                ':employee_id' => $employee_id,
                ':type' => $data['type'],
                ':from_date' => $data['from'],
                ':to_date' => $data['to'],
                ':reason' => $data['reason'],
                ':status' => 'pending'
            ]);
            
            $leave_id = $conn->lastInsertId();
            
            echo json_encode([
                'success' => true, 
                'message' => 'Leave request created successfully',
                'data' => [
                    'id' => 'LV-' . $leave_id,
                    'employee' => $data['employee'],
                    'type' => $data['type'],
                    'from' => $data['from'],
                    'to' => $data['to'],
                    'days' => $data['days'],
                    'reason' => $data['reason'],
                    'status' => 'Pending'
                ]
            ]);
            break;
            
        case 'PUT':
            // Update leave request status (approve/reject)
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data || !isset($data['id']) || !isset($data['status'])) {
                throw new Exception('Invalid request data');
            }
            
            // Extract numeric ID from LV-XXX format
            $leave_id = str_replace('LV-', '', $data['id']);
            
            $sql = "UPDATE leave_requests SET leave_status = :status, approval_date = CURDATE()";
            
            // Add approved_by if provided
            if (isset($data['approved_by'])) {
                $sql .= ", approved_by = :approved_by";
            }
            
            $sql .= " WHERE leave_id = :id";
            
            $stmt = $conn->prepare($sql);
            $params = [
                ':status' => strtolower($data['status']),
                ':id' => $leave_id
            ];
            
            if (isset($data['approved_by'])) {
                $params[':approved_by'] = $data['approved_by'];
            }
            
            $stmt->execute($params);
            
            echo json_encode(['success' => true, 'message' => 'Leave request updated successfully']);
            break;
            
        case 'DELETE':
            // Delete a leave request
            $id = isset($_GET['id']) ? str_replace('LV-', '', $_GET['id']) : null;
            
            if (!$id) {
                throw new Exception('Invalid request ID');
            }
            
            $sql = "DELETE FROM leave_requests WHERE leave_id = :id";
            $stmt = $conn->prepare($sql);
            $stmt->execute([':id' => $id]);
            
            echo json_encode(['success' => true, 'message' => 'Leave request deleted successfully']);
            break;
            
        default:
            throw new Exception('Method not allowed');
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

// Helper function to calculate days
function calculateDays($from, $to) {
    $fromDate = new DateTime($from);
    $toDate = new DateTime($to);
    $interval = $fromDate->diff($toDate);
    return $interval->days + 1;
}
?>