<?php
// php/connect.php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hms_hr_db";

try {
    // FIXED: Removed the comma inside the connection string
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // echo "Connected successfully"; // Uncomment to test
} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>